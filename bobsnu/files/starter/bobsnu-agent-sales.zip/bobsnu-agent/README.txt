BOBSNU 실습 폴더 (영업)

이 폴더 하나만 Claude 데스크탑 앱에 연결합니다. 회사 파일이 있는 폴더는 연결하지 않습니다.

CLAUDE.md      지침 파일. 내 규칙 3개를 넣습니다.
index.md       목록표
terms.md       용어·기준 (교육용 예시)
fix-log.md     정정 기록
sources/       원자료. 고치지 않습니다.
examples/      승인된 결과물을 넣는 곳
outputs/       Claude가 결과물을 저장하는 곳
01-practice/   모듈 01에서 쓰는 자료 A~D와 AI 초안
next/          모듈 05에서 쓰는 새 자료
skills/        제공 스킬 13개 (zip은 올리는 용도, 폴더는 읽는 용도)
templates/     요청문, 검수표, 직무 프로필 양식

공개 자료는 2026-11-26에 옮긴 사본이고, 가상이라고 적힌 자료의 숫자와 거래처는 지어낸 것입니다.
