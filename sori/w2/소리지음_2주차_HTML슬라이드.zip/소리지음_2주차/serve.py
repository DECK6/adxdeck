from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import webbrowser
folder=Path(__file__).resolve().parent
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(folder)))
url=f'http://127.0.0.1:{server.server_port}/index.html'
print('소리지음 수업 자료:',url,flush=True)
print('종료하려면 이 창에서 Control+C를 누르세요.',flush=True)
webbrowser.open(url)
try:server.serve_forever()
except KeyboardInterrupt:server.server_close()
