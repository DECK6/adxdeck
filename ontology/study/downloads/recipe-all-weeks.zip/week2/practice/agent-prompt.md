이 폴더는 GPTers 24기 요리와 보유 재료 실습용 AKM입니다.
1. AKM의 99-system/INDEX.md, 현재 40-memory의 메모, 99-system/ROUTER.md·LOOP.md·VERIFICATION.md와 이 폴더의 practice/README.md를 읽으세요.
2. practice/model.json과 practice/questions.json을 읽고, 관계의 뜻·방향·출처를 먼저 확인하세요. 원본 자료는 10-sources, 이 사례의 조건은 30-context/projects에 있습니다. 파일 위치는 practice/note-paths.json에서 찾으세요.
3. 질문마다 답변 / 사용한 문서 ID와 근거 문장 / 따라간 관계 / 판단 불가 사항을 분리하세요. 연결이 없는 내용을 상식으로 메우지 마세요.
4. 재고 목록을 전부 확인했는지 먼저 읽고, 미확인과 없음의 차이를 지키세요.
5. expected-answers.json이나 웹의 참고 답변을 읽거나 답안으로 복사하지 마세요. 비교할 때는 같은 모델·설정의 새 대화에서 같은 질문·응답 형식을 유지하세요.
6. 결과를 practice/response-template.json의 형식으로 새 파일에 저장하세요. phase를 실제 실행 단계(before 또는 after)로 정하고 모델명·실행일·질문을 기록하세요. 템플릿의 미측정 상태를 실행 결과로 오인하지 마세요.
7. 질문은 다음 3개를 그대로 사용하세요.
Q1. 지금 보유 재료가 모두 충족되는 메뉴는 무엇인가요?
Q2. 버터간장밥에 부족한 재료는 무엇인가요?
Q3. 보관함에 버터를 추가하면 재료가 충족되는 메뉴는 어떻게 달라지나요?

웹의 관계 질의 미리보기는 규칙으로 계산한 예시입니다. 실제 LLM 답변은 직접 실행해 기록하세요.
