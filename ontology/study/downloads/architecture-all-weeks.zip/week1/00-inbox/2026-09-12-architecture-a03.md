---
description: "Synthetic source record for the GPTers ontology practice case."
akmLayer: source
akmRole: raw-source
akmType: source
trustLevel: raw
CMDS: Connect
sourceType: agent-output
sourcePath: "https://github.com/DECK6/adxdeck/blob/main/scripts/gpters24/data.mjs"
nextAction: merge
date created: 2026-09-12
date modified: 2026-09-12
---

# A03 · 주방과 다이닝 · 분리된 공간

KITCHEN은 (0,6160)–(3740,9200), DINING은 (3860,5660)–(7740,9200)이다. LIVING과 각각 다른 공간 ID와 형상을 갖는다. 주방은 11.3696㎡, 다이닝은 13.7352㎡다. 공간 간 문은 원 모델에 있으며 여기서는 대표 연결만 다룬다.

원본 상태를 보존하고 해석은 별도 노트에 기록하세요.
