---
description: "Synthetic source record for the GPTers ontology practice case."
akmLayer: source
akmRole: raw-source
akmType: source
trustLevel: raw
CMDS: Connect
sourceType: agent-output
sourcePath: "https://github.com/DECK6/adxdeck/blob/main/scripts/gpters24/data.mjs"
nextAction: merge
date created: 2026-09-12
date modified: 2026-09-12
---

# A09 · 도면 · 좌표와 리비전

DRAWING은 HOUSE를 나타내며 리비전은 FAMILY-02다. 도면의 직사각형은 원 모델의 실내 공간 경계다. mm 좌표, 방 이름, 넓이는 모델과 함께 읽는다. 이 실습의 도면은 벽·문짝·설비가 생략된 공간 관계 도식이며 실시설계 도면이 아니다.

원본 상태를 보존하고 해석은 별도 노트에 기록하세요.
