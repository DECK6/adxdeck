---
description: "Lists every class and property declared in the canonical residential ontology vocabulary."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, korea, residential, ontology, drawing, bim]
---

# 주거 건설 온톨로지 전체 어휘 v0.3.0

vocabulary.json에서 생성했다. 필수값·열거값·nullable·상속은 어휘 정본과 생성 스키마를 따른다.

## 클래스

| 이름 | 한국어 | 상위 | 정의 |
|---|---|---|---|
| Project | 사업 | Object | 승인·설계·시공의 관리 단위 |
| ProjectContext | 적용 맥락 | Object | 지역·용도·규모·날짜·절차 묶음 |
| Site | 대지 | SpatialObject | 법적 경계·지형·접근 조건 |
| Building | 건축물 | SpatialObject | 건물 객체 |
| Storey | 층 | SpatialObject | 기준 레벨을 가진 공간 집합 |
| Space | 공간 | SpatialObject | 실·홀·복도 등 공간 |
| Zone | 구역 | SpatialObject | 방화·열·설비 등 목적별 영역 |
| Route | 경로 | Object | 순서 있는 이동 구간 |
| RouteSegment | 경로 구간 | Object | 폭·경사·높이를 가진 구간 |
| BuildingElement | 건축 부재 | Component | 물리적 건물 구성 요소 |
| Wall | 벽 | BuildingElement | 경계를 이루는 부재; 내력은 별도 역할 |
| Slab | 슬래브 | BuildingElement | 바닥 등의 구조 판 |
| Roof | 지붕 | BuildingElement | 상부 외피 |
| Column | 기둥 | BuildingElement | 수직 구조 부재 |
| Beam | 보 | BuildingElement | 하중 전달 부재 |
| Foundation | 기초 | BuildingElement | 상부 하중을 지반에 전달 |
| Opening | 개구부 | BuildingElement | 부재에 생긴 열린 공간 |
| Door | 문 | BuildingElement | 개구부 출입을 제어하는 조립 부재 |
| Window | 창 | BuildingElement | 외피 등의 개구부에 설치되는 부재 |
| Stair | 계단 | BuildingElement | 높이차 이동 시설 |
| Ramp | 경사로 | BuildingElement | 경사면 이동 시설 |
| Railing | 난간 | BuildingElement | 가장자리 추락 방지 부재 |
| Handrail | 손잡이 | BuildingElement | 사람이 잡는 부재 |
| Assembly | 조립체 | Object | 역할을 수행하는 구성 요소의 조합 |
| Layer | 레이어 | Object | 순서·방향·두께를 가진 층 |
| Material | 재료 | Object | 물질·제품 재료의 종류 |
| ProductType | 제품 형식 | Object | 제조사·제품코드로 식별한 카탈로그 대상 |
| ProductBatch | 자재 로트 | Object | 납품·검사 가능한 실제 묶음 |
| Junction | 접합부 | Object | 부재·층·시스템의 만남 |
| Penetration | 관통부 | Object | 배관 등의 통과로 생기는 부분 |
| BuildingService | 설비 | Component | 환기·급배수·전기·소방 등 |
| ClearanceZone | 여유 공간 | Object | 통과·작동·점검·반출 공간 |
| Datum | 기준면·기준선 | Object | 치수의 원점과 경계 |
| Quantity | 수량·치수 | Object | 값·단위·속성·기준·상태 |
| Requirement | 요구 | Object | 특정 조건에서 요구되는 명제 |
| Rule | 규칙 | Object | 적용조건과 검사항목의 구조화 |
| ApplicabilityCondition | 적용조건 | Object | 삼값 논리로 평가할 조건 |
| Exception | 예외 | Object | 특정 조항을 달리 적용하는 조건 |
| SourceDocument | 출처 문서 | Object | 법령·시방·제품·기술 문서 |
| SourceEdition | 문서 판 | Object | 시행·발행일 및 판 식별 |
| Provision | 조항 | Object | 조·항·호·별표 또는 쪽·표 |
| Evidence | 근거 | Object | 주장과 출처·관측을 잇는 증거 |
| Observation | 관측 | Claim | 실측·시험·검사에서 얻은 사실 |
| Assessment | 판정 | Object | 규칙판·입력판·결과·판정시각 |
| InstallationActivity | 시공 작업 | Activity | 누가 언제 어떤 상세로 시공했는가 |
| Inspection | 검사 | Activity | 시공 상태의 확인 행위 |
| Change | 변경 | Activity | 설계·제품·공정의 리비전 변경 |
| Defect | 결함 | Object | 관찰되거나 확인된 성능·품질 문제 |
| Hypothesis | 원인 가설 | Claim | 관찰을 설명하는 검증 전 명제 |
| PracticeCandidate | 암묵지 후보 | Claim | 조건·반례·검증 상태 있는 현장 지식 |
| Object | 대상 | — | 안정적 ID를 가진 도메인 대상 |
| SpatialObject | 공간 대상 | Object | 포함과 경계의 기준인 공간·구역 |
| Component | 물리 구성요소 | Object | 설치되는 물리 구성요소 |
| Activity | 행위 | Object | 시간·주체·대상 있는 작업 또는 검토 |
| Claim | 주장 | Object | 증거와 승인 상태가 구분되는 명제 |
| Function | 기능 | Object | 단열·기밀·방수·내력 등 수행 기능 |
| Role | 역할 | Object | 세대 경계·공용 등 맥락 의존 역할 |
| Volume | 체적 영역 | SpatialObject | 좌표계가 지정된 공간 영역 |
| Surface | 표면 | Component | 방향과 경계를 가진 면 |
| Drain | 배수구 | BuildingService | 배수 유입 구성요소 |
| Outlet | 배출구 | BuildingService | 시스템 배출 종점 |
| Edge | 가장자리 | Object | 형상 경계의 선 |
| Leaf | 문짝 | Component | 문을 구성하는 움직이는 패널 |
| Frame | 문틀·창틀 | Component | 개구부에 고정되는 프레임 |
| Flight | 계단 경사부 | Component | 참 사이 계단 구간 |
| DoorSwing | 문 개폐 영역 | ClearanceZone | 개폐 상태에 따른 점유 영역 |
| Test | 시험 | Inspection | 선언한 방법·기준으로 수행하는 검사 |
| Concealment | 은폐 | Activity | 후속 공정으로 검사 부분이 가려지는 행위 |
| Handover | 인계 | Activity | 자료와 대상의 인수인계 행위 |
| DeliveryInspection | 반입 검사 | Inspection | 자재 반입 상태 검사 |
| ConcealedInspection | 은폐 전 검사 | Inspection | 가려지기 전 상태 검사 |
| ModelDocument | 모델 문서 | Object | 교환 가능한 그래프의 프로젝트·판·멤버 묶음 |
| ResidentialUnit | 주거 세대 | Zone | 세대 단위 공간 집합과 공용부 경계 |
| CommonArea | 공용부 | Zone | 공용 공간과 관리 경계 |
| ResidentialProfile | 주거 프로필 | Object | 법정 용도·생활 명칭·세대/동 범위 구분 |
| DesignBrief | 설계·복원 입력 | Object | 작업 종류와 목표 산출물·프로그램 |
| SpaceProgram | 공간 프로그램 | Object | 실별 면적·사용·가구·인접 요구 |
| LayoutConstraint | 배치 제약 | Requirement | 의무·현황·제품·선호·가정의 구분 |
| ParcelBoundary | 대지 경계 | SpatialBoundary | 측량 근거와 좌표를 가진 필지 경계 |
| RegulatoryEnvelope | 규제 영역 | Volume | 적용판에 근거한 건축 가능 공간의 제약 |
| Survey | 측량·실측 자료 | SourceDocument | 좌표·일시·방법·정밀도·근거 기록 |
| DrawingDocument | 도면 문서 | SourceDocument | 파일과 판·권한·설계단계의 단위 |
| DrawingSheet | 도면 시트 | Object | 번호·제목·축척·범례·개정의 단위 |
| DrawingView | 도면 뷰 | Object | 평면·단면·입면·상세의 관측/생성 뷰 |
| ViewTransform | 뷰 좌표 변환 | Object | 도면 좌표와 모델 좌표의 매핑 |
| ScaleCalibration | 축척 보정 | Object | 독립 치수로 검증한 축척과 잔차 |
| GridAxis | 기준축 | Object | 통합 도면의 축과 그리드 |
| Placement | 배치 | Object | 부모 좌표계 기준 원점·회전·단위 |
| GeometryProfile | 형상 프로파일 | Object | 좌표계 안의 선·닫힌 외곽·구멍·경사 |
| SolidRepresentation | 입체 표현 | DerivedArtifact | 원본 객체와 리비전에서 파생한 형상 표현 |
| HostFace | 호스트 면 | Surface | 문창 등이 결합되는 벽의 지정 면과 방향 |
| TypeDefinition | 부품 타입 | Object | 재사용 매개변수·제품·호스트·여유 계약 |
| ParameterDefinition | 매개변수 정의 | Object | 값이 아닌 속성·단위·기준·허용범위 정의 |
| SpatialBoundary | 공간 경계 | Object | 공간의 폐합 경계와 이웃 관계 |
| AreaMeasurement | 면적 측정 | Quantity | 전용·공급·실사용·법정 산정 기준의 별도 수량 |
| DimensionAnnotation | 치수 주석 | Object | 치수 값과 기하·기준면·출처 위치의 연결 |
| Tag | 도면 태그 | Object | 안정적 부재 ID와 일람표의 연결 |
| Schedule | 일람표 | DerivedArtifact | 특정 판의 부재 목록과 속성 열 |
| Inference | 추론 기록 | Claim | 관측에서 파생한 가정과 근거·한계 |
| ReconstructionIssue | 복원 쟁점 | Object | 누락·충돌·모호함과 해결 이력 |
| ModelRevision | 모델 판 | Object | 부재·관측·파생물의 동일 시점 묶음 |
| DerivedArtifact | 파생물 | Object | 모델 객체와 판에 의존하는 산출물 |
| DrawingArtifact | 파생 도면 | DerivedArtifact | 원본 뷰에서 생성된 모델판별 도면 |
| ExchangeMapping | 교환 매핑 | Object | 원본 ID와 교환 ID·손실·변환기의 연결 |
| ApprovalRecord | 승인 기록 | Evidence | 무엇을 누가 어느 범위에서 승인했는가 |
| FactAssertion | 조건 사실 | Claim | 조건 코드에 대한 근거 있는 삼값 진술 |
| BenchmarkCase | 검증 사례 | Object | 입력·정답·권한·분리군·검사 목적의 계약 |
| BenchmarkResult | 검증 결과 | Assessment | 사례·모델판·방법·오차·한계를 연결 |
| ServiceConnection | 설비 접속 | Junction | 설비 포트·유체·전기·방향과 점검 조건 |
| Shaft | 설비 샤프트 | Space | 전용/공용과 수직 연결이 있는 공간 |
| Appliance | 가전 | Component | 제품 본체·설치·정비 여유를 구분한 기기 |
| Furniture | 가구 | Component | 사용 공간과 문·가구 간 간섭을 가진 가구 |
| Balcony | 발코니 | Space | 확장 상태·열경계·배수·피난 역할 있는 공간 |
| OndolSystem | 온돌 시스템 | BuildingService | 난방층·분배기·배관의 조합 |
| WetArea | 습식 공간 | Space | 방수·레벨·배수 연결이 있는 공간 |
| StructuralSystem | 구조 시스템 | Object | 하중 전달 형식과 검토 근거 |

## 속성·관계

| 이름 | 적용 클래스 | 목적어/타입 | 개수 | 정의 |
|---|---|---|---|---|
| hasContext | Project | ProjectContext | 단일 값 | 適用 맥락 |
| containsSpace | SpatialObject | Space | 여러 값 | 포함 공간 |
| containsElement | SpatialObject | BuildingElement | 여러 값 | 소속 부재 |
| boundsSpace | BuildingElement | Space | 여러 값 | 경계 공간 |
| adjacentTo | Space | Space | 여러 값 | 인접 공간 |
| connectsSpace | Door | Space | 여러 값 | 문 연결 공간 |
| fillsOpening | Door, Window | Opening | 단일 값 | 채우는 개구부 |
| voidsElement | Opening | BuildingElement | 단일 값 | 절개 대상 |
| hasAssembly | BuildingElement | Assembly | 단일 값 | 조립체 |
| hasLayer | Assembly | Layer | 여러 값 | 재료층 |
| usesMaterial | Layer | Material | 단일 값 | 사용 재료 |
| occupiesZone | Component | Layer, Volume | 여러 값 | 점유 영역 |
| hasQuantity | Object | Quantity | 여러 값 | 수량·치수 |
| measuredFrom | Quantity | Datum | 단일 값 | 측정 기준 |
| joins | Junction | BuildingElement | 여러 값 | 접합 부재 |
| penetrates | Penetration | BuildingElement, Zone | 여러 값 | 관통 대상 |
| sealedBy | Junction, Penetration | Assembly | 단일 값 | 씰 조립체 |
| drainsTo | Surface, Drain | Drain, Outlet | 여러 값 | 배수 대상 |
| hasClearance | Object | ClearanceZone | 여러 값 | 여유 공간 |
| appliesUnder | Rule | ApplicabilityCondition | 여러 값 | 적용 조건 |
| hasException | Rule | Exception | 여러 값 | 예외 |
| requires | Rule | Requirement | 여러 값 | 요구 |
| derivedFrom | Rule, Evidence | Provision | 여러 값 | 근거 조항 |
| inEdition | Provision | SourceEdition | 단일 값 | 출처 판 |
| documentedBy | SourceEdition | SourceDocument | 단일 값 | 문서 |
| assesses | Assessment | Object | 단일 값 | 판정 대상 |
| evaluatesRule | Assessment | Rule | 단일 값 | 판정 규칙 |
| supportedBy | Assessment, Claim | Evidence | 여러 값 | 지지 근거 |
| supersedes | SourceEdition, Rule, ModelRevision | SourceEdition, Rule, ModelRevision | 여러 값 | 대체한 이전 판 |
| precedes | Activity | Activity | 여러 값 | 후속 행위 |
| affectedBy | Object | Change | 여러 값 | 영향 변경 |
| explains | Hypothesis | Observation, Defect | 여러 값 | 설명 대상 |
| tests | Inspection | Hypothesis, Requirement | 여러 값 | 검증 대상 |
| hasSegment | Route | RouteSegment | 여러 값 | 경로 구간 |
| modelProject | ModelDocument | Project | 단일 값 | 모델 프로젝트 |
| modelRevision | ModelDocument | ModelRevision | 단일 값 | 모델 판 |
| hasMember | ModelDocument | Object | 여러 값 | 모델 객체 |
| hasFunction | Layer, Assembly, Component | Function | 여러 값 | 수행 기능 |
| hasRole | Object | Role | 여러 값 | 맥락 역할 |
| hasLeaf | Door | Leaf | 여러 값 | 문짝 |
| hasFrame | Door, Window | Frame | 단일 값 | 틀 |
| hasFlight | Stair | Flight | 여러 값 | 계단 경사부 |
| serves | ClearanceZone, BuildingService | Object | 여러 값 | 서비스 대상 |
| protects | Railing | Edge | 여러 값 | 보호 가장자리 |
| intersects | Volume, Surface | Object | 여러 값 | 간섭 대상 |
| establishedBefore | Datum | Activity | 여러 값 | 기준 설정 후 행위 |
| hasProfile | ProjectContext | ResidentialProfile | 단일 값 | 주거 프로필 |
| hasBrief | Project | DesignBrief | 단일 값 | 작업 입력 |
| hasProgram | DesignBrief | SpaceProgram | 여러 값 | 공간 요구 |
| hasConstraint | DesignBrief, SpaceProgram, RegulatoryEnvelope | LayoutConstraint | 여러 값 | 제약 |
| hasSite | Project | Site | 단일 값 | 대지 |
| hasBuilding | Site | Building | 여러 값 | 건물 |
| hasStorey | Building | Storey | 여러 값 | 층 |
| hasUnit | Building | ResidentialUnit | 여러 값 | 주거 세대 |
| hasCommonArea | Building, ResidentialUnit | CommonArea | 여러 값 | 공용부 맥락 |
| belongsToStorey | BuildingElement, Space, ResidentialUnit | Storey | 단일 값 | 소속 층 |
| belongsToRevision | Object | ModelRevision | 단일 값 | 모델 판 |
| hasPlacement | Component, SpatialObject, GeometryProfile, GridAxis | Placement | 단일 값 | 배치 |
| relativeTo | Placement | Placement | 단일 값 | 부모 배치 |
| hasGeometry | Component, SpatialObject, SpatialBoundary | GeometryProfile | 단일 값 | 형상 |
| hasBoundary | Space, ResidentialUnit, Site | SpatialBoundary | 여러 값 | 공간 경계 |
| hasHostFace | Opening | HostFace | 단일 값 | 호스트 면 |
| widthQuantity | Opening | Quantity | 단일 값 | 개구부 폭 수량 |
| heightQuantity | Opening | Quantity | 단일 값 | 개구부 높이 수량 |
| baseHeightQuantity | Opening | Quantity | 단일 값 | 개구부 하단 수량 |
| offsetQuantity | Opening | Quantity | 단일 값 | 호스트 시작 거리 수량 |
| faceOf | HostFace | Wall | 단일 값 | 호스트 벽 |
| hasType | Component, Assembly | TypeDefinition | 단일 값 | 타입 |
| hasParameter | TypeDefinition | ParameterDefinition | 여러 값 | 매개변수 정의 |
| hasSource | Object | SourceDocument | 여러 값 | 출처 |
| hasEvidence | Object | Evidence | 여러 값 | 증거 |
| hasApproval | Object | ApprovalRecord | 단일 값 | 승인 기록 |
| hasInference | Object | Inference | 단일 값 | 추론 기록 |
| usesInput | Inference | Quantity, Evidence | 여러 값 | 추론 입력 |
| quantitySubject | Quantity | Object | 단일 값 | 수량 대상 |
| inputQuantity | Quantity | Quantity | 여러 값 | 계산 입력 |
| hasSheet | DrawingDocument | DrawingSheet | 여러 값 | 시트 |
| hasView | DrawingSheet | DrawingView | 여러 값 | 뷰 |
| inDocument | DrawingSheet | DrawingDocument | 단일 값 | 소속 문서 |
| inSheet | DrawingView | DrawingSheet | 단일 값 | 소속 시트 |
| hasTransform | DrawingView | ViewTransform | 단일 값 | 뷰 변환 |
| hasCalibration | ViewTransform | ScaleCalibration | 단일 값 | 축척 보정 |
| observes | DrawingView, DimensionAnnotation | Object | 여러 값 | 관측 대상 |
| annotates | DimensionAnnotation, Tag | Object | 단일 값 | 주석 대상 |
| dimensionQuantity | DimensionAnnotation | Quantity | 단일 값 | 표시 수량 |
| hasTag | DrawingView | Tag | 여러 값 | 태그 |
| hasDimension | DrawingView | DimensionAnnotation | 여러 값 | 치수 주석 |
| listsElement | Schedule | Component | 여러 값 | 일람 객체 |
| dependsOn | DerivedArtifact | Object | 여러 값 | 파생 입력 객체 |
| showsView | DrawingArtifact | DrawingView | 단일 값 | 표현 뷰 |
| derivedFromRevision | DerivedArtifact | ModelRevision | 단일 값 | 파생 원본 판 |
| hasRepresentation | Component | SolidRepresentation | 여러 값 | 입체 표현 |
| hasIssue | ModelRevision, DrawingDocument | ReconstructionIssue | 여러 값 | 쟁점 |
| concerns | ReconstructionIssue | Object | 여러 값 | 쟁점 대상 |
| candidateQuantity | ReconstructionIssue | Quantity | 여러 값 | 충돌 치수 후보 |
| startStorey | Stair | Storey | 단일 값 | 시작 층 |
| endStorey | Stair | Storey | 단일 값 | 끝 층 |
| usesOpening | Stair | Opening | 단일 값 | 상층 바닥 개구부 |
| connectsService | ServiceConnection | BuildingService | 여러 값 | 연결 설비 |
| hasStructuralSystem | Building | StructuralSystem | 단일 값 | 구조 시스템 |
| hasExchange | ModelRevision | ExchangeMapping | 여러 값 | 교환 결과 |
| hasBenchmark | Project | BenchmarkCase | 여러 값 | 평가 사례 |
| evaluatesCase | BenchmarkResult | BenchmarkCase | 단일 값 | 평가 사례 |
| label | Object | string | 단일 값 | 한국어 명칭 |
| schemaVersion | ModelDocument | string | 단일 값 | 데이터 계약 판 |
| evidenceStatus | Object | string | 단일 값 | 값을 안 방식 |
| approvalStatus | Object | string | 단일 값 | 승인 상태 |
| lifeCycleStage | Object | string | 단일 값 | 설계·시공 상태 |
| revisionCode | ModelRevision, SourceEdition, DrawingDocument | string | 단일 값 | 판 식별 |
| createdAt | ModelRevision, Observation, ApprovalRecord | string | 단일 값 | 기록 시점 |
| checkedAt | SourceDocument, FactAssertion | string | 단일 값 | 확인 시점 |
| uri | SourceDocument | string | 단일 값 | 문서 위치 |
| sourceKind | SourceDocument | string | 단일 값 | 출처 성격 |
| sourceLocator | Evidence, Observation, DimensionAnnotation | string | 단일 값 | 원문 위치 |
| verificationStatus | SourceDocument, Rule, TypeDefinition | string | 단일 값 | 확인 수준 |
| workMode | DesignBrief | string | 단일 값 | 작업 종류 |
| modelScope | DesignBrief, ResidentialProfile | string | 단일 값 | 공간 범위 |
| outputPurpose | DesignBrief | string | 단일 값 | 산출물 목적 |
| requestedOutputs | DesignBrief | json | 단일 값 | 필요 산출물 |
| legalUse | ResidentialProfile | string | 단일 값 | 법정 용도 |
| colloquialUse | ResidentialProfile | string | 단일 값 | 생활 명칭 |
| useEvidenceStatus | ResidentialProfile | string | 단일 값 | 법정 용도 확인 |
| procedure | ProjectContext | string | 단일 값 | 승인 절차 |
| location | ProjectContext | json | 단일 값 | 주소·지역 |
| applicationDate | ProjectContext | string | 단일 값 | 적용 신청일 |
| energyRegion | ProjectContext | string | 단일 값 | 에너지 지역 |
| householdProgram | SpaceProgram | json | 단일 값 | 가구 구성·실·수납·생활 요구 |
| constraintKind | LayoutConstraint | string | 단일 값 | 제약 종류 |
| expression | LayoutConstraint, Rule, ApplicabilityCondition, Exception | json | 단일 값 | 명시 연산식 |
| strength | LayoutConstraint | string | 단일 값 | 강도 |
| value | Quantity | number | 단일 값 | 값 |
| unit | Quantity, Placement, GeometryProfile, ParameterDefinition | string | 단일 값 | 단위 |
| propertyTerm | Quantity, ParameterDefinition | string | 단일 값 | 측정 속성 |
| basis | Quantity, ParameterDefinition | string | 단일 값 | 측정 기준 |
| uncertainty | Quantity | number | 단일 값 | 측정 불확도 |
| formula | Quantity | string | 단일 값 | 계산식 식별 |
| validityStatus | Quantity | string | 단일 값 | 수량의 현 판 유효성 |
| areaBasis | AreaMeasurement | string | 단일 값 | 면적 산정 종류 |
| datumKind | Datum | string | 단일 값 | 기준 종류 |
| origin | Placement | json | 단일 값 | 부모 좌표계의 원점 |
| rotationDeg | Placement | number | 단일 값 | 로컬 Z축 회전 |
| handedness | Placement | string | 단일 값 | 좌표계 방향 |
| northAngleDeg | Placement | number | 단일 값 | 북향 각도 |
| georeference | Placement | json | 단일 값 | 측량/지리 좌표 매핑 |
| geometryKind | GeometryProfile | string | 단일 값 | 형상 종류 |
| points | GeometryProfile | json | 단일 값 | 로컬 좌표 점 배열 |
| holes | GeometryProfile | json | 단일 값 | 내부 닫힌 구멍 배열 |
| referenceSide | Wall | string | 단일 값 | 벽 기준면 |
| interiorSide | Wall | string | 단일 값 | 축 진행에 대한 실내측 |
| wallRoles | Wall | json | 단일 값 | 벽 역할 |
| joinKind | Junction | string | 단일 값 | 접합 종류 |
| layerJoinPolicy | Junction | json | 단일 값 | 레이어 접속 정책 |
| operation | Door, Window | string | 단일 값 | 개폐 방식 |
| swingHand | Door | string | 단일 값 | 개폐 방향 |
| faceSide | HostFace | string | 단일 값 | 호스트 벽 면 |
| layerOrder | Layer | integer | 단일 값 | 레이어 순서 |
| direction | Assembly | string | 단일 값 | 조립 순서 방향 |
| compositionMode | Assembly, Layer | string | 단일 값 | 두께 결합 |
| typeCode | TypeDefinition, ProductType | string | 단일 값 | 타입 코드 |
| manufacturer | ProductType, TypeDefinition | string | 단일 값 | 제조사 |
| productEdition | ProductType, TypeDefinition | string | 단일 값 | 제품 판 |
| parameterValues | Component, Assembly | json | 단일 값 | 타입별 매개변수 값 |
| parameterConstraints | ParameterDefinition | json | 단일 값 | 명시 범위·근거 |
| hostConditions | TypeDefinition | json | 단일 값 | 호스트 조건 |
| clearancePurpose | ClearanceZone | string | 단일 값 | 여유 목적 |
| balconyState | Balcony | string | 단일 값 | 발코니 상태 |
| thermalBoundaryStatus | Balcony | string | 단일 값 | 열경계 확인 |
| ownershipScope | Space, Component | string | 단일 값 | 전용·공용 맥락 |
| serviceKind | BuildingService, ServiceConnection | string | 단일 값 | 설비 종류 |
| servicePorts | BuildingService, ServiceConnection | json | 단일 값 | 접속 포트·조건 |
| structuralKind | StructuralSystem | string | 단일 값 | 하중 전달 형식 |
| sheetNumber | DrawingSheet | string | 단일 값 | 시트 번호 |
| sheetTitle | DrawingSheet | string | 단일 값 | 시트 제목 |
| viewKind | DrawingView | string | 단일 값 | 뷰 종류 |
| viewSettings | DrawingView | json | 단일 값 | 절단·투영·축척·스타일 |
| sheetStyle | DrawingSheet | json | 단일 값 | 선·폰트·축척·범례 |
| sourcePixelRegion | DimensionAnnotation, Tag | json | 단일 값 | 원문 위치 영역 |
| transformMatrix | ViewTransform | json | 단일 값 | 도면→모델 변환 |
| calibrationChecks | ScaleCalibration | json | 단일 값 | 독립 치수와 잔차 |
| calibrationStatus | ScaleCalibration | string | 단일 값 | 보정 상태 |
| tagCode | Tag | string | 단일 값 | 태그 코드 |
| columns | Schedule | json | 단일 값 | 일람표 열 |
| artifactStatus | DerivedArtifact | string | 단일 값 | 파생물 상태 |
| artifactFormat | DerivedArtifact | string | 단일 값 | 표현 형식 |
| artifactUri | DerivedArtifact | string | 단일 값 | 산출물 경로 |
| inferenceMethod | Inference | string | 단일 값 | 추론 방법 |
| limitations | Inference, BenchmarkCase, BenchmarkResult | json | 단일 값 | 한계 |
| issueKind | ReconstructionIssue | string | 단일 값 | 쟁점 종류 |
| issueStatus | ReconstructionIssue | string | 단일 값 | 쟁점 상태 |
| reason | ReconstructionIssue, Evidence, Assessment | string | 단일 값 | 사유 |
| assessmentResult | Assessment | string | 단일 값 | 개별 판정 |
| isWholeBuildingApproval | Assessment | boolean | 단일 값 | 전체 건물 승인 아님 |
| authority | Rule | string | 단일 값 | 규범 성격 |
| ruleCode | Rule, FactAssertion | string | 단일 값 | 규칙 ID |
| factCode | FactAssertion | string | 단일 값 | 조건 코드 |
| truthValue | FactAssertion | boolean | 단일 값 | 삼값 사실 |
| approvalScope | ApprovalRecord | json | 단일 값 | 승인 대상·범위 |
| reviewerRole | ApprovalRecord | string | 단일 값 | 검토자 역할 |
| exchangeFormat | ExchangeMapping | string | 단일 값 | 교환 형식·판 |
| converterVersion | ExchangeMapping | string | 단일 값 | 변환기 판 |
| idMappings | ExchangeMapping | json | 단일 값 | ID 대응 |
| losses | ExchangeMapping | json | 단일 값 | 손실 목록 |
| roundTripStatus | ExchangeMapping | string | 단일 값 | 왕복 검사 |
| datasetKind | BenchmarkCase | string | 단일 값 | 자료 종류 |
| buildingGroupId | BenchmarkCase | string | 단일 값 | 중복·대칭을 묶는 건물 ID |
| split | BenchmarkCase | string | 단일 값 | 자료 분리 |
| rightsStatus | BenchmarkCase, DrawingDocument | string | 단일 값 | 재사용 권한 |
| privacyStatus | BenchmarkCase, DrawingDocument | string | 단일 값 | 개인정보 처리 |
| inputManifest | BenchmarkCase | json | 단일 값 | 입력·정답·판·해시 |
| metrics | BenchmarkResult | json | 단일 값 | 오차·방법·범위 |
| hasRegulatoryEnvelope | Site | RegulatoryEnvelope | 여러 값 | 대지의 규제 검토 영역; 미확정 연결은 추정으로 표시한다. |
| basedOnSurvey | Site, GeometryProfile | Survey | 여러 값 | 측량 근거; 미확정 연결은 추정으로 표시한다. |
| hasService | Building, Space, Zone | BuildingService | 여러 값 | 연결된 설비; 미확정 연결은 추정으로 표시한다. |
| approvalDecision | ApprovalRecord | string | 단일 값 | 특정 프로젝트·개정본·대상에 대한 검토 결정. 법정 자격이나 실제 심사를 자동 증명하지 않는다. |
