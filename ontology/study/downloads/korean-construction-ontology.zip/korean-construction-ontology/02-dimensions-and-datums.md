---
description: "Source-scoped Korean construction knowledge and ontology foundations: 02-dimensions-and-datums."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 치수·단위·기준면 사전

## 반드시 별도 속성으로 저장할 치수

| 용어 / 속성 | 의미 | 혼동하면 생기는 오류 |
|---|---|---|
| 중심선치수 / axisDistance | 기둥·벽 기준축 사이 | 실제 실내 공간을 과대평가 |
| 안목치수 / clearInsideDimension | 마감면 등 지정 경계 사이의 순수 치수 | 골조치수와 동일시 |
| 골조 개구부 / roughOpeningWidth | 구조체에 마련한 구멍의 너비 | 문틀 설치 여유 누락 |
| 문틀 외경 / frameOuterWidth | 문틀 바깥쪽 전체 폭 | 개구부와 문틀이 끼지 않음 |
| 문짝 폭 / leafWidth | 움직이는 문 패널 너비 | 실제 통과유효폭과 혼동 |
| 통과유효폭 / clearOpeningWidth | 문을 정해진 상태로 열었을 때 통과 가능한 폭 | 문짝 900을 접근성 적합으로 오인 |
| 창대높이 / sillHeightAboveFFL | 실내 마감바닥부터 창대 상단 등 지정 지점 | 창 하단·유리 하단·난간 높이 혼동 |
| 창 상단높이 / headHeightAboveFFL | 마감바닥부터 창호 상단 지정 지점 | 개구부 높이와 혼동 |
| 층높이 / storeyHeight | 명시한 층 기준면 간 수직거리 | 천장 아래 유효높이로 오인 |
| 반자높이 / ceilingHeight | 마감바닥부터 반자까지 | 보·덕트 아래 국소 높이를 무시 |
| 유효높이 / clearHeadroom | 통행면부터 최저 장애물 하단 | 천장 일부만 높아도 통과로 판정 |
| 구조 슬래브 두께 / structuralThickness | 콘크리트 등 구조체 자체 | 마감·난방층을 포함해 법정값 충족 주장 |
| 바닥 구성 총두께 / floorAssemblyThickness | 지정 방향의 전체 레이어 합 | 층고에서 중복 차감 |
| 벽체 총두께 / assemblyThickness | 구조·단열·공기층·마감 포함 | 구조벽 두께로 사용 |
| 도막 건조두께 / dryFilmThickness | 경화·건조 후 도막 두께 | 습윤 도포두께와 혼동 |
| 구배 / slope | 수직 높이차 ÷ 수평 투영길이 | 경사면 길이 또는 각도와 혼동 |

FFL은 마감바닥 기준면, SSL은 구조 슬래브 기준면으로 이 문서에서 정의한다. 실제 도면의 FL·SL 표기는 사무소마다 다를 수 있으므로 도면 범례를 먼저 매핑한다. `THK`는 두께 표기 관례이지 단위 자체가 아니다.

## 단위 규칙

기본 길이 저장은 mm, 면적 m², 체적 m³, 열전도율 W/(m·K), 열관류율 W/(m²·K), 환기횟수 h⁻¹이다. 원문 단위와 정규화 단위를 함께 남긴다. 1m=1,000mm, 1cm=10mm. 소음 dB는 시험량과 평가방법까지 저장한다. 서로 다른 충격음 지표의 dB를 단순 합산·비교하지 않는다.

구배 1:12 = 1/12 ≈ 8.33%다. 12도와 다르다. 요구가 `≤1/12`이면 1:15는 더 완만하고 1:8은 더 급하다. 온도는 열전달 계산에서 차이와 절대값을 구별한다.

## 공차는 허용 최솟값과 다르다

법정 유효폭이 900mm인 곳의 도면을 정확히 900mm로 잡으면 마감·문틀·철물·시공 편차 때문에 실측은 작아질 수 있다. 설계 여유는 법정 기준을 낮추는 공차가 아니다. 온톨로지에는 `requiredMin`, `designNominal`, `manufacturingTolerance`, `installationTolerance`, `measuredValue`, `measurementUncertainty`를 나눠 둔다.

예를 들어 구조 개구부 1,050mm, 문틀 설치 틈 10mm씩, 문틀 외경 1,030mm라는 예제는 조립 여유 설명일 뿐 보편 창호 시방이 아니다. 유효폭은 이 값만으로 확정할 수 없으며 프레임 단면·열림각·문 두께·철물 간섭을 확인해야 한다.

## 모듈과 표준

주택건설기준 등에 관한 규칙 제3조는 안목치수 원칙과 일부 평면치수의 50mm 기준척도를 규정한다. 같은 조의 주택 거실·침실 반자높이 및 층높이는 별도 조건이다. ‘모듈 50mm’에서 ‘모든 문은 900×2,100mm’를 도출할 수 없다. 출처: S06, [16-source-register](16-source-register.md).

## 측정값 레코드 예

```yaml
id: OBS-DOOR-001
subject: EX-DOOR-101
property: clearOpeningWidth
value: 892
unit: mm
basis: finished_clear_opening
state: as_built
method: field_measurement
openingState: declared_in_measurement_record
measuredAt: 2026-09-05
uncertaintyMm: null
sourceDrawingRevision: null
```

이 예의 892mm는 가상 측정값이다. `null`은 모름이며 0으로 바꾸지 않는다. 자재 카탈로그 치수는 `state: product_nominal`, 시공도 치수는 `state: designed`로 저장한다.
