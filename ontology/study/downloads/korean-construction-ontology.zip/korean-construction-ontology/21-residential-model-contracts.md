---
description: "Defines the residential model input, geometry, quantity, provenance and revision contracts."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, korea, residential, ontology, drawing, bim]
---

# 한국 주거 모델의 입력·형상·근거 계약 v0.3

정본은 [residential-model.schema.json](schemas/residential-model.schema.json)의 객체·관계·값·근거·리비전이다. 메시나 판매용 평면 이미지가 이를 대신하지 않는다.

## 입력 범위

루트는 schemaVersion/modelId/projectId/revisionId/entities다. ID는 고유하고 관계는 존재하는 올바른 타입의 ID를 참조한다. Project는 hasContext와 hasBrief를 가진다.

DesignBrief.workMode는 reconstruct_existing/design_new/propose_change, modelScope는 unit/building/site다. outputPurpose는 visualization/editable_model/concept_design/design_documents다. 이 릴리스는 설계·시공 도서 출고 검증을 제공하지 않아 design_documents를 OUTPUT_UNVERIFIED로 반환한다.

legalUse와 colloquialUse는 별도다. 법정 용도·절차·주소·시점 미확정은 개념 모델에는 표현하되 법규 적용은 UNKNOWN으로 둔다. 세대 모델에서도 공용 샤프트와 구조·세대경계·피난 연결 맥락을 보존한다.

## 치수는 부재에 귀속된 주장이다

| 필드 | 의미 |
|---|---|
| quantitySubject, propertyTerm | 어느 객체의 어떤 물리량인가 |
| value, unit | 수치·단위; 미상은 null |
| basis, measuredFrom | 측정 의미·실제 Datum 참조 |
| evidenceStatus | 관측·실측·계산·가정·미상 |
| approvalStatus, hasApproval | 검토·승인 상태 및 범위 기록 |
| lifeCycleStage | 기존·설계·준공·철거·신설·제품 명목·참고 |
| uncertainty | 같은 단위의 불확실성; 미상은 null |
| validityStatus | current/stale/unverified |
| hasSource / hasEvidence / hasInference | 출처·근거·가정 |
| inputQuantity, formula | 계산 입력·산식; 문자열 산식을 임의 실행하지 않음 |

unknown과 value=null은 함께 움직인다. 값 0은 실제 0이라는 주장이다. 관측/실측은 출처나 근거, 가정은 Inference, 계산은 입력 수량과 산식을 요구한다. approved는 측정 방법으로 사용할 수 없다.

문짝·문틀·골조 개구부·통과유효폭, 구조 슬래브·온돌/완충/마감·바닥 전체 두께는 각각 다른 물리량과 기준을 사용한다. 전용·공급·계약·실사용 면적은 AreaMeasurement.areaBasis로 구분한다.

## 좌표·벽·레이어

Placement는 XYZ 원점, Z축 회전, right/mirrored, mm/m, 부모 relativeTo를 가진다. 참조 함수는 로컬 X 반전 → Z 회전 → 같은 단위의 원점 이동 → 출력 단위 변환 순서다. 부모 순환은 거부한다. georeference에 EPSG·변환 파라미터를 기록하며 미상 EPSG를 확정하지 않는다.

GeometryProfile.points는 순서 있는 XYZ 배열이다. polygon/slope_surface는 첫 점을 마지막에 반복하고 내부 holes를 둔다. 참조 검사는 평면의 주축 투영으로 닫힘·자기교차·퇴화·비평면성·구멍의 외부 이탈·접촉·겹침을 확인한다. 수직 다각형도 허용하며 단위는 mm로 맞춘다. 자유곡면·전체 솔리드 유효성은 별도 기하 커널 범위다.

벽 경로의 진행 방향에서 내부가 왼쪽/오른쪽인지 interiorSide에 적고 기준선은 referenceSide=center/interior/exterior로 정한다. 두께 200mm, 내부 왼쪽일 때 오프셋은 각각 [-100,+100], [-200,0], [0,+200]mm다. 이는 기하 예제이며 법정 두께가 아니다.

Junction은 joins, joinKind(L/T/X 등), layerJoinPolicy로 대상·층별 연속/중단·우선순위를 기록한다. 단열·기밀·방수·내화 충전은 별도 요구다. 미확정 접합을 단순 겹침으로 확정하지 않는다.

Assembly는 direction과 layerOrder로 층을 정렬한다. serial은 직렬 구성, parallel_zone은 같은 깊이를 공유하는 영역이다. 스터드와 충진재는 같은 Layer/Volume을 occupiesZone으로 참조해 공유 두께를 한 번만 센다. 단열 성능은 두께 합만으로 판정하지 않는다.

## 개구부·층·계단

Opening은 Wall/Slab/Roof와 Storey를 가리킨다. 수량 주어는 해당 Opening이어야 한다.

| 관계 | propertyTerm | 기준 예 |
|---|---|---|
| offsetQuantity | hostOffset | host_axis_start / slab_local |
| widthQuantity | roughOpeningWidth | rough_opening |
| heightQuantity | roughOpeningHeight | rough_opening / slab_thickness |
| baseHeightQuantity | openingBaseHeight | FFL / SSL |

문·창은 fillsOpening으로 연결한다. 문 개폐/손잡이와 설치·작동·정비 여유는 별도다. 창대 미상인 창의 완전한 높이를 사실처럼 만들지 않는다.

Storey의 SSL·FFL은 hasQuantity와 Datum을 사용한다. 계단은 startStorey/endStorey, hasFlight, usesOpening으로 위층 슬래브 구멍에 연결한다. 참조 검사는 부모 Placement·회전·반전·단위를 적용한 공통 좌표의 구멍 외곽을 대조한다. 모든 위치의 머리 공간·단수·참 계산은 후속 기하 기능이다.

## 관측·도면·변경

DrawingDocument는 파일·판·권한·개인정보 상태, Sheet는 번호·표제·스타일, View는 종류·변환·표현 설정을 가진다. DimensionAnnotation은 원문 위치·대상·수량, Tag는 대상·태그를 연결한다.

ScaleCalibration의 verified는 이 프로젝트 계약상 서로 다른 치수 참조 두 개 이상을 요구한다. 실제 독립성·허용 잔차·왜곡 보정 정확도는 파서와 검토자가 검사해야 한다. 사진 원근을 일반 평면 축척으로 취급하지 않는다.

치수 충돌은 candidateQuantity에 양쪽 값을 남긴다. resolved에는 근거와 승인 기록이 필요하다. 발코니 확장, 철거/신설, 시공 전후는 별도 ModelRevision과 lifeCycleStage로 보존한다.

변경은 원시 관측을 보존하면서 파생 도면·솔리드·일람표와 계산값을 stale로 만든다. 참조 무효화 함수는 보수적으로 연결 그래프를 따라가므로 실제 편집기의 최소 재생성 범위보다 클 수 있다. 후속 엔진이 재생성·검증해야 current가 된다.

## 출력과 검증

[output-contracts.json](output-contracts.json)은 평면·단면·입면·일람표·실내입면·천장·편집3D·IFC·시각화의 설정·포함 정보를 정한다. sheetStyle/viewSettings/servicePorts 등 자유 JSON의 내부 값은 도구별 확장 영역으로, 연동 시 세부 스키마를 추가한다.

JSON Schema는 필드·타입, SHACL은 RDF 관계·필수값 및 일부 의미 제약, Python은 ID·호스트·국소 기하·상태 불변식을 검사한다. SHACL만으로 실제 구조·피난·인허가를 확인하지 않는다. [JSON Schema 2020-12](https://json-schema.org/draft/2020-12/json-schema-core), [W3C SHACL](https://www.w3.org/TR/shacl/).

JSON-LD는 실제 RDF 그래프를 [W3C JSON-LD 1.1](https://www.w3.org/TR/json-ld11/)에 맞게 직렬화한다. IFC는 판·변환기·ID 대응·손실·왕복 상태의 계약만 제공하며 실제 IFC 파일 변환은 아직 구현하지 않았다.

## v0.3 반복 검토 보강

- 승인 범위는 projectId/revisionId/entityIds/modelDigest로 고정한다. approvalDecision, 검토자 역할, 시간대가 있는 createdAt, 원 승인 문서 hasSource가 필요하다. revision_digest(model)은 승인 레코드·승인 링크/상태를 제외한 모델 전체의 의미 정규화 SHA-256이다. 데이터가 달라지면 승인을 재검토한다. 자격·서명 진위 검증을 대신하지 않는다.
- 치수·형상·출처·타입 매개변수 변경은 연결된 파생물에 전파한다. 기존 승인 링크를 제거해 재검토 상태로 돌리며 원 승인 기록은 남긴다.
- 벽 두께 같은 양수 치수와 막힌 통로의 실측 유효폭 0을 구분한다. 0을 미상으로 바꾸지 않는다. 법규 미달 실측도 사실 데이터로 보존한다.
- 도면 문서/시트/뷰 소속을 양방향으로 확인하고, 개정본·공간 포함·수량 계산·산출물 의존의 순환을 진단한다. 뷰 좌표변환은 가역이어야 한다.
- RDF 숫자는 xsd:decimal이다. 큰 정수를 보존하고 JSON 수치로 손실 없이 읽을 수 없는 외부 소수는 명시적으로 거절한다. 알 수 없는 소유 객체 속성·타입·누락 멤버·잘못된 IRI/자료형을 조용히 버리지 않는다. RDF 1.1 단순 문자열과 xsd:string은 모두 허용한다.
- RDF 입력에서 모델 인스턴스 이름공간 밖의 독립적인 스키마 트리플은 모델 데이터로 수입하지 않는다. 소유 객체의 외부 주석은 미지원 속성 오류로 반환한다. 내보낸 파일은 JSON 정본에서 재생성한다.
- View 설정·서비스 포트 등 확장 JSON을 실제 엔진에 연결할 때에는 도구별 세부 계약을 추가한다. 검증 통과만으로 렌더러가 완성되거나 실측 정확도가 확인되지는 않는다.
