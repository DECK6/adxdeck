---
description: "Source register for Korean construction ontology foundations."
akmLayer: knowledge
akmType: map
trustLevel: unverified
sourceType: synthesis
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, sources, ontology]
---

# 출처 장부와 확인 수준

확인일 2026-09-05. 접근·원문 확인·최신판·프로젝트 적용은 별도 상태다. 검색 크롤링 날짜는 시행일이 아니다. 직접 확인도 실제 사업 적용 승인을 뜻하지 않는다.

## S01 · 건축법 시행령 제3조의5·별표1

- 성격: LAW
- 판·위치: 용도분류 경로
- 확인: 검색 조문 확인; 최신 별표 전체 미대조
- 원문: [건축법 시행령 제3조의5·별표1](https://law.go.kr/법령/건축법시행령)

## S02 · 주택건설기준 규정 제14조의2

- 성격: LAW
- 판·위치: 2026-06-30 시행, 대통령령 36475
- 확인: 직접 조문 확인
- 원문: [주택건설기준 규정 제14조의2](https://law.go.kr/lsLinkCommonInfo.do?lsJoLnkSeq=1021077579)

## S03 · 주택건설기준 규정 제14조

- 성격: LAW
- 판·위치: 2026-06-30 시행
- 확인: 직접 조문 확인
- 원문: [주택건설기준 규정 제14조](https://www.law.go.kr/lsLinkCommonInfo.do?lsJoLnkSeq=1030114601)

## S04 · 주택건설기준 규정 제18조제2항

- 성격: LAW
- 판·위치: 2026-06-30 시행
- 확인: 검색 조문 확인
- 원문: [주택건설기준 규정 제18조제2항](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1033039947)

## S04b · 주택건설기준 규정 제18조제3항

- 성격: LAW
- 판·위치: 2026-05-06 관련 판
- 확인: 검색 확인; 최신판 재대조 필요
- 원문: [주택건설기준 규정 제18조제3항](https://www.law.go.kr/LSW/lsInfoP.do?ancYnChk=0&chrClsCd=010202&efYd=20260506&lsiSeq=285833&urlMode=lsInfoP)

## S05 · 피난방화규칙 제14~17조

- 성격: LAW
- 판·위치: 2025-10-31 시행, 국토교통부령 1531
- 확인: 직접 조문 확인; 대상 시행령 별도
- 원문: [피난방화규칙 제14~17조](https://www.law.go.kr/lumLsLinkPop.do?ancYnChk=0&chrClsCd=010202&lspttninfSeq=105110)

## S06 · 주택건설기준 규칙 제3조

- 성격: LAW
- 판·위치: 2023-12-11 시행, 국토교통부령 1282
- 확인: 검색 본문 확인; 최신판 미확정
- 원문: [주택건설기준 규칙 제3조](https://law.go.kr/LSW/lsInfoP.do?lsiSeq=256865)

## S07 · 편의증진법 시행규칙 별표1

- 성격: LAW
- 판·위치: 별표 개정 2023-12-11, 22쪽 PDF
- 확인: 원문 텍스트 확인; 최신 별표 미확정
- 원문: [편의증진법 시행규칙 별표1](https://www.law.go.kr/LSW/flDownload.do?bylClsCd=110201&flSeq=135226913)

## S08 · 건축물 에너지절약설계기준

- 성격: NOTICE
- 판·위치: 제2025-738호, 시행 2025-12-31
- 확인: 표제·검색 조문 확인
- 원문: [건축물 에너지절약설계기준](https://www.law.go.kr/LSW/admRulInfoP.do?admRulSeq=2100000269510&chrClsCd=010201)

## S09 · 한국에너지공단 에너지절약설계기준 해설서

- 성격: GUIDANCE
- 판·위치: 제2025-738호, 2025-12-31 배포
- 확인: 공식 PDF 22쪽/인쇄18쪽 표 직접 이미지 대조
- 원문: [한국에너지공단 에너지절약설계기준 해설서](https://min24.energy.or.kr/nbuild/RM/GU/boardDetail_03.do?bbsNo=0&category=titl&keyword=&page=1&sn=333)

## S10 · 주차장법 시행규칙 제3조

- 성격: LAW
- 판·위치: 2026-07-27 시행, 국토교통부령 1604
- 확인: 검색 조문 확인
- 원문: [주차장법 시행규칙 제3조](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1029242743)

## S11 · 국가건설기준센터

- 성격: STANDARD
- 판·위치: 조회 2026-09-05
- 확인: KDS/KCS 체계 확인; 세부 전문 확인 아님
- 원문: [국가건설기준센터](https://www.kcsc.re.kr/)

## S12 · CODIL 시방서가 뭔가요

- 성격: GUIDANCE
- 판·위치: 조회 2026-09-05
- 확인: 방수 코드 목록 확인; 세부 최신 수치 미채택
- 원문: [CODIL 시방서가 뭔가요](https://www.codil.or.kr/storyTelling/st08/st08.html)

## S13 · buildingSMART IfcWall

- 성격: STANDARD
- 판·위치: IFC4.3.2.0 IFC4X3_ADD2
- 확인: 의미·레이어 설명 직접 확인
- 원문: [buildingSMART IfcWall](https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/HTML/lexical/IfcWall.htm)

## S14 · buildingSMART IfcMaterialLayer

- 성격: STANDARD
- 판·위치: IFC4.3.2.0
- 확인: 공기층·두께 의미 직접 확인
- 원문: [buildingSMART IfcMaterialLayer](https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/HTML/lexical/IfcMaterialLayer.htm)

## S15 · buildingSMART IfcDoor

- 성격: STANDARD
- 판·위치: IFC4.3.2.0
- 확인: 문·개구부·형식 의미 직접 확인
- 원문: [buildingSMART IfcDoor](https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/HTML/lexical/IfcDoor.htm)

## S16 · Building Topology Ontology

- 성격: GUIDANCE
- 판·위치: 조회 2026-09-05
- 확인: 공식 커뮤니티 문서 열람; 연결 후보
- 원문: [Building Topology Ontology](https://w3c-lbd-cg.github.io/bot/)

## S17 · 에너지 절약형 한옥 모델개발 기획

- 성격: GUIDANCE
- 판·위치: 표2.3.31
- 확인: 공공 연구보고서 검색 표 확인; 전체 직접 대조 미실시
- 원문: [에너지 절약형 한옥 모델개발 기획](https://www.codil.or.kr/filebank/original/RK/OTKCRK220184/OTKCRK220184.pdf)

## S18 · 한국패시브건축협회 PVC 시스템창호 시방서

- 성격: GUIDANCE
- 판·위치: 2021-08-19, 협회 인증건축물 대상
- 확인: 협회 작성·건축사사무소 배포 사본; PDF18쪽/인쇄14쪽 직접 이미지 대조
- 원문: [한국패시브건축협회 PVC 시스템창호 시방서](https://chiho.co.kr/static/download/표준시방서-PVC시스템창호-20210819.pdf)

## S19 · 건축물 구조기준 등에 관한 규칙

- 성격: LAW
- 판·위치: 구조 기준 탐색 경로
- 확인: 구판 정의·개정이유 확인; 현행 상세 수치 미채택
- 원문: [건축물 구조기준 등에 관한 규칙](https://www.law.go.kr/법령/건축물의구조기준등에관한규칙)

## S20 · 설비기준 규칙 제11조

- 성격: LAW
- 판·위치: 2026-08-24 시행, 국토교통부령1614
- 확인: 검색 조문 전체 확인
- 원문: [설비기준 규칙 제11조](https://www.law.go.kr/lsLinkProc.do?ancYd=20161207&joNo=001100002&lsClsCd=L&lsId=2021897&lsNm=건축물의설비기준등에관한규칙&mode=4)

## S21 · 산업안전보건기준 규칙 제55·56조

- 성격: LAW
- 판·위치: 조회 2026-09-05
- 확인: 검색 조문 확인; 전체 표제부 재대조 필요
- 원문: [산업안전보건기준 규칙 제55·56조](https://law.go.kr/lsInfoP.do?ancYnChk=0&lsId=007363)

## S22 · 산업안전보건기준 규칙 제67조

- 성격: LAW
- 판·위치: 2026-03-02 시행, 고용노동부령450
- 확인: 검색 조문 확인
- 원문: [산업안전보건기준 규칙 제67조](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1020912307)

## S23 · W3C SHACL

- 성격: STANDARD
- 판·위치: W3C Recommendation 2017-07-20
- 확인: 공식 문서 열람; 데이터 검증 참조
- 원문: [W3C SHACL](https://www.w3.org/TR/shacl/)

## S24 · W3C PROV-O

- 성격: STANDARD
- 판·위치: W3C Recommendation 2013-04-30
- 확인: 공식 문서 열람; 출처 모델 참조
- 원문: [W3C PROV-O](https://www.w3.org/TR/prov-o/)

## S25 · W3C SKOS Reference

- 성격: STANDARD
- 판·위치: W3C Recommendation 2009-08-18
- 확인: 공식 문서 열람; 용어 모델 참조
- 원문: [W3C SKOS Reference](https://www.w3.org/TR/skos-reference/)

## S26 · W3C SSN/SOSA

- 성격: STANDARD
- 판·위치: 조회 2026-09-05
- 확인: 공식 문서 열람; 관측 모델 참조
- 원문: [W3C SSN/SOSA](https://www.w3.org/TR/vocab-ssn/)

## S27 · 크나우프 KND-12DB 인정서

- 성격: PRODUCT
- 판·위치: FR-WS23-0109-2, 2024-07-09, 유효기한 표기 2028-01-08
- 확인: 제조사 PDF1쪽 이미지 직접 대조; 취소·변경 실시간 미조회
- 원문: [크나우프 KND-12DB 인정서](https://knauf.com/api/download-center/v1/assets/6b357738-a26a-4a9a-9794-950b7b8011dc?download=true&country=kr&locale=ko-KR&tenant=knauf)

## S28 · 크나우프 KND-19DB 인정서

- 성격: PRODUCT
- 판·위치: FR-WS23-0109-6, 2024-07-09, 유효기한 표기 2028-01-08
- 확인: 제조사 PDF1쪽 이미지 직접 대조; 취소·변경 실시간 미조회
- 원문: [크나우프 KND-19DB 인정서](https://knauf.com/api/download-center/v1/assets/760aaa30-20a3-4766-8c1d-e71266b53c3d?download=true&country=kr&locale=ko-KR&tenant=knauf)

## S29 · 영림 2026-27 종합카탈로그 2판

- 성격: PRODUCT
- 판·위치: 표지 2026-27 종합카탈로그
- 확인: PDF19쪽/인쇄32~33쪽 직접 이미지 대조; 다운로드 TLS 검증 우회 이력으로 원본 재확인 필요
- 원문: [영림 2026-27 종합카탈로그 2판](https://www.yl.co.kr/download/26-27%20%E1%84%8B%E1%85%B5%E1%86%B7%E1%84%8B%E1%85%A5%E1%86%B8%20%E1%84%8C%E1%85%A9%E1%86%BC%E1%84%92%E1%85%A1%E1%86%B8%20%E1%84%8F%E1%85%A1%E1%84%90%E1%85%A1%E1%86%AF%E1%84%85%E1%85%A9%E1%84%80%E1%85%B3%202%E1%84%91%E1%85%A1%E1%86%AB.pdf)

## 사용·보존 경계

본문은 요약·합성이며 전문 복제물이 아니다. 원문 PDF 일부는 재현·표 대조를 위한 실행기록에 보존했다. S18은 협회 작성 원문의 제3자 배포 사본이다. S29는 Aside가 제조사 서버에서 받은 파일을 직접 읽었으나 다운로드 TLS 검증 우회 이력이 있어 승인용 원본으로 자동 사용하지 않는다. S01·S11·S12·S19는 탐색 경로로서 세부 수치 직접 증거로 확대하지 않는다. 모든 실제 사업 적용은 부칙·시방·인정 상태를 별도로 확인한다.

## 보존 원문

PDF 6건의 불변 사본과 SHA-256: 2026-09-05-korean-construction-source-snapshots (배포에 포함하지 않은 내부 기록). 웹 조회 30건 모두의 전체 페이지를 보존했다는 뜻은 아니다. [sources.json](sources.json)에 snapshotPath가 있는 출처만 원문 사본이 있다.

## v0.2 계약 근거 통합

기존 S01~S29(S04b 포함) 30건을 유지하고 [20-residential-drawing-3d-requirements](20-residential-drawing-3d-requirements.md)의 R01~R09를 sources.json에 통합했다. BIM 지침 게시물·첨부 존재 확인을 PDF 전문 검토로 승격하지 않았으며 R07~R09도 확인한 조문 범위를 유지했다.

- R10: [W3C SHACL](https://www.w3.org/TR/shacl/) — RDF 데이터 제약.
- R11: [JSON Schema 2020-12 Core](https://json-schema.org/draft/2020-12/json-schema-core) — 모델 JSON 스키마 방언.
- R12: [W3C JSON-LD 1.1](https://www.w3.org/TR/json-ld11/) — RDF의 JSON 표현.

세 공식 본문은 2026-09-05 확인했다. 총 42개 출처 레코드는 같은 문서의 다른 확인 목적도 포함한다. 법규 숫자를 이번 구현에서 새로 확대 추출하지 않았다. 카드·관계·검사 기준은 작성자 정의이며 이 표준들이 한국 주택 치수를 정한다는 뜻이 아니다.

## v0.3 법령 재검토 출처

S01·S05·S06·R07의 미확정 표시는 초기 확인 이력이다. 후속 직접 대조는 아래 L 계열과 [25 적용 조건](25-residential-legal-conditions.md)에 기록했다. 기존 레코드의 확인 범위를 소급 변경하지 않는다.

- L01 · [건축법 시행령 별표 1 주거 분류](https://www.law.go.kr/LSW/lsBylInfoP.do?bylSeq=18390265&lsiSeq=288339&efYd=20260728&directYn=Y) — 2026-07-28 대통령령 제36541호; 별표 개정 표지 2025-10-01; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L02 · [주택건설기준 규정 제3조·제7조·제13조·제14조·제14조의2](https://www.law.go.kr/법령/주택건설기준등에관한규정/(20260630,36475,20260630)/제14조의2) — 2026-06-30 대통령령 제36475호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L03 · [주택건설기준 규칙 제3조·제3조의2](https://www.law.go.kr/법령/주택건설기준등에관한규칙/(20260729,01605,20260729)/제3조) — 2026-07-29 국토교통부령 제1605호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L04 · [피난방화구조규칙 제16조](https://www.law.go.kr/법령/건축물의피난ㆍ방화구조등의기준에관한규칙/(20251031,01531,20251031)/제16조) — 2025-10-31 국토교통부령 제1531호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L05 · [건축법 시행령 제50조·제119조](https://www.law.go.kr/법령/건축법시행령/(20260728,36541,20260728)/제50조) — 2026-07-28 대통령령 제36541호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L06 · [2026 라멘 공업화주택 성능예외 개정 부칙](https://www.law.go.kr/법령/주택건설기준등에관한규정/(20260506,36308,20260506)/부칙) — 2026-05-06 대통령령 제36308호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인
- L07 · [2022 바닥충격음 개정 경과조치](https://www.law.go.kr/법령/주택건설기준등에관한규정/(20220804,32851,20220804)/부칙) — 2022-08-04 대통령령 제32851호; 국가법령정보센터 원문·관련 조문·부칙 직접 대조; 프로젝트 적용 미확인

- L08 · [건축법 시행령 제53조제2항 소규모 층간바닥](https://www.law.go.kr/법령/건축법시행령/제53조) — 2026-07-28 대통령령 제36541호; 공식 원문 직접 확인; 개별 사업 적용 미확인
- L09 · [피난방화구조규칙 제19조제3·4항](https://www.law.go.kr/법령/건축물의피난ㆍ방화구조등의기준에관한규칙/제19조) — 2025-10-31 국토교통부령 제1531호; 공식 원문 직접 확인; 개별 사업 적용 미확인
- L10 · [소음방지를 위한 층간 바닥충격음 차단 구조기준](https://www.law.go.kr/LSW/admRulInfoP.do?admRulSeq=2100000156789) — 2018-09-21 국토교통부고시 제2018-585호; 제2~4조·별표1·부칙; 공식 원문 직접 확인; 고시 별표 텍스트·표 이미지 대조; 개별 사업 적용 미확인
- L11 · [법제처 26-0462 용도변경과 소음방지기준](https://opinion.lawmaking.go.kr/nl4li/lsItptEmp/451625?mode=all) — 회신 2026-09-03; 기존건축물 특례 비적용 사안; 공식 원문 직접 확인; 개별 사업 적용 미확인
