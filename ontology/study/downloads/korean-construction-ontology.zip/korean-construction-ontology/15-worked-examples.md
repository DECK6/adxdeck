---
description: "Korean construction ontology foundation: 15-worked-examples."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: concept
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 온톨로지 적용 사례와 기대 결과

모든 건물·측정 데이터는 가상이다. 아래 결과는 패키지 규칙을 설명하는 논리 예제이며 실제 건축물 판정 결과가 아니다.

## 사례 A: 서울 외단열 RC 벽

조건: 서울·중부2, 공동주택 외의 해당 거실 외벽, 외기 직접, S09 확인판 적용을 별도로 확정했다고 가정. 목표 U≤0.240. 벽 375mm라는 총두께만 있음.

결과: U 계산은 UNKNOWN. 각 레이어 λ·두께·표면저항·병렬 열교 등 필요한 입력이 없다. 총두께가 크다는 이유로 PASS를 만들지 않는다. ‘서울의 모든 벽 U≤0.170’도 공동주택 여부를 생략한 오류다.

## 사례 B: 공동주택 슬래브

적용 범위·판본 확정, 화장실 아님, 벽식 RC, 예외 아님, 구조두께 200mm, 바닥 총두께 330mm.

FLOOR-001 두께 요구는 FAIL. 330mm는 구조 슬래브 두께가 아니다. 두께를 210mm로 바꾸면 해당 두께 항목만 PASS이며 충격음 요구는 시험·구조 근거 없으면 UNKNOWN이다. 무량판이면 라멘 150mm 예외로 자동 전환하지 않는다.

## 사례 C: 900mm 문짝

문짝 폭 900mm, 유효폭 미측정, 적용 대상 접근성 출입구라고 가정.

결과: UNKNOWN. leafWidth를 clearOpeningWidth로 복사할 수 없다. 실제 유효폭 892mm이고 규칙판 적용까지 확정되면 900mm 최소 요구는 FAIL. 문틀 외경·개구부만 넓혀도 최종 유효폭·활동공간을 다시 봐야 한다.

## 사례 D: 경량벽 단열 중복

보드 12.5mm씩 양면, 스터드 영역 75mm, 동일 영역에 단열 75mm.

직렬 총두께: 12.5+75+12.5=100mm. 175mm라는 합계는 잘못이다. 스터드·단열은 동일 영역의 하위 구성이다. 100mm라는 산술을 내화 1시간 인정으로 연결해서도 안 된다. 특정 보드·스터드·상세의 인정 근거가 필요하다.

## 사례 E: 무단차 욕실

휠체어 경로에는 단차 제거 요구가 있지만 욕실 방수·배수 상세는 없음.

결과: 접근성 요구와 방수 요구를 함께 검토할 설계 문제. ‘턱 50mm 추가’는 작성자 임의 처방이며 접근성 문제를 만들 수 있다. 구조 레벨·배수구·문 하부·방수층을 통합 설계한 증거가 들어올 때까지 해결 상태는 UNKNOWN.

## 사례 F: 기울기와 경로

높이차 450mm, 수평길이 4,000mm → 구배 11.25% ≈ 1:8.89. 일반 1:12 적용이 확정된 경사로라면 FAIL. 길이 5,400mm이면 경사 항목만 PASS. 시작·끝·참·폭·문 회전 영역은 별도 항목이다.

## 사례 G: 구판과 신판

검색에서 주차 일반형 폭 2,300mm와 2,500mm가 함께 나옴.

서로 다른 판본의 규칙으로 저장한다. 2026년 확인판 평행주차 외 일반형은 2,500mm지만 기존 사업 경과조치를 확인하지 않은 상태에서는 프로젝트 판정 UNKNOWN이다. 숫자가 작다는 이유로 구판을 삭제하지 않는다.

## 사례 H: 제품명만 있는 내화벽

제품명이 ‘방화석고보드’이고 벽체가 100mm.

결과: 내화시간 UNKNOWN. KND-12DB와 같은 특정 인정 시스템을 실제로 채택하고 보드·스터드·접합·시공·유효상태까지 대조해야 한다. 100mm는 제품 시스템 치수와 맞을 수 있지만 단독 성능 증거가 아니다.

## 사례 I: 변경 영향

층고는 유지하고 천장 속 덕트 높이를 늘림.

Change → 천장 하강 → ceilingHeight·clearHeadroom 영향 → 문·점검구·스프링클러·감지기·설비 접근 재검토. 이전 판정은 stale로 표시하고 새로운 설계판에 재연결한다.

## 사례 J: 젖은 창대

비가 오지 않는 추운 날 실내 습도가 높을 때 발생.

결로 가설을 만들 수 있으나 확정하지 않는다. 외부 강우·배관·표면온도·실내 습도·기밀 누설 등의 근거와 시험을 연결한다. 증상→원인→보수 사이의 미확인 단계를 보존한다.

## 완성 인스턴스 예제

```yaml
project:
  id: EX-PROJECT-01
  location: Seoul
  energyRegion: central2
  legalUse: non_apartment
  permitApplicationDate: null
  ruleEditionApplicability: unknown
wall:
  id: EX-WALL-01
  type: Wall
  external: true
  loadBearing: unknown
  exposure: direct_outdoor
  assembly: EX-ASM-01
assembly:
  id: EX-ASM-01
  direction: interior_to_exterior
  compositionMode: serial
  layers:
    - {id: EX-L01, order: 1, material: interior_finish, thicknessMm: 15}
    - {id: EX-L02, order: 2, material: reinforced_concrete, thicknessMm: 200}
    - {id: EX-L03, order: 3, material: insulation_unspecified, thicknessMm: 150}
    - {id: EX-L04, order: 4, material: exterior_finish_system, thicknessMm: 10}
  totalThicknessMm: 375
assessment:
  id: EX-ASSESS-01
  rule: THERMAL-002
  result: UNKNOWN
  missing: [permit_rule_edition, material_conductivities, thermal_calculation]
  isWholeBuildingApproval: false
```

이 예제에는 일부러 입력 누락을 남겼다. 근거가 없는 값을 모델이 자동으로 채우지 않고 필요한 질문을 만들 수 있어야 한다.

## v0.2 기계가 검증하는 주거 예제

위의 축약 YAML·계산 예제는 설명 자료다. 아래 JSON이 v0.2 스키마 검증 대상이다.

| 예제 | 입력 범위 | 확인할 관계 |
|---|---|---|
| [detached.json](examples/detached.json) | 단독주택 신축 개념안 | 가상 대지·규제 미확정·프로그램·구조·설비 |
| [villa.json](examples/villa.json) | 다세대 세대 복원 | 통칭/법정 용도·공용 샤프트·세대 경계 |
| [apartment.json](examples/apartment.json) | 아파트 세대 복원 | 발코니 전후·문창 호스트·치수 충돌·부분 변경 |

**세 파일은 동일한 합성 형상 조각을 세 프로필에 적용한 계약 예제다. 독립 주택 3건이나 완성된 평면도가 아니다.** 벽 200mm·개구부 1,000×2,200mm·높이 후보 등은 작성자 가정이며 한국 주택의 전국 표준 치수가 아니다.

창대와 창 높이는 미상이고 두 천장고 후보는 충돌 상태다. 계약 검증을 통과해도 완전한 솔리드를 생성할 정보는 부족하다. 이 사례는 모르는 값을 올바르게 표현했으므로 데이터 계약을 통과한다.

벽 두께 변경은 관련 도면·일람표·표현을 stale로 만든다. 문 이동은 같은 Opening의 호스트 거리만 바꾸고 과거 개구부 객체를 복제하지 않는다. 실제 CAD 절개와 도면 재렌더링은 후속 엔진의 책임이다.
