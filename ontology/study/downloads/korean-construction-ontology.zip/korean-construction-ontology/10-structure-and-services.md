---
description: "Korean construction knowledge and ontology: 10-structure-and-services."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 구조·설비·마감의 간섭

## 구조 치수는 설계 결과다

기둥·보·슬래브·기초 크기, 철근 지름·간격·정착·피복은 부재별 구조조건에 따라 결정한다. 보편 배근표나 기초 두께표는 제공하지 않는다. 하중·스팬·재료강도·내진·처짐·진동·지반·내구성·내화·시공조건을 입력하고 구조계산·상세와 연결한다. 공식 기준 경로: S11·S19.

| 입력 누락 | 영향 | 관계 |
|---|---|---|
| 무거운 마감·장비 변경 | 고정하중 변화 | Change changes LoadCase |
| 큰 무주공간 | 스팬·처짐·진동 | Beam spansBetween Supports |
| 현장 보·벽 타공 | 하중 경로·철근 | Opening requires StructuralReview |
| 배관 집중 | 배근·피복·매립 간섭 | Service clashesWith RebarZone |
| 외장 앵커 | 풍하중·지진·열교 | Anchor transfersLoadTo Substrate |
| 기존 도면 부재 | 현재 구조 불확실 | Element supportedBy Survey |

비내력벽이라는 이유만으로 철거 가능을 확정하지 않는다. 방화구획·차음·설비·비구조요소 고정 조건도 남는다.

## 환기 규정 확인

설비기준 규칙 제11조 확인판 시행 2026-08-24(S20): 신축·리모델링하는 30세대 이상 공동주택 및 주택 30세대 이상인 해당 복합건축물은 **0.5회/h 이상** 환기 가능한 자연·기계환기설비 대상이다. 30세대 미만 등의 권장 경로와 다중이용시설의 별도 인원당 환기량을 구분한다.

가상 체적 200m³에 0.5h⁻¹이면 100m³/h다. 기기 명목 풍량만으로 실제 덕트 저항·말단 풍량·소음·균형을 입증하지 않는다. 주방 배기·기본 환기·연소 공기는 다른 기능이다. [제11조](https://www.law.go.kr/lsLinkProc.do?ancYd=20161207&joNo=001100002&lsClsCd=L&lsId=2021897&lsNm=건축물의설비기준등에관한규칙&mode=4)

## 천장 속 공간

보 하부, 덕트 보온·플랜지, 배관 구배·행거, 케이블 트레이, 천장틀·조명·스프링클러까지 공간을 차지한다. 장비 외형에 더해 설치 여유, 점검 여유, 필터·장비 반출 경로를 모델링한다. 점검구가 있다는 사실은 교체 가능하다는 증거와 다르다.

방화구획 관통은 내화채움·댐퍼와 연결한다(S05 제14조). 기밀용 폼이나 보통 실란트로 채웠다는 사실을 내화성능 입증으로 쓰지 않는다.

## 흔한 설치높이의 취급

콘센트 300mm, 스위치 1,200mm 등을 모든 공간의 법정값으로 저장하지 않는다. 사용자의 도달, 가구·문, 습윤부, 접근성 대상과 제품 지침으로 정한다. 배수관 구배·관경, 보온, 전선용량, 가스·소방 간격은 실제 시스템 없이는 unknown이다.

무거운 가구·TV·손잡이는 보강 위치와 하중을 마감 전에 계획한다. 천장·칸막이 변경은 구조·소방·접근성 영향 재검토로 전파한다.
