---
description: "Source-scoped Korean construction knowledge and ontology foundations: 05-doors-and-openings."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 문 규격·유효폭·문틀·방화문

## 표준 문 크기는 단일 법정값이 아니다

문은 주문 가능한 문짝 치수, 문틀 외경, 골조 개구부, 실제 통과 폭을 갖는다. ‘900×2,100 문’이라고만 기록하면 어느 치수인지 알 수 없다. 이 버전은 특정 제조사의 확인된 제품 규격과 작성자 계획 예제를 구분한다. 제품 자료는 [19-product-and-practice-evidence](19-product-and-practice-evidence.md)를 참조한다.

| 계획 예제 | 문짝 폭×높이, mm | 상태 |
|---|---|---|
| EX-D01 실내 여닫이 | 800×2,100 | 작성자 모델링 예제; 시장 표준·법정치 주장 아님 |
| EX-D02 넓은 실내문 | 900×2,100 | 같은 조건; 유효폭 900을 보장하지 않음 |
| EX-D03 높은 문 | 900×2,300 | 제조사 제작 범위·보강·하드웨어 확인 필요 |

예제를 실무 관행으로 승격하려면 제조사 발주표·문 일람표의 실제 채택 사례가 필요하다. 접근성 요구가 있는 문에는 예제 문짝 치수부터 고르지 말고 필요한 유효폭에서 개구부·문틀·문짝을 역산한다.

## 접근성 문에 관한 확인값

장애인등 편의증진법 시행규칙 별표 1 제6호의 **2023-12-11 개정 PDF 확인판**: 출입구 통과유효폭 900mm 이상, 전면 유효거리 1,200mm 이상, 비자동문 옆 활동공간 600mm 이상. 연속문은 개폐 공간을 전면 유효거리에 산입하지 않는다. 경기용 휠체어용 해당 체육시설 출입구에는 1,200mm 기준이 별도로 있다. **최신 별표 연결 및 대상시설·경과조치는 미확정**이다. S07, PDF 3~4쪽.

문턱은 없도록 하며 방화문 등 불가피한 경우 높이차 20mm 이하 예외가 있다. 이를 모든 문에 턱 20mm를 권장하는 규칙으로 바꾸지 않는다. [확인한 별표](https://www.law.go.kr/LSW/flDownload.do?bylClsCd=110201&flSeq=135226913)

## 문 주변에서 동시에 풀어야 하는 문제

| 검토 | 왜 중요한가 | 남길 증거 |
|---|---|---|
| 열림 방향·회전 영역 | 피난·가구·휠체어 활동공간 간섭 | 문 일람표와 평면 중첩 |
| 문틀 고정 바탕 | 경량벽에 반복 개폐 하중 전달 | 보강 상세·앵커 규격 |
| 마감 후 하부 여유 | 바닥 추가 마감·문 처짐·차음 충돌 | 바닥 레벨·하드웨어 상세 |
| 도어클로저·힌지·잠금 | 개방 힘, 자동 폐쇄, 비상 운영 | 제품 조합 및 시험·인정 자료 |
| 유리문 인지·안전 | 충돌·파손·시인성 | 유리 종류와 표시 상세 |
| 방수·기밀 | 외부문 하부 빗물·누기 | 배수·문턱·기밀 연속 상세 |
| 방화문 | 문짝만 바꾸어 성능을 주장할 수 없음 | 문틀·철물·씰·벽체 포함 인정·설치 조건 |

방화구획에 쓰는 방화문의 폐쇄 방식과 관통부 내화채움은 피난방화규칙 제14조에서 확인한다(S05). ‘항상 문을 열어 두되 소화기가 가까우면 된다’는 관행은 대체 근거가 아니다. 방화문 분류·등급·인정 상세는 프로젝트에서 별도 확인한다.

## 온톨로지 연결

`Opening voidsElement Wall`; `Door fillsOpening Opening`; `Door hasLeaf Leaf`; `Door hasFrame Frame`; `Door connectsSpace Space`; `ClearanceZone serves Door`. 문과 개구부를 동일 객체로 만들지 않는다. IFC 매핑에서도 외곽 폭을 통과유효폭으로 단순 복사하지 않는다. 실제 통과 치수는 별도 속성·측정 결과로 보존한다.
