---
description: "Korean construction ontology foundation: 13-ontology-schema."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: concept
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 건설 온톨로지 개념·관계·검증 설계

## 설계 목표

v0.3은 **기계가 읽고 검증할 수 있는 주거 모델 어휘·관계·데이터 계약**이다. [vocabulary.json](vocabulary.json)에 클래스 116개, 객체 관계 106개, 데이터 속성 108개를 정의하고 [ontology.ttl](ontology.ttl), [JSON Schema](schemas/residential-model.schema.json), [shapes.ttl](shapes.ttl)을 생성한다. 아래 핵심 사전을 유지했으며 확장 전체는 [24 어휘 참조](24-vocabulary-reference.md)에 싣는다. 법규 적합 판정기나 CAD 형상 엔진의 완성 구현은 아니다.

부재 객체에 thickness=200만 붙이는 방식에서 벗어나, 조립체·층·기준면·요구·설계값·관측값·근거·적용 맥락을 분리한다. 아래 클래스와 관계는 작성자 제안이며 국내 공인 온톨로지라고 주장하지 않는다.

## 클래스 사전

| 클래스 | 한국어 | 정의·경계 |
|---|---|---|
| Project | 사업 | 승인·설계·시공의 관리 단위 |
| ProjectContext | 적용 맥락 | 지역·용도·규모·날짜·절차 묶음 |
| Site | 대지 | 법적 경계·지형·접근 조건 |
| Building | 건축물 | 건물 객체 |
| Storey | 층 | 기준 레벨을 가진 공간 집합 |
| Space | 공간 | 실·홀·복도 등 공간 |
| Zone | 구역 | 방화·열·설비 등 목적별 영역 |
| Route | 경로 | 순서 있는 이동 구간 |
| RouteSegment | 경로 구간 | 폭·경사·높이를 가진 구간 |
| BuildingElement | 건축 부재 | 물리적 건물 구성 요소 |
| Wall | 벽 | 경계를 이루는 부재; 내력은 별도 역할 |
| Slab | 슬래브 | 바닥 등의 구조 판 |
| Roof | 지붕 | 상부 외피 |
| Column | 기둥 | 수직 구조 부재 |
| Beam | 보 | 하중 전달 부재 |
| Foundation | 기초 | 상부 하중을 지반에 전달 |
| Opening | 개구부 | 부재에 생긴 열린 공간 |
| Door | 문 | 개구부 출입을 제어하는 조립 부재 |
| Window | 창 | 외피 등의 개구부에 설치되는 부재 |
| Stair | 계단 | 높이차 이동 시설 |
| Ramp | 경사로 | 경사면 이동 시설 |
| Railing | 난간 | 가장자리 추락 방지 부재 |
| Handrail | 손잡이 | 사람이 잡는 부재 |
| Assembly | 조립체 | 역할을 수행하는 구성 요소의 조합 |
| Layer | 레이어 | 순서·방향·두께를 가진 층 |
| Material | 재료 | 물질·제품 재료의 종류 |
| ProductType | 제품 형식 | 제조사·제품코드로 식별한 카탈로그 대상 |
| ProductBatch | 자재 로트 | 납품·검사 가능한 실제 묶음 |
| Junction | 접합부 | 부재·층·시스템의 만남 |
| Penetration | 관통부 | 배관 등의 통과로 생기는 부분 |
| BuildingService | 설비 | 환기·급배수·전기·소방 등 |
| ClearanceZone | 여유 공간 | 통과·작동·점검·반출 공간 |
| Datum | 기준면·기준선 | 치수의 원점과 경계 |
| Quantity | 수량·치수 | 값·단위·속성·기준·상태 |
| Requirement | 요구 | 특정 조건에서 요구되는 명제 |
| Rule | 규칙 | 적용조건과 검사항목의 구조화 |
| ApplicabilityCondition | 적용조건 | 삼값 논리로 평가할 조건 |
| Exception | 예외 | 특정 조항을 달리 적용하는 조건 |
| SourceDocument | 출처 문서 | 법령·시방·제품·기술 문서 |
| SourceEdition | 문서 판 | 시행·발행일 및 판 식별 |
| Provision | 조항 | 조·항·호·별표 또는 쪽·표 |
| Evidence | 근거 | 주장과 출처·관측을 잇는 증거 |
| Observation | 관측 | 실측·시험·검사에서 얻은 사실 |
| Assessment | 판정 | 규칙판·입력판·결과·판정시각 |
| InstallationActivity | 시공 작업 | 누가 언제 어떤 상세로 시공했는가 |
| Inspection | 검사 | 시공 상태의 확인 행위 |
| Change | 변경 | 설계·제품·공정의 리비전 변경 |
| Defect | 결함 | 관찰되거나 확인된 성능·품질 문제 |
| Hypothesis | 원인 가설 | 관찰을 설명하는 검증 전 명제 |
| PracticeCandidate | 암묵지 후보 | 조건·반례·검증 상태 있는 현장 지식 |

외벽/내벽/내력/방화/차음은 상호 배타적인 단일 분류가 아니다. 한 벽이 여러 역할을 동시에 가진다. Layer는 Material의 하위종이 아니고 특정 위치의 층이 Material을 사용한다. Rule과 Observation도 물리적 BuildingElement의 하위종이 아니다.

## 핵심 관계

| 관계 | 주어 → 목적어 | 의미·제약 |
|---|---|---|
| hasContext | Project → ProjectContext | 적용 판단 입력 |
| containsSpace | Building/Storey/Zone → Space | 공간 포함 |
| containsElement | SpatialObject → BuildingElement | 위치·소속 |
| boundsSpace | BuildingElement → Space | 경계; 단순 포함과 다름 |
| adjacentTo | Space → Space | 인접; 통행 가능을 뜻하지 않음 |
| connectsSpace | Door → Space | 출입 연결 후보; 문 상태도 필요 |
| fillsOpening | Door/Window → Opening | 개구부와 삽입 부재 분리 |
| voidsElement | Opening → BuildingElement | 어느 부재의 개구부인가 |
| hasAssembly | BuildingElement → Assembly | 실제 구성 |
| hasLayer | Assembly → Layer | 층 순서는 layerOrder 속성으로 보존 |
| usesMaterial | Layer → Material | 해당 층 재료 |
| occupiesZone | Component → Layer/Volume | 스터드·충진재 중복두께 방지 |
| hasQuantity | Object → Quantity | 값·단위·기준·상태 |
| measuredFrom | Quantity → Datum | 기준면 |
| joins | Junction → BuildingElement | 접합 대상 |
| penetrates | Penetration → BuildingElement/Zone | 관통 대상 |
| sealedBy | Junction/Penetration → Assembly | 씰 시스템 |
| drainsTo | Surface/Drain → Drain/Outlet | 물 흐름 |
| hasClearance | Object → ClearanceZone | 통과·작동·정비 공간 |
| appliesUnder | Rule → ApplicabilityCondition | 적용조건 |
| hasException | Rule → Exception | 예외 |
| requires | Rule → Requirement | 요구값·성능 |
| derivedFrom | Rule/Evidence → Provision | 조항 단위 근거 |
| inEdition | Provision → SourceEdition | 판본 고정 |
| documentedBy | SourceEdition → SourceDocument | 출처 식별 |
| assesses | Assessment → Object | 판정 대상 |
| evaluatesRule | Assessment → Rule | 규칙 ID+버전 |
| supportedBy | Assessment/Claim → Evidence | 근거 |
| supersedes | SourceEdition/Rule → 이전 판 | 단방향 갱신 이력 |
| precedes | Activity/Inspection → Activity | 선후 공정 |
| affectedBy | Object/Assessment → Change | 변경 영향 |
| explains | Hypothesis → Observation/Defect | 가설, 확정원인 아님 |
| tests | Inspection/Test → Hypothesis/Requirement | 판정 방법 |
| hasSegment | Route → RouteSegment | 순서는 명시 속성 |

관계에 여러 주어 타입을 썼다는 이유로 RDF rdfs:domain을 여러 번 선언하지 않는다. 여러 domain은 교집합 추론이므로 의도한 합집합과 다를 수 있다. 상위 클래스 또는 명시적 union 설계가 필요하다.

## 외부 표준과 연결

| 표준 | 재사용 영역 | 이 패키지의 연결 방침 |
|---|---|---|
| IFC 4.3.2.0 | 벽·문·슬래브·개구부·재료층 교환 | 클래스 의미를 검토한 매핑; 자동 동치 선언 금지 |
| BOT | Site·Building·Storey·Space와 토폴로지 | 건물 공간관계에 재사용 후보 |
| SKOS | 용어·동의어·분류 | 한국어 표준어와 현장어를 label로 연결 |
| PROV-O | 출처·생성·책임·파생 | 규칙 추출·판정의 출처 추적 |
| SOSA/SSN | 관측·대상·속성·절차 | 실측·센서·시험 기록 |
| SHACL | 데이터 그래프 제약 | 필수 단위·기준면·근거·형식 검증 |

공식 근거: S13~S16·S23~S26. BOT는 W3C 커뮤니티 그룹 작업이며 W3C Recommendation 법적 지위를 가진 표준이라고 표현하지 않는다. IFC는 정보 교환 스키마이지 한국 법규 적합 증명 자체가 아니다. OWL 분류 추론과 수치·데이터 유효성 검증은 목적이 다르다.

## 판정의 5가지 결과

- PASS: 확정된 적용 규칙과 비교 가능한 입력으로 해당 요구만 충족.
- FAIL: 확정된 적용 규칙의 해당 요구를 불충족.
- UNKNOWN: 적용조건·판본·입력·측정기준·증거 중 필요한 것이 빠짐.
- NOT_APPLICABLE: 적용 제외가 긍정적 근거로 확인됨.
- CONFLICT: 적용판·요구·동일 상태 관측이 상충하여 정리가 필요함.

법규 하나의 PASS를 건물 전체 ‘적법·안전’으로 확대하지 않는다. 원문 직접 확인과 해당 사업 적용 승인은 다른 상태다. legalApplicabilityVerified=false인 규칙을 현행 사업 적합 자동판정에 사용하지 않는다.

## 검증 제약 명세

1. Quantity에는 propertyTerm·value·unit·basis·evidenceStatus·approvalStatus·lifeCycleStage·uncertainty·validityStatus와 quantitySubject가 필수다.
2. 레이어 layerOrder는 조립체 내에서 중복되지 않으며 실내→실외 등 direction이 필요하다.
3. 병렬 영역은 두께를 직렬 합산하지 않는다. 최소한 compositionMode를 기록한다.
4. 법령 규칙은 출처·조항·확인판·예외·적용시점 상태가 필요하다.
5. 제품 성능은 제품코드·인정번호·구성·유효기간·확인상태에 연결한다.
6. 측정 누락은 0이 아니다. UNKNOWN을 유지한다.
7. 설계값과 준공 실측을 하나의 단일 속성으로 덮어쓰지 않는다.
8. 치수 변경은 관련 판정을 stale로 만들고 재평가한다.
9. 검색 요약만 확인한 출처는 direct_read로 승격하지 않는다.
10. 암묵지 후보는 법령 등급으로 자동 변환하지 않는다.


## 확장 어휘와 계층 선언 방침

위 50개 핵심 클래스와 34개 핵심 관계를 보존했다. 다음 보조 어휘도 v0.3 어휘·OWL·스키마에 실제 선언했다. 이름이 다른 관계를 임의의 동의어로 합치지 않는다.

| 보조 어휘 | 처리 |
|---|---|
| Object, SpatialObject, Component | 추상 상위 타입; SpatialObject 아래 Site·Building·Storey·Space·Zone, Component 아래 물리 구성요소 |
| Volume, Surface, Drain, Outlet, Edge | 공간·배수·가장자리 상세 확장 타입 |
| Function, Role | 단열·기밀·내력 등 기능/역할 개념; SKOS 개념으로도 모델링 가능 |
| Leaf, Frame, Flight, DoorSwing | 문짝·문틀·계단참 사이 경사부·문 개폐 영역의 상세 타입 |
| Claim, Test, Activity | 주장·시험·행위 상위 타입; InstallationActivity는 Activity의 하위 타입 |
| Concealment, Handover | 은폐·인계 행위 타입 |
| DeliveryInspection, ConcealedInspection | Inspection 하위 타입 |
| hasFunction, hasLeaf, hasFrame, hasFlight | 부재의 기능·부분 구성을 위한 확장 관계 |
| serves, protects, intersects, establishedBefore | 서비스 대상·추락보호·간섭·기준 설정의 확장 관계 |

로컬 이름공간은 `urn:akm:construction:`이며 공인 한국 표준을 뜻하지 않는다. 인스턴스 IRI는 여기에 `instance:<ID>`를 붙인다. 설명 장의 과거 축약 YAML은 v0.3 유효 JSON으로 자동 간주하지 않으며 이행 규칙에 따라 변환한다.

## 주거·도면·형상 확장 구조

| 묶음 | 핵심 연결 |
|---|---|
| 범위 | Project → hasBrief → DesignBrief; ProjectContext → hasProfile → ResidentialProfile |
| 주거 | Building → hasUnit / hasCommonArea; ResidentialUnit → containsSpace; Space의 ownershipScope |
| 대지 | Site → hasBoundary → ParcelBoundary; hasRegulatoryEnvelope; basedOnSurvey |
| 형상 | Wall → hasPlacement / hasGeometry; Placement → relativeTo; Opening → voidsElement / hasHostFace |
| 치수 | Opening → widthQuantity / heightQuantity / offsetQuantity / baseHeightQuantity → Quantity → measuredFrom → Datum |
| 관측 | DrawingDocument → DrawingSheet → DrawingView → DimensionAnnotation / Tag → 원 객체 |
| 근거 | Quantity → hasInference / hasEvidence / hasApproval; ReconstructionIssue → candidateQuantity |
| 산출물 | ModelRevision ← derivedFromRevision ← DrawingArtifact / SolidRepresentation / Schedule |
| 변경·교환 | supersedes로 이전 판 보존; dependsOn으로 영향 추적; ExchangeMapping에 판·ID 대응·손실·검사 결과 |

DrawingView는 원 도면의 관측 뷰도 표현한다. 생성 도면은 DrawingArtifact가 showsView로 연결한다. 원 도면을 생성 결과처럼 취급하지 않는다.

레이어는 hasLayer 배열 순서가 아닌 layerOrder로 정렬한다. 좌표·다각형 점·행렬 내부 순서는 보존한다. JSON 객체 관계 배열은 RDF 집합 의미라서 순서 비교 대상이 아니다.

evidenceStatus는 관측·실측·계산·가정·미상이고 approvalStatus는 미확정·제안·검토·승인·반려다. 승인과 실측은 서로 대체할 수 없다. 승인 레코드 존재 검사가 승인자의 자격·내용 진실성을 보증하지는 않는다.
