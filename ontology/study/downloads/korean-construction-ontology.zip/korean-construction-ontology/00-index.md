---
description: "Entry point for source-scoped Korean building rules, construction assemblies and ontology foundations."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 한국 주거 건축·건설 온톨로지 v0.3

**조사·정리 기준일: 2026-09-05.** 벽체·문·창호·층고·바닥에서 출발해 접근성·계단·주차·방수·설비·가설 안전까지 연결한 Markdown 지식 패키지다. 법령, 고시, 표준 탐색 경로, 제품 인정서, 실무 판단을 출처와 적용 조건으로 구분했다.

v0.3은 기존 **핵심 클래스 50개·핵심 관계 34개·참고 규칙 69개**를 보존하고, 총 **클래스 116개·객체 관계 106개·데이터 속성 108개**의 주거 모델로 확장했다. Markdown에 RDF/OWL, JSON Schema, SHACL, 조건식, 부품 템플릿과 합성 검증 예제를 연결했다. 완성된 주택 설계·도면 복원 엔진을 의미하지는 않는다.

## 주거 도면·3D 보강 검토

우선 대상은 **단독·다가구·다세대·연립·아파트 등 한국 주거공간**이다. 상가·근린생활시설은 제외한다. ‘빌라’는 통칭으로 보존하고 실제 법정 용도를 별도로 입력한다. 보강 명세와 초기 검토를 반영한 데이터 계약은 아래 구현 문서에서 확인한다. 규칙 69개는 참고 상태를 유지한다.

- [도면·3D 보강 명세](20-residential-drawing-3d-requirements.md): 좌표·형상·도면 해석·주거 타입·검증·보강 순서.
- v0.1 초기 공백 검토 (배포에 포함하지 않은 내부 기록) → v0.2 구현 검증과 남은 범위 (배포에 포함하지 않은 내부 기록).

## 먼저 알아둘 다섯 가지

1. 벽 두께의 정답은 하나가 아니다. 세대 경계벽 규정, 구조 검토, 열성능, 특정 제품 인정 사양을 분리한다.
2. 외벽 두 겹 사이 단열은 한 구성이다. 외단열 RC, 내단열, 경량구조 충진단열, 통기 외장도 레이어로 표현한다.
3. 문짝 900mm와 통과유효폭 900mm는 다르다. 문짝·문틀·골조 개구부·사용 상태의 치수를 나눈다.
4. 층고·천장고·슬래브·바닥 마감 두께는 기준면이 다르다. 마감 후 실제 높이를 계산한다.
5. ‘암묵지’는 조건·반례·근거가 있는 후보로 저장한다. 현장 인터뷰 없이 전국 공통 관행이라고 주장하지 않는다.

## 읽는 순서

| 문서 | 핵심 질문 |
|---|---|
| [01 규정과 적용 맥락](01-regulatory-context.md) | 어느 법령·판본이 어느 건물에 적용되는가? |
| [02 치수와 기준면](02-dimensions-and-datums.md) | 이 숫자는 무엇을 어디서부터 잰 것인가? |
| [03 벽체·레이어](03-walls-and-assemblies.md) | 내력·차음·방화·단열 역할을 어떻게 나누는가? |
| [04 단열·외피](04-thermal-envelope.md) | 지역과 용도에 따라 단열 성능이 어떻게 달라지는가? |
| [05 문·개구부](05-doors-and-openings.md) | 제품 규격과 유효폭을 어떻게 구별하는가? |
| [06 창호·설치 높이](06-windows-and-heights.md) | 창대·창 상단·추락방지·채광을 어떻게 연결하는가? |
| [07 바닥·층고](07-floors-and-storeys.md) | 구조와 마감·설비가 실제 천장고에 미치는 영향은? |
| [08 계단·접근성·주차](08-stairs-accessibility-parking.md) | 경로를 따라 여러 조건을 어떻게 중첩하는가? |
| [09 방수·지붕](09-waterproofing-and-roofs.md) | 물 흐름과 접합부를 어떻게 기록하는가? |
| [10 구조·설비](10-structure-and-services.md) | 계산·제품·시방 확인이 필요한 범위는? |
| [11 가설 안전·품질](11-construction-safety-and-quality.md) | 공사 중 상태와 준공 상태를 어떻게 나누는가? |
| [12 암묵지 후보 20개](12-tacit-knowledge-patterns.md) | 현장 판단을 검증 가능한 지식으로 바꾸려면? |
| [13 온톨로지 명세](13-ontology-schema.md) | 어떤 개념과 관계가 필요한가? |
| [14 규칙 카탈로그](14-rule-catalog.md) | 적용 조건·예외·출처가 붙은 규칙은? |
| [15 예제 인스턴스](15-worked-examples.md) | 벽·문·층고를 실제 데이터로 표현하면? |
| [16 출처대장](16-source-register.md) | 어떤 문서의 어느 판을 얼마나 확인했는가? |
| [17 검증 질문·확장 과제](17-competency-questions.md) | 이 모델이 무엇을 답해야 하고 무엇이 남았는가? |
| [18 현장어 사전](18-terminology.md) | 먹·골조·바탕·공틀 등의 표현을 어떻게 정규화하는가? |
| [19 제품·실무 문헌 사례](19-product-and-practice-evidence.md) | 실제 인정서·카탈로그는 어떤 범위의 근거가 되는가? |

데이터: [rules.json](rules.json) · [sources.json](sources.json).

## 온톨로지의 연결 구조

```mermaid
flowchart LR
  P["사업 맥락: 지역·용도·날짜"] --> R["적용 규칙과 예외"]
  S["출처의 특정 판·조항"] --> R
  B["건물·층·공간"] --> E["벽·문·창·바닥"]
  E --> A["조립체 → 순서 있는 레이어"]
  E --> Q["설계값·실측값 + 단위·기준면"]
  R --> V["개별 요구 판정"]
  Q --> V
  V --> O["PASS / FAIL / UNKNOWN / 적용 제외 / 충돌"]
  T["암묵지 후보 + 조건·반례"] --> I["검사·관측·증거"]
  I --> Q
```

권장 도입 순서는 용어·클래스 사전→조립체 인스턴스→사업 맥락→출처판 고정→개별 조건 검증이다. IFC/BOT와 객체를 연결하고, PROV-O로 근거, SKOS로 현장어, SOSA로 실측, SHACL로 데이터 제약을 표현하는 설계를 제시했다. v0.3은 로컬 어휘의 RDF/OWL 선언·SHACL 검증·JSON↔RDF 왕복을 구현했다. 외부 표준 연결은 참조 매핑이며 IFC 변환기·IDS 납품 검증기는 별도다.

## 확인 상태와 사용 범위

- 법적 의무, 제조사 고유 사양, 문헌 권고, 작성자 계산 예제를 눈에 보이게 구분했다.
- 접근성 별표 등 미확정 항목은 확인판과 상태를 함께 적었다. 주거 분류·반자높이·바닥의 추가 시행판 대조는 25장과 L 계열 출처에 연결했다.
- 열관류율 표와 제조사 인정서·카탈로그 핵심 쪽은 텍스트 추출 후 이미지로 대조했다.
- 프로젝트별 적용판·경과조치·조례·인정 유효성 확인은 별도이며, 누락 입력의 기본 판정은 UNKNOWN이다.
- 시방 전문·유료 KS 원문·지역 조례 전체, 현장 전문가 인터뷰까지 완료한 자료는 아니다. 미확인 치수는 임의의 ‘표준값’으로 채우지 않았다.

신규 자료는 기존 규칙을 덮어쓰기보다 판본·확인일·근거를 추가한다. 소스의 신뢰도와 특정 사업에 적용되는지는 별개의 상태로 유지한다.

Obsidian 시작 링크: [13-ontology-schema](13-ontology-schema.md) · [14-rule-catalog](14-rule-catalog.md) · [16-source-register](16-source-register.md).

## v0.3 구현 파일

| 목적 | 파일 |
|---|---|
| 입력·좌표·치수·변경 | [21 주거 모델 데이터 계약](21-residential-model-contracts.md) |
| 프로필·부품·접합 템플릿 | [22 주거 라이브러리](22-residential-type-library.md) |
| 실행·검증·마이그레이션 | [23 구현 검증과 이행](23-validation-and-migration.md) |
| 전체 클래스·속성 사전 | [24 어휘 참조](24-vocabulary-reference.md) |
| 기계용 어휘 정본 | [vocabulary.json](vocabulary.json) |
| RDF/OWL·제약 | [ontology.ttl](ontology.ttl) · [shapes.ttl](shapes.ttl) · [JSON Schema](schemas/residential-model.schema.json) |
| 조건·예외·출처 | [rule-contracts.json](rule-contracts.json) · [sources.json](sources.json) |
| 출력·평가·추적 | [output-contracts.json](output-contracts.json) · [benchmark-contract.json](benchmark-contract.json) · [requirement-coverage.json](requirement-coverage.json) |

기존 복원은 `reconstruct_existing`, 새 계획은 `design_new`, 변경안은 `propose_change`를 지정한다. 모르는 치수는 `null`과 `evidenceStatus: unknown`으로 보존한다. 관측한 벽을 법규 기본값으로 몰래 바꾸지 않는다.

## 반복 보완판 v0.3

[25 주거 법령 적용 조건](25-residential-legal-conditions.md)과 [법령 보충 데이터](legal-review-2026-09-05.json)를 추가했다. 입력·승인·형상·변경·직렬화 반례를 보강하고 정본에서 도식·스키마·어휘 사전·예제를 다시 생성했다. 최신 반복 검토는 2026-09-05-residential-ontology-review-loop (배포에 포함하지 않은 내부 기록)에 둔다.
