---
description: "Korean construction knowledge and ontology: 08-stairs-accessibility-parking."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 계단·난간·경사로·주차

## 용도별 계단

피난방화규칙 제15조 확인판 시행 2025-10-31(S05): 해당 계단 유효높이 2,100mm 이상. 높이 3m 초과 계단은 3m 이내마다 유효너비 1,200mm 이상 참이 필요하다. 초등학교는 폭 1,500mm 이상·단높이 160mm 이하·단너비 260mm 이상, 중고등학교는 폭 1,500mm 이상·단높이 180mm 이하·단너비 260mm 이상이다.

‘기타 계단’ 잔여 조항의 작은 폭을 일반 출입계단 기본값으로 쓰지 않는다. 주택 계단과 접근성 계단의 중첩 기준을 확인한다. 보행 편의 경험식은 법정 기준을 대신하지 않는다.

## 난간과 손잡이

주택건설기준 규정 제18조제2항 확인판 시행 2026-06-30(S04): 해당 난간은 마감면부터 1,200mm 이상, 간살 안목간격 100mm 이하. 조항이 정한 내부계단 등 위험이 적은 장소는 900mm 이상 경로가 있다. 난간과 손잡이는 다른 기능·속성이다. [난간 조문](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1033039947)

## 접근성 경로

S07의 2023-12-11 개정 별표 확인판: 해당 경사로 일반 기울기 1:12 이하, 유효폭 1,200mm 이상. 시작·끝·굴절·참 활동공간은 일반 1,500×1,500mm이며 직선 참 등 예외가 있다. 기존시설 완화는 명시 조건을 모두 확인해야 한다. 해당 계단은 단너비 280mm 이상·단높이 180mm 이하와 균일성 기준이 있다. 최신 별표와 적용 대상의 대조는 미확정이다.

가상 예제: 높이차 450mm에 1:12라면 수평 길이 5,400mm가 필요하다. 시작·끝 활동공간은 별도로 배치한다. 경사면 길이와 수평 투영길이를 바꾸어 쓰지 않는다. 문 개폐 영역도 따로 검토한다.

BF 인증과 법정 편의시설 기준은 별도 문서다. BF 대상·등급별 기준은 이 버전에서 확정하지 않았다.

## 주차 구획

주차장법 시행규칙 제3조제1항제2호의 **평행주차 외** 구획, 확인판 시행 2026-07-27(S10).

| ID | 종류 | 너비×길이 최소, mm |
|---|---|---:|
| PARK-001 | 경형 | 2,000×3,600 |
| PARK-002 | 일반형 | 2,500×5,000 |
| PARK-003 | 확장형 | 2,600×5,200 |
| PARK-004 | 장애인전용 | 3,300×5,000 |

[주차구획 조문](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1029242743). 차로·램프·유효높이·대수·설치비율까지 충족했다는 뜻은 아니다. 평행·기계식 주차에 전용하지 않는다. 대수와 비율은 용도·조례 등 별도 입력이다.

## 공간 관계

Route hasSegment RouteSegment; RouteSegment hasQuantity Quantity; DoorSwing intersects ClearanceZone; Stair hasFlight Flight; Railing protects Edge. 접근성은 개별 문 치수를 넘어 주차→접근로→출입구→복도→승강기→목적실의 연속 경로로 검토한다.
