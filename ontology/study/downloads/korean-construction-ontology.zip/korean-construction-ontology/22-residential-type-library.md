---
description: "Defines six residential input profiles and thirteen parameterized component intake categories."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, korea, residential, ontology, drawing, bim]
---

# 한국 주거 프로필·부품 템플릿

[residential-profiles.json](library/residential-profiles.json)은 단독·다가구·다세대·연립·아파트·미확정을 구분한다. 세대·동·대지 범위를 명시하며 법정 용도는 근거 문서로 확인한다.

[component-types.json](library/component-types.json)은 **13영역 카드·46개 ParameterDefinition**을 제공한다. 실제 제조사 모델이 채워진 제품 라이브러리는 아니다. manufacturer/productEdition/nominalDimensions는 미상, defaultParameterValues는 빈 값, verificationStatus는 unverified다.

| 영역 | 주 대상 | 수집 물리량 | 별도 여유 |
|---|---|---|---|
| 현관 | Door | roughOpeningWidth, roughOpeningHeight, clearWidth, thresholdHeight, cabinetDepth | operation, passage, replacement |
| 거실·침실 | Furniture | furnitureWidth, furnitureDepth, furnitureHeight, passageWidth, ceilingHeight | operation, passage |
| 주방 | Assembly | cabinetDepth, counterHeight, applianceOpeningWidth, installationGap, drainSlope | operation, maintenance |
| 가전 | Appliance | productWidth, productDepth, productHeight, installationGap, maintenanceGap, replacementWidth | installation, maintenance, replacement |
| 욕실 | WetArea | floorLevel, drainSlope, waterproofUpstand, thresholdHeight, ceilingHeight | passage, maintenance |
| 다용도실 | Space | floorLevel, drainSlope, installationGap, passageWidth | operation, maintenance |
| 온돌 바닥 | OndolSystem | pipeDiameter, pipeSpacing, embedmentDepth, layerThickness, floorLevel | installation, maintenance |
| 발코니 | Balcony | floorLevel, drainSlope, assemblyThickness, openingBaseHeight | passage, maintenance |
| 외피 | Wall | assemblyThickness, layerThickness, thermalConductivity, thermalTransmittance, cavityDepth | installation, maintenance |
| 경계·구조벽 | Wall | assemblyThickness, layerThickness, soundReduction, fireResistance | installation |
| 설비 공간 | Shaft | shaftWidth, shaftDepth, servicePortDiameter, maintenanceGap | maintenance, replacement |
| 지붕·기초 | Assembly | slabThickness, roofSlope, eaveDepth, foundationDepth, soilBearingCapacity | installation, maintenance |
| 공동부 | CommonArea | clearWidth, clearHeadroom, riserHeight, treadDepth, landingWidth | passage, maintenance |

## 타입과 실제 부재

TypeDefinition은 반복 부품의 매개변수·호스트 조건, ParameterDefinition은 물리량·단위·기준을 정의한다. 실제 부재는 hasType과 parameterValues로 연결하며 값은 Quantity ID를 참조한다. 타입을 가져올 때 파라미터와 출처도 함께 가져와 모든 ID를 해소한다.

전국 공통 기본값을 만들지 않는다. 구조·노출·용도·제품판·접합·성능 근거를 확보한 후 수치를 넣는다. 기존 제품 근거 3건은 [19-product-and-practice-evidence](19-product-and-practice-evidence.md)와 PROD-001~003에 보존했다. 이 수집 템플릿을 해당 제조사의 검증된 제품으로 표시하지 않는다.

## 벽체 구성의 수집 단위

RC 외단열은 내부 마감→구조체→단열→외장 시스템, 내단열은 실내 측 단열과 슬래브 접합 열교를 수집한다. 조적 중공벽은 내·외측 구성·단열·공기층·배수·연결철물을 분리한다. 경량 목구조는 스터드와 충진재 공유 영역·면재·기밀/방습·통기층·외장을 기록한다. 시스템마다 구조·화재·수분·두께 검토가 다르다.

외벽을 항상 ‘벽 두 겹+단열’로 생성하지 않는다. 그 구성을 선택했다면 레이어와 접합을 설정하고 근거가 부족한 부분은 가정으로 표시한다.

## 암묵지의 실증 카드

PracticeCandidate에 조건·선택·이유·실패·반례·검토자 역할·도면 위치·관측·검증 판을 연결한다. 기존 TK-001~020은 참고 후보를 유지한다. 인터뷰 주장과 도면/실측으로 검증된 사례는 다른 근거 상태를 가진다.

주방 이동 제약이라면 배수 포트·샤프트·바닥 레벨·구배 근거·우회 경로·관통부/천장 영향과 Change를 연결한다. 조건이 같은 사례인지 비교할 정보가 있어야 재사용할 수 있다.

타입을 사용 가능 상태로 승격하려면 출처판·권한, 기준면별 치수, 파라미터 범위, 설치·사용·정비·반출 공간, 접합 및 시스템 성능을 확보한다. 최소·대표·최대 파라미터로 형상·간섭을 검증한 후 프로젝트에 채택한다.

## 법령의 표준 바닥 시스템 참고

[별도 참고 파일](library/floor-systems-legal-reference.json)은 소규모 주택 고시의 인정구조 또는 I/II형식 표준구조와 레이어 순서를 보존한다. 기존 13개 매개변수 수집 템플릿과 구별하며 특정 제품 인정이나 모든 주택의 기본값을 뜻하지 않는다. 적용 조건은 [25 법령 재검토](25-residential-legal-conditions.md)를 따른다.
