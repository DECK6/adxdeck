---
description: "Separates executable ontology contract checks from real reconstruction and design performance."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, korea, residential, ontology, drawing, bim]
---

# v0.3 구현 검증·이행·후속 연결

현재 릴리스는 온톨로지와 데이터 계약의 구현이다. 최신 검사 증거는 2026-09-05-residential-ontology-review-loop (배포에 포함하지 않은 내부 기록)에 둔다. 2026-09-05-residential-ontology-v02-verification (배포에 포함하지 않은 내부 기록)은 이전 판의 검사 이력이다.

## 재현

Python 3.11과 [requirements.txt](requirements.txt)의 고정 의존성을 사용한다. 패키지 루트에서 실행한다.

```sh
python tools/build_contracts.py
python -m unittest discover -s tools -v
python tools/check_package.py --report /path/to/verification-report.json
python tools/validate_model.py examples/apartment.json --shacl --rdf-out /path/to/apartment.ttl
```

build_contracts.py의 정본은 vocabulary.json이다. JSON Schema·OWL·SHACL·context를 각각 수동 편집하지 않는다. RDF 익명 노드 출력 순서는 바뀔 수 있으므로 재생성 정합은 그래프 동형성으로 확인한다.

검증기는 실패 코드·객체 ID를 반환하며 원 입력을 수정하지 않는다. 잘못된 스키마는 의미 검사 전에 진단한다. 파일·필드 존재만으로 실제 승인 내용의 진실성을 확인할 수는 없다.

## 검사 층

| 층 | 현재 실행 | 후속 검증 |
|---|---|---|
| 데이터 | 타입·ID·참조·Quantity·상태 | 실제 문서 추출 정확성 |
| 기하 | 평면 투영·구멍 포함/교차·벽 구간·계단 구멍·좌표 | 전체 솔리드·경로·열교·국소 높이 |
| 근거·법규 | UNKNOWN·조건식·활성화 가드 | 사업 적용판·예외·전문가 대조 |
| 도면 정합 | 객체 ID·치수 대상·충돌 보존 | 원도면 중첩·단면 재생성 |
| 교환 | JSON↔RDF·JSON-LD 의미 왕복 | 실제 IFC 파일·선택 도구 왕복 |
| 변경 | 산출물·계산값 무효화 | 기하·수량·도면·판정 재생성 |

[requirement-coverage.json](requirement-coverage.json)은 O01~O12와 SC-01~SC-10의 구현 계약·테스트·남은 엔진 증거를 구분한다. 계약 통과를 10개 시스템 시나리오의 실물 검증 완료로 보고하지 않는다.

## v0.1 이행

rules.json과 핵심 ID를 보존하고 rule-contracts.json의 legacyRecord로 원 기록을 대조한다. 과거 축약 YAML은 다음처럼 변환한다.

| 이전 표기 | v0.3 |
|---|---|
| thicknessMm: 200 | Quantity + 주어·물리량·단위·기준·상태 |
| state: approved | 근거 상태를 별도 확인; approvalStatus와 hasApproval |
| layer.order | layerOrder |
| 높이 누락/0 기본값 | null + unknown |
| 문과 구멍 혼용 | Door.fillsOpening → Opening.voidsElement |
| 최신 파일명이 정본 | ModelRevision·supersedes·부분 개정 근거 |
| 제품 치수를 공통 법정값으로 재사용 | 제품판·용도·명목/설치/유효 기준 보존 |

기존 이름은 보존했지만 v0.1 임의 JSON이 새 필수값을 자동 충족하지는 않는다. 외부 IFC/BOT/PROV/SOSA 등과의 동치는 검증하지 않았으며 seeAlso 참조만 선언했다.

## 실제 도면·3D 시스템 연결

1. 권한 있는 주거 도면 세트와 독립 검토 모델을 확보한다. benchmark-contract.json의 건물별 분리·미상 비율·치수 오차·호스트 오류·교환 손실을 기록한다.
2. PDF/CAD/스캔 파서가 원문 위치·근거와 함께 이 모델을 만든다. 평면·단면·입면·일람표 충돌은 자동 평균하지 않는다.
3. 기하 엔진이 벽·개구부·바닥·계단을 만들고 같은 판에서 도면을 출력한다. 변경 전파를 실제 파일로 확인한다.
4. 신규 단독주택 생성은 대지·생활 요구·제약을 풀어 같은 모델에 후보를 만든다. 공동주택 동 전체는 코어·수직동선·구조·설비·대지까지 확대한다.
5. 목표 도서 수준에 맞춰 건축·구조·설비·법규 검토를 결합한다.

독립 사례 9건은 실험 시작 제안이다. 현재 실제 사례는 0건이며 합성 조각 3개는 복원 정확도의 통계 표본이 아니다.

## v0.2 → v0.3 이행

schemaVersion을 0.3.0으로 올리기 전에 빈 필수 관계, 치수 귀속·단위·기준, 날짜, 도면 소속, 순환, 오래된 의존성을 수정한다. 기존 RDF의 xsd:double을 단순 문자열 치환하지 말고 원 JSON에서 다시 내보낸다. 이미 반올림된 숫자는 원 근거에서 복구한다.

기존 ApprovalRecord에 결정을 추정해 넣지 않는다. 대상·개정본·승인 원문을 대조하고 승인 당시 데이터에서 modelDigest를 계산한다. 근거가 없으면 승인 상태를 미확정/재검토로 남긴다. 불러오는 검사기는 오류를 진단하며 입력을 자동 보정하지 않는다.

현행 법령의 추가 조건은 [25 적용 조건 재검토](25-residential-legal-conditions.md)를 따른다. 과거 출처 레코드는 확인 이력으로 보존하고 L 계열 출처 및 currentReviewId로 새 확인 결과를 연결했다.
