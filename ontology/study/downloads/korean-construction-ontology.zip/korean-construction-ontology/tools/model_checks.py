"""Geometry and graph invariants independent of schema projection."""
import math
import hashlib
import json
from datetime import date, datetime

LENGTH = {"mm": 1.0, "m": 1000.0}
EPS = 1e-6  # mm arithmetic guard, never a statutory or construction tolerance.
POSITIVE_LENGTHS = {
    "assemblyThickness", "layerThickness", "structuralThickness", "slabThickness",
    "floorAssemblyThickness", "roughOpeningWidth", "roughOpeningHeight", "leafWidth",
    "frameOuterWidth", "ceilingHeight",
    "storeyHeight", "furnitureWidth", "furnitureDepth", "furnitureHeight", "cabinetDepth",
    "productWidth", "productDepth", "productHeight", "shaftWidth", "shaftDepth",
    "pipeDiameter", "pipeSpacing", "servicePortDiameter", "riserHeight", "treadDepth",
    "landingWidth", "applianceOpeningWidth",
}
NONNEGATIVE_LENGTHS = {"clearOpeningWidth", "clearWidth", "clearHeadroom", "passageWidth", "replacementWidth"}


def revision_digest(model):
    """Whole packet fingerprint, excluding approval records and approval links/status.

    It binds a review to the data reviewed, not the authenticity of the reviewer.
    Sorting relation arrays is handled by the caller's semantic canonicalization.
    """
    packet = {k:v for k,v in model.items() if k != "entities"}
    packet["entities"] = sorted([
        {k:v for k,v in e.items() if k not in ("hasApproval", "approvalStatus")}
        for e in model["entities"] if e["type"] != "ApprovalRecord"
    ], key=lambda e:e["id"])
    def normalize(value):
        if isinstance(value, float) and value.is_integer():
            return int(value)
        if isinstance(value, list):
            return [normalize(v) for v in value]
        if isinstance(value, dict):
            return {k:normalize(v) for k,v in value.items()}
        return value
    raw = json.dumps(normalize(packet), ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()


def cross2(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def on_segment(a, b, p):
    return abs(cross2(a,b,p)) <= EPS * max(1, math.dist(a,b)) and all(min(a[i],b[i])-EPS <= p[i] <= max(a[i],b[i])+EPS for i in (0,1))


def intersect(a, b, c, d):
    return (cross2(a,b,c)*cross2(a,b,d) < 0 and cross2(c,d,a)*cross2(c,d,b) < 0) or any((
        on_segment(a,b,c), on_segment(a,b,d), on_segment(c,d,a), on_segment(c,d,b)))


def self_intersects(ring):
    n = len(ring)-1
    return any(intersect(ring[i],ring[i+1],ring[j],ring[j+1])
               for i in range(n) for j in range(i+2,n) if not (i == 0 and j == n-1))


def ring_intersects(a, b):
    return any(intersect(p,q,r,s) for p,q in zip(a,a[1:]) for r,s in zip(b,b[1:]))


def inside(point, ring):
    if any(on_segment(a,b,point) for a,b in zip(ring,ring[1:])):
        return False
    count = False
    x,y = point
    for a,b in zip(ring,ring[1:]):
        if (a[1]>y) != (b[1]>y):
            crossing = a[0] + (y-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if x < crossing:
                count = not count
    return count


def project_rings(points, holes):
    """Find a non-collinear plane and project along its dominant normal."""
    origin = points[0]
    normal = None
    for b,c in zip(points[1:],points[2:]):
        u,v = [[p[i]-origin[i] for i in range(3)] for p in (b,c)]
        n = [u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        norm = math.sqrt(sum(x*x for x in n))
        if norm > EPS:
            normal = [x/norm for x in n]
            break
    if normal is None:
        return None, False
    nonplanar = any(abs(sum((p[i]-origin[i])*normal[i] for i in range(3))) > EPS
                    for ring in [points]+holes for p in ring)
    drop = max(range(3), key=lambda i: abs(normal[i]))
    axes = [i for i in range(3) if i != drop]
    return [[[p[i]-origin[i] for i in axes] for p in ring] for ring in [points]+holes], nonplanar


def check_profile(e, fail):
    eid = e["id"]
    if e["unit"] not in LENGTH:
        return
    scale = LENGTH[e["unit"]]
    points = [[x*scale for x in p] for p in e["points"]]
    holes = [[[x*scale for x in p] for p in ring] for ring in e.get("holes",[])]
    for ring in [points]+holes:
        if any(math.dist(a,b) <= EPS for a,b in zip(ring,ring[1:])):
            fail("DEGENERATE_GEOMETRY", eid, "Adjacent points coincide")
    if e["geometryKind"] not in ("polygon","slope_surface"):
        if holes:
            fail("PROFILE_HOLES", eid, "Interior holes require a polygon/surface profile")
        return
    for ring in [points]+holes:
        if len(ring)<4 or math.dist(ring[0],ring[-1]) > EPS:
            fail("OPEN_RING", eid, "Ring must close")
            return
    rings, nonplanar = project_rings(points,holes)
    if rings is None:
        fail("DEGENERATE_GEOMETRY",eid,"Polygon has no area")
        return
    if nonplanar:
        fail("NONPLANAR_PROFILE",eid,"Polygon and holes must lie in one declared plane")
    for ring in rings:
        if self_intersects(ring):
            fail("SELF_INTERSECTION",eid,"Projected ring intersects itself")
        area2 = sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(ring,ring[1:]))
        if abs(area2) <= EPS*EPS:
            fail("DEGENERATE_GEOMETRY",eid,"Ring has zero signed area")
    outer = rings[0]
    for hole in rings[1:]:
        if ring_intersects(outer,hole):
            fail("HOLE_BOUNDARY",eid,"An interior hole crosses or touches the outer boundary")
        elif not all(inside(p,outer) for p in hole[:-1]):
            fail("HOLE_OUTSIDE",eid,"Hole lies outside the polygon")
    for i,a in enumerate(rings[1:]):
        for b in rings[i+2:]:
            if ring_intersects(a,b) or inside(a[0],b) or inside(b[0],a):
                fail("HOLE_OVERLAP",eid,"Interior holes overlap, touch or nest")


def world_ring(by, profile, owner, ring):
    """Convert a profile ring through its explicit parent placements into mm."""
    scale = LENGTH.get(profile.get("unit"))
    if scale is None:
        raise ValueError("Unknown profile unit")
    points = [[x*scale for x in p] for p in ring]
    pid = profile.get("hasPlacement") or owner.get("hasPlacement")
    seen = set()
    while pid:
        if pid in seen:
            raise ValueError("Placement cycle")
        seen.add(pid)
        placement = by.get(pid,{})
        unit = LENGTH.get(placement.get("unit"))
        if unit is None:
            raise ValueError("Unresolved placement")
        angle = math.radians(placement["rotationDeg"])
        origin = [x*unit for x in placement["origin"]]
        converted = []
        for x,y,z in points:
            if placement["handedness"] == "mirrored":
                x = -x
            converted.append([x*math.cos(angle)-y*math.sin(angle)+origin[0],
                              x*math.sin(angle)+y*math.cos(angle)+origin[1],z+origin[2]])
        points = converted
        pid = placement.get("relativeTo")
    return points


def equal_rings(a, b):
    if len(a) != len(b) or len(a)<4:
        return False
    a,b = a[:-1],b[:-1]
    for candidate in (b,b[::-1]):
        for shift in range(len(candidate)):
            if all(math.dist(p,candidate[(i+shift)%len(candidate)])<=EPS for i,p in enumerate(a)):
                return True
    return False


def check_cycles(by, relation, code, is_subject, fail):
    visited, active = set(), set()
    def visit(id):
        if id in active:
            fail(code,id,relation+" contains a cycle")
            return
        if id in visited or id not in by or not is_subject(by[id]):
            return
        active.add(id)
        refs = by[id].get(relation,[])
        for ref in refs if isinstance(refs,list) else [refs]:
            visit(ref)
        active.remove(id)
        visited.add(id)
    for id in by:
        visit(id)


def audit_invariants(model, by, is_a, fail):
    for e in by.values():
        eid=e["id"]
        for key in ("applicationDate","createdAt","checkedAt"):
            value=e.get(key)
            if key in e and value is not None:
                try:
                    if key=="applicationDate":
                        if len(value)!=10:
                            raise ValueError()
                        date.fromisoformat(value)
                    else:
                        if "T" in value:
                            parsed=datetime.fromisoformat(value.replace("Z","+00:00"))
                            if parsed.tzinfo is None:
                                raise ValueError()
                        elif key == "checkedAt":
                            date.fromisoformat(value)
                        else:
                            raise ValueError()
                except ValueError:
                    fail("DATE_FORMAT",eid,key+" is not a valid date or timezone-aware timestamp")
        for qid in e.get("hasQuantity",[]):
            q=by.get(qid,{})
            if q.get("quantitySubject")!=eid:
                fail("QUANTITY_OWNER",eid,"hasQuantity points at another subject")
        if is_a(e,"Quantity") and e.get("value") is not None:
            if e["unit"]=="unknown":
                fail("QUANTITY_UNIT",eid,"Known values require known units")
            if e["propertyTerm"] in POSITIVE_LENGTHS:
                if e["unit"] not in LENGTH:
                    fail("QUANTITY_UNIT",eid,"Length property requires mm or m")
                if e["value"]<=0:
                    fail("QUANTITY_DOMAIN",eid,"Physical thickness/width/height must be positive")
            if e["propertyTerm"] in NONNEGATIVE_LENGTHS:
                if e["unit"] not in LENGTH or e["value"] < 0:
                    fail("QUANTITY_DOMAIN",eid,"Clearance requires a nonnegative length; zero can describe obstruction")
        if is_a(e,"Project"):
            context=by.get(e.get("hasContext"),{})
            profile=by.get(context.get("hasProfile"),{})
            brief=by.get(e.get("hasBrief"),{})
            if profile.get("modelScope")!=brief.get("modelScope"):
                fail("CONTEXT_SCOPE",eid,"Profile and DesignBrief model scopes differ")
        if is_a(e,"Wall"):
            roles=set(e["wallRoles"])
            if {"load_bearing","non_load_bearing"}<=roles:
                fail("WALL_ROLE_CONFLICT",eid,"Structural roles contradict each other")
            if by.get(e.get("hasGeometry"),{}).get("geometryKind")!="polyline":
                fail("WALL_PATH",eid,"Wall reference geometry must be a polyline path")
        if is_a(e,"Opening"):
            host=by.get(e.get("voidsElement"),{})
            for key in ("widthQuantity","heightQuantity","offsetQuantity","baseHeightQuantity"):
                q=by.get(e.get(key),{})
                if q.get("value") is None:
                    continue
                allowed={"widthQuantity":{"rough_opening"},"heightQuantity":{"rough_opening","slab_thickness"},
                         "offsetQuantity":{"host_axis_start"} if is_a(host,"Wall") else {"slab_local"},
                         "baseHeightQuantity":{"FFL","SSL"}}[key]
                if q.get("basis") not in allowed:
                    fail("OPENING_BASIS",eid,key+" has an incompatible measurement basis")
        if "parameterValues" in e:
            type_def=by.get(e.get("hasType"),{})
            definitions={by[pid].get("propertyTerm"):by[pid] for pid in type_def.get("hasParameter",[]) if pid in by}
            for term,qid in e["parameterValues"].items():
                if term not in definitions:
                    fail("PARAMETER_UNDECLARED",eid,"Parameter is not declared by the selected type: "+term)
                q=by.get(qid,{})
                if not is_a(q,"Quantity"):
                    fail("PARAMETER_REFERENCE",eid,"Parameter value must refer to an existing Quantity")
                elif q.get("quantitySubject")!=eid or q.get("propertyTerm")!=term or (term in definitions and
                        (q.get("unit")!=definitions[term]["unit"] or q.get("basis")!=definitions[term]["basis"])):
                    fail("PARAMETER_BINDING",eid,"Parameter quantity subject, term, unit or basis mismatch")
        if is_a(e,"DerivedArtifact") and e.get("artifactStatus")=="current":
            seen=set()
            def stale_dependencies(target):
                if target in seen or target not in by:
                    return False
                seen.add(target)
                dependency=by[target]
                if dependency.get("artifactStatus")=="stale" or dependency.get("validityStatus")=="stale":
                    return True
                return any(stale_dependencies(t) for t in dependency.get("dependsOn",[]))
            if any(stale_dependencies(t) for t in e.get("dependsOn",[])):
                fail("STALE_DEPENDENCY",eid,"Current artifact consumes a stale dependency")
        for parent_field, inverse in (("inSheet","hasView"),("inDocument","hasSheet")):
            if parent_field in e:
                parent=by.get(e[parent_field],{})
                if eid not in parent.get(inverse,[]):
                    fail("DRAWING_MEMBERSHIP",eid,parent_field+" disagrees with parent's "+inverse)
            for child_id in e.get(inverse, []):
                if by.get(child_id, {}).get(parent_field) != eid:
                    fail("DRAWING_MEMBERSHIP", eid, inverse+" disagrees with child's "+parent_field)
        if is_a(e, "ApprovalRecord"):
            scope = e["approvalScope"]
            if scope["projectId"] != model["projectId"] or not is_a(by.get(scope["revisionId"],{}), "ModelRevision") or any(i not in by for i in scope["entityIds"]):
                fail("APPROVAL_SCOPE", eid, "Approval scope has unresolved project, revision or subjects")
            if not e.get("hasSource"):
                fail("APPROVAL_PROVENANCE", eid, "Approval requires its source record")
        if "hasApproval" in e:
            approval = by.get(e["hasApproval"], {})
            scope = approval.get("approvalScope", {})
            if scope.get("projectId") != model["projectId"] or scope.get("revisionId") != e.get("belongsToRevision",model["revisionId"]) or eid not in scope.get("entityIds",[]):
                fail("APPROVAL_SCOPE", eid, "Approval is not scoped to this project, revision and entity")
            if (e.get("approvalStatus") == "approved" or e.get("issueStatus") == "resolved") and approval.get("approvalDecision") != "approved":
                fail("APPROVAL_DECISION", eid, "Approved/resolved state requires an approved decision")
            if scope.get("modelDigest") != model.get("_reviewDigest"):
                fail("APPROVAL_SNAPSHOT", eid, "Approval fingerprint differs from the reviewed model packet")
        if is_a(e, "ViewTransform"):
            matrix = [row[:] for row in e["transformMatrix"]]
            # Scaled elimination tests rank without assigning a construction tolerance.
            for col in range(4):
                pivot = max(range(col,4), key=lambda row: abs(matrix[row][col]))
                if matrix[pivot][col] == 0:
                    fail("TRANSFORM_SINGULAR", eid, "Coordinate transform must be invertible")
                    break
                matrix[col],matrix[pivot] = matrix[pivot],matrix[col]
                for row in range(col+1,4):
                    ratio = matrix[row][col]/matrix[col][col]
                    for j in range(col,4):
                        matrix[row][j] -= ratio*matrix[col][j]
    fill_counts={}
    for e in by.values():
        if "fillsOpening" in e:
            fill_counts.setdefault(e["fillsOpening"],[]).append(e["id"])
    for op,fillers in fill_counts.items():
        if len(fillers)>1:
            fail("OPENING_FILL",op,"Multiple fill assemblies; use leaves/panels within one Door or Window")
    check_cycles(by,"supersedes","REVISION_CYCLE",lambda e:is_a(e,"ModelRevision"),fail)
    check_cycles(by,"inputQuantity","QUANTITY_CYCLE",lambda e:is_a(e,"Quantity"),fail)
    check_cycles(by,"dependsOn","ARTIFACT_CYCLE",lambda e:is_a(e,"DerivedArtifact"),fail)
    check_cycles(by,"containsSpace","SPATIAL_CYCLE",lambda e:is_a(e,"SpatialObject"),fail)
