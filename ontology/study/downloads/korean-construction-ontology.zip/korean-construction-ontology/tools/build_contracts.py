"""Build all schema projections from vocabulary.json; no network or input mutation."""
import json
from collections import Counter
from pathlib import Path
from rdflib import BNode, Graph, Literal, Namespace, RDF, RDFS, OWL, XSD, URIRef
from rdflib.collection import Collection

ROOT = Path(__file__).resolve().parents[1]
SH = Namespace("http://www.w3.org/ns/shacl#")
ID_SCHEMA = {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_.:-]*$"}
NUMBER = {"type": "number"}
POINT = {"type": "array", "items": NUMBER, "minItems": 3, "maxItems": 3}
RING = {"type": "array", "items": POINT, "minItems": 4}


def projection_tree_signature(graph):
    """Exact blank-node-independent comparison for generated rooted tree graphs.

    Reject shared/cyclic/unrooted blank nodes rather than using this bounded
    comparator on arbitrary RDF. Each generated anonymous node has one parent.
    """
    blanks = {n for triple in graph for n in triple if isinstance(n, BNode)}
    incoming = Counter(o for s,p,o in graph if isinstance(o,BNode))
    if any(incoming[n] != 1 for n in blanks):
        raise ValueError("Projection comparison requires one parent per blank node")
    active, seen = set(), set()
    def term(node):
        if not isinstance(node,BNode):
            return ("term",node.n3())
        if node in active:
            raise ValueError("Cyclic blank nodes")
        active.add(node);seen.add(node)
        result=("tree",tuple(sorted((p.n3(),term(o)) for p,o in graph.predicate_objects(node))))
        active.remove(node)
        return result
    result=tuple(sorted((s.n3(),p.n3(),term(o)) for s,p,o in graph if not isinstance(s,BNode)))
    if seen != blanks:
        raise ValueError("Unrooted blank-node component")
    return result


def ancestors(v, name):
    result = []
    while name is not None:
        if name in result:
            raise ValueError("class inheritance cycle: " + name)
        result.append(name)
        name = v["classes"][name]["parent"]
    return result


def fields_for(v, name):
    chain = ancestors(v, name)
    return {k: p for k, p in v["properties"].items() if set(chain) & set(p["domains"])}


def required_for(v, name):
    return sorted({p for c in ancestors(v, name) for p in v["classes"][c]["required"]})


def record(props, required=None):
    return {"type": "object", "properties": props, "required": list(props) if required is None else required, "additionalProperties": False}


def expression_schema():
    return {"oneOf": [
        record({"kind": {"const": kind}, "items": {"type": "array", "minItems": 1, "items": {"$ref": "#/$defs/Expression"}}})
        for kind in ("all_of", "any_of")
    ] + [
        record({"kind": {"const": "not"}, "item": {"$ref": "#/$defs/Expression"}}),
        record({"kind": {"const": "fact"}, "factCode": ID_SCHEMA, "expected": {"type": "boolean"}}),
        record({"kind": {"const": "compare"}, "propertyTerm": {"type": "string"},
                "operator": {"enum": ["gte", "lte", "eq"]}, "value": NUMBER,
                "unit": {"type": "string"}, "basis": {"type": "string"}}),
        record({"kind": {"const": "evidence_required"}, "requirementCode": ID_SCHEMA}),
    ]}


def value_schema(name, p):
    if p["kind"] == "object":
        return {"type": "array", "items": ID_SCHEMA, "uniqueItems": True} if p["multiple"] else ID_SCHEMA
    typ = p["type"]
    s = {"type": typ if typ != "json" else ["object", "array"]}
    if name == "points": s = {"type": "array", "items": POINT, "minItems": 2}
    elif name == "holes": s = {"type": "array", "items": RING}
    elif name == "origin": s = POINT
    elif name == "transformMatrix":
        s = {"type": "array", "items": {"type": "array", "items": NUMBER, "minItems": 4, "maxItems": 4}, "minItems": 4, "maxItems": 4}
    elif name == "requestedOutputs":
        s = {"type": "array", "minItems": 1, "uniqueItems": True, "items": {"enum": ["plan", "section", "elevation", "schedule", "interior_elevation", "ceiling_plan", "editable_3d", "ifc_exchange", "visualization"]}}
    elif name == "wallRoles":
        s = {"type": "array", "uniqueItems": True, "items": {"enum": ["exterior", "interior", "load_bearing", "non_load_bearing", "unit_boundary", "fire_compartment", "acoustic", "wet_boundary", "unknown"]}}
    elif name == "parameterValues":
        s = {"type": "object", "additionalProperties": ID_SCHEMA}
    elif name == "approvalScope":
        s = record({"projectId": ID_SCHEMA, "revisionId": ID_SCHEMA,
                    "entityIds": {"type": "array", "minItems": 1, "uniqueItems": True, "items": ID_SCHEMA},
                    "modelDigest": {"type":"string", "pattern":"^[a-f0-9]{64}$"}})
    elif name in ("limitations", "losses"):
        s = {"type": "array", "items": {"type": "string"}}
    elif name == "columns":
        s = {"type": "array", "minItems": 1, "items": {"type": "string"}, "uniqueItems": True}
    elif name == "calibrationChecks":
        s = {"type": "array", "items": record({
            "dimensionId": ID_SCHEMA, "sourceLength": {"type": "number", "exclusiveMinimum": 0},
            "modelLengthMm": {"type": "number", "exclusiveMinimum": 0}, "residualMm": NUMBER
        })}
    elif name == "expression": s = {"$ref": "#/$defs/Expression"}
    if "enum" in p: s["enum"] = p["enum"]
    if p.get("nullable"):
        s = {"anyOf": [s, {"type": "null"}]}
    return s


def vocabulary_reference(v):
    """Markdown projection uses the same definitions as the machine contracts."""
    lines = ["# 주거 건설 온톨로지 전체 어휘 v" + v["version"], "",
             "vocabulary.json에서 생성했다. 필수값·열거값·nullable·상속은 어휘 정본과 생성 스키마를 따른다.", "",
             "## 클래스", "", "| 이름 | 한국어 | 상위 | 정의 |", "|---|---|---|---|"]
    for name,c in v["classes"].items():
        lines.append("| " + " | ".join([name,c["label"],c["parent"] or "—",c["definition"].replace("|","\\|")]) + " |")
    lines += ["", "## 속성·관계", "", "| 이름 | 적용 클래스 | 목적어/타입 | 개수 | 정의 |", "|---|---|---|---|---|"]
    for name,p in v["properties"].items():
        lines.append("| " + " | ".join([name,", ".join(p["domains"]),", ".join(p["ranges"]) if p["kind"]=="object" else p["type"],
                                       "여러 값" if p["multiple"] else "단일 값",p["definition"].replace("|","\\|")]) + " |")
    return "\n".join(lines) + "\n"


def build(root=ROOT):
    v = json.loads((root / "vocabulary.json").read_text())
    k = Namespace(v["namespace"])
    for name, c in v["classes"].items():
        if c["parent"] is not None and c["parent"] not in v["classes"]:
            raise ValueError("undeclared parent " + name)
        fields = fields_for(v, name)
        if not set(required_for(v, name)) <= set(fields):
            raise ValueError("required fields outside class domain: " + name)
    for p in v["properties"].values():
        for c in p["domains"] + p.get("ranges", []):
            if c not in v["classes"]: raise ValueError("undeclared class " + c)

    defs = {"Expression": expression_schema()}
    for name in v["classes"]:
        properties = {"id": ID_SCHEMA, "type": {"const": name}}
        properties.update({n: value_schema(n, p) for n, p in fields_for(v, name).items()})
        for field in required_for(v, name):
            if v["properties"][field]["kind"] == "object" and v["properties"][field]["multiple"]:
                properties[field]["minItems"] = max(1, properties[field].get("minItems", 0))
        defs[name] = record(properties, ["id", "type"] + required_for(v, name))
        if name in ("Quantity", "AreaMeasurement"):
            defs[name]["allOf"] = [
                {"if": {"properties": {"evidenceStatus": {"const": "unknown"}}},
                 "then": {"properties": {"value": {"type": "null"}}},
                 "else": {"properties": {"value": {"type": "number"}}}}
            ]
    schema = record({
        "schemaVersion": {"const": v["version"]},
        "modelId": ID_SCHEMA, "projectId": ID_SCHEMA, "revisionId": ID_SCHEMA,
        "entities": {"type": "array", "minItems": 1,
                     "items": {"oneOf": [{"$ref": "#/$defs/" + n} for n in v["classes"] if n != "ModelDocument"]}}
    })
    schema.update({"$schema": "https://json-schema.org/draft/2020-12/schema",
                   "$id": "urn:akm:construction:schema:residential-model:" + v["version"], "$defs": defs})
    (root / "schemas").mkdir(exist_ok=True)
    (root / "schemas/residential-model.schema.json").write_text(json.dumps(schema, ensure_ascii=False, indent=2) + "\n")

    ontology, shapes = Graph(), Graph()
    for g in (ontology, shapes):
        for prefix, ns in [("kco", k), ("owl", OWL), ("rdfs", RDFS), ("xsd", XSD), ("sh", SH)]:
            g.bind(prefix, ns)
    ontology.add((k.ontology, RDF.type, OWL.Ontology))
    ontology.add((k.ontology, OWL.versionInfo, Literal(v["version"])))
    ontology.add((k.ontology, RDFS.comment, Literal(v["namespaceStatus"], lang="en")))
    datatypes = {"string": XSD.string, "number": XSD.decimal, "integer": XSD.integer, "boolean": XSD.boolean, "json": RDF.JSON}
    for name, c in v["classes"].items():
        ontology.add((k[name], RDF.type, OWL.Class))
        ontology.add((k[name], RDFS.label, Literal(c["label"], lang="ko")))
        ontology.add((k[name], RDFS.comment, Literal(c["definition"], lang="ko")))
        if c["parent"]: ontology.add((k[name], RDFS.subClassOf, k[c["parent"]]))
    def union(classes):
        if len(classes) == 1: return k[classes[0]]
        node, head = BNode(), BNode()
        ontology.add((node, RDF.type, OWL.Class))
        ontology.add((node, OWL.unionOf, head))
        Collection(ontology, head, [k[x] for x in classes])
        return node
    for name, p in v["properties"].items():
        ontology.add((k[name], RDF.type, OWL.ObjectProperty if p["kind"] == "object" else OWL.DatatypeProperty))
        ontology.add((k[name], RDFS.label, Literal(p["label"], lang="ko")))
        ontology.add((k[name], RDFS.comment, Literal(p["definition"], lang="ko")))
        ontology.add((k[name], RDFS.domain, union(p["domains"])))
        ontology.add((k[name], RDFS.range, union(p["ranges"]) if p["kind"] == "object" else datatypes[p["type"]]))
    for m in v["externalMappings"]: ontology.add((k[m["term"]], RDFS.seeAlso, URIRef(m["target"])))

    for name in v["classes"]:
        shape = k[name + "Shape"]
        shapes.add((shape, RDF.type, SH.NodeShape))
        shapes.add((shape, SH.targetClass, k[name]))
        # Each most-specific class contract includes inherited properties.
        # Parent shapes stay open so subclasses do not conflict with them.
        required = required_for(v, name)
        for field, p in fields_for(v, name).items():
            ps = BNode()
            shapes.add((shape, SH.property, ps))
            shapes.add((ps, SH.path, k[field]))
            if field in required and not p.get("nullable"):
                shapes.add((ps, SH.minCount, Literal(1)))
            if not p["multiple"]: shapes.add((ps, SH.maxCount, Literal(1)))
            if p["kind"] == "object":
                shapes.add((ps, SH.nodeKind, SH.IRI))
                if len(p["ranges"]) == 1: shapes.add((ps, SH["class"], k[p["ranges"][0]]))
                else:
                    head = BNode(); choices = []
                    for c in p["ranges"]:
                        choice = BNode(); shapes.add((choice, SH["class"], k[c])); choices.append(choice)
                    Collection(shapes, head, choices); shapes.add((ps, SH["or"], head))
            else:
                shapes.add((ps, SH.datatype, datatypes[p["type"]]))
                if "enum" in p:
                    head = BNode()
                    Collection(shapes, head, [Literal(x, datatype=datatypes[p["type"]]) for x in p["enum"]])
                    shapes.add((ps, SH["in"], head))
    # Unknown/known is a semantic condition, not just an optional numeric property.
    constraint = BNode()
    shapes.add((k.QuantityShape, SH.sparql, constraint))
    shapes.add((constraint, SH.message, Literal("Quantity unknown/value state mismatch")))
    shapes.add((constraint, SH.select, Literal("""
PREFIX kco: <urn:akm:construction:>
SELECT $this WHERE {
  $this kco:evidenceStatus ?state .
  OPTIONAL { $this kco:value ?value }
  FILTER ((?state = "unknown" && BOUND(?value)) || (?state != "unknown" && !BOUND(?value)))
}
""")))
    ontology.serialize(root / "ontology.ttl", format="turtle")
    shapes.serialize(root / "shapes.ttl", format="turtle")
    context = {"@version": 1.1, "@vocab": str(k), "id": "@id", "type": "@type"}
    for name, p in v["properties"].items():
        if p["kind"] == "object":
            context[name] = {"@id": str(k[name]), "@type": "@id"}
            if p["multiple"]: context[name]["@container"] = "@set"
        elif p["type"] == "json": context[name] = {"@id": str(k[name]), "@type": "@json"}
    (root / "context.jsonld").write_text(json.dumps({"@context": context}, ensure_ascii=False, indent=2) + "\n")
    wordbook = root / "24-vocabulary-reference.md"
    front = wordbook.read_text().split("\n# ", 1)[0] if wordbook.is_file() else "---\ndescription: Generated residential vocabulary.\nakmLayer: knowledge\nakmRole: reusable-knowledge\nakmType: guide\ntrustLevel: unverified\nsourceType: synthesis\nCMDS: Develop\nnextAction: verify\ndate created: 2026-09-05\ndate modified: 2026-09-05\ntags: [construction, korea, ontology]\n---\n"
    wordbook.write_text(front + "\n" + vocabulary_reference(v))
    print(json.dumps({"classes": len(v["classes"]), "objectProperties": sum(p["kind"]=="object" for p in v["properties"].values()), "dataProperties": sum(p["kind"]=="data" for p in v["properties"].values()), "ontologyTriples": len(ontology), "shapeTriples": len(shapes)}))


if __name__ == "__main__":
    build()
