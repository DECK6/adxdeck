"""Cross-file release checks; reports contract evidence, never real-house accuracy."""
import argparse
import ast
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator
from rdflib import Graph, RDF, OWL
from rdflib.compare import isomorphic
import validate_model as engine
from build_contracts import vocabulary_reference

ROOT = Path(__file__).resolve().parents[1]


def check():
    results = []
    def record(name, passed, detail):
        results.append({"check": name, "passed": bool(passed), "detail": detail})
    vocab = engine.VOCAB
    schema = engine.SCHEMA
    Draft202012Validator.check_schema(schema)
    ontology = Graph().parse(ROOT / "ontology.ttl")
    shapes = Graph().parse(ROOT / "shapes.ttl")
    record("declared-classes", set(ontology.subjects(RDF.type, OWL.Class)) >= {engine.K[k] for k in vocab["classes"]}, len(vocab["classes"]))
    for kind, owl_kind in (("object", OWL.ObjectProperty), ("data", OWL.DatatypeProperty)):
        names = {engine.K[k] for k,p in vocab["properties"].items() if p["kind"] == kind}
        record("declared-" + kind + "-properties", names == set(ontology.subjects(RDF.type, owl_kind)), len(names))
    record("legacy-core", len(vocab["legacyCoreClasses"]) == 50 and len(vocab["legacyCoreRelations"]) == 34
           and set(vocab["legacyCoreClasses"]) <= set(vocab["classes"]) and set(vocab["legacyCoreRelations"]) <= set(vocab["properties"]), "50 classes; 34 relations")
    raw = json.loads((ROOT / "rules.json").read_text())["rules"]
    bridge = json.loads((ROOT / "rule-contracts.json").read_text())
    record("legacy-records-preserved", raw == [r["legacyRecord"] for r in bridge["rules"]], len(raw))
    record("no-activated-legal-rules", all(r["automationStatus"] == "reference_only" and r["legalApplicabilityVerified"] is False for r in bridge["rules"]), len(bridge["rules"]))
    sources = json.loads((ROOT / "sources.json").read_text())
    source_ids = {s["id"] for s in sources}
    record("unique-sources", len(source_ids) == len(sources), len(sources))
    record("rule-source-links", all(set(r["sourceIds"]) <= source_ids for r in raw), len(raw))
    profiles = json.loads((ROOT / "library/residential-profiles.json").read_text())
    record("profile-source-links", all(set(p["sourceIds"]) <= source_ids for p in profiles["profiles"]), len(profiles["profiles"]))
    record("residential-only", {p["legalUse"] for p in profiles["profiles"]} == {"detached","dagagu","dasedae","yeonrip","apartment","unknown"}
           and all(not m["autoResolve"] for m in profiles["colloquialMappings"]), "legal use and colloquial labels stay separate")
    coverage = json.loads((ROOT / "requirement-coverage.json").read_text())
    tests = {n.name for path in (ROOT / "tools").glob("test_*.py") for n in ast.walk(ast.parse(path.read_text()))
             if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")}
    refs = {t for row in coverage["requirements"] + coverage["scenarios"] for t in row["tests"]} | set(coverage.get("reviewRegressionTests",[]))
    record("traceability-test-links", refs <= tests, {"testMethods": len(tests), "missing": sorted(refs-tests)})
    paths = {p for row in coverage["requirements"] for p in row["artifacts"]}
    record("traceability-artifact-links", all((ROOT / p).is_file() for p in paths), sorted(paths))
    record("traceability-scope", len(coverage["requirements"]) == 12 and len(coverage["scenarios"]) == 10, "ontology contract scope; downstream tests retained")
    wordbook = (ROOT / "24-vocabulary-reference.md").read_text()
    record("markdown-vocabulary-sync", wordbook.split("\n# ",1)[-1] == vocabulary_reference(vocab).removeprefix("# "), "all class/property definitions match the canonical vocabulary")
    versioned_paths = ["rule-contracts.json", "library/residential-profiles.json", "library/component-types.json",
                       "benchmark-contract.json", "output-contracts.json", "requirement-coverage.json", "migration-manifest.json", "legal-review-2026-09-05.json", "library/floor-systems-legal-reference.json"]
    record("contract-version-sync", all(json.loads((ROOT / p).read_text())["schemaVersion"] == vocab["version"] for p in versioned_paths)
           and schema["properties"]["schemaVersion"]["const"] == vocab["version"], vocab["version"])
    expression = Draft202012Validator({"$ref":"#/$defs/Expression", "$defs":schema["$defs"]})
    record("all-rule-expressions", all(expression.is_valid(r[k]) for r in bridge["rules"] for k in
           ("applicabilityExpression","exceptionExpression","requirementExpression")), len(bridge["rules"])*3)
    ledger = json.loads((ROOT / "legal-review-2026-09-05.json").read_text())
    reviews = {r["id"]:r for r in ledger["reviews"]}
    record("legal-review-links", all(set(r["sourceIds"]) <= source_ids for r in reviews.values())
           and all(r.get("currentReviewId") in reviews for r in bridge["rules"] if "currentReviewId" in r), len(reviews))
    record("legal-review-guard", all(r["automationStatus"] == "reference_only" and not r["legalApplicabilityVerified"]
           and r["missingInputResult"] == "UNKNOWN" for r in reviews.values()), "source reading does not activate project rules")
    library = json.loads((ROOT / "library/component-types.json").read_text())
    parameters = {p["id"]:p for p in library["parameters"]}
    contract_errors = []
    for entity in library["parameters"] + [c["definition"] for c in library["types"]]:
        contract = {"$ref":"#/$defs/"+entity["type"], "$defs":schema["$defs"]}
        if not Draft202012Validator(contract).is_valid(entity):
            contract_errors.append(entity["id"])
    record("library-entity-contracts", not contract_errors, contract_errors)
    record("library-parameter-links", all(set(t["parameters"]) == set(t["definition"]["hasParameter"])
           and set(t["parameters"]) <= set(parameters) for t in library["types"]), len(library["types"]))
    floors = json.loads((ROOT / "library/floor-systems-legal-reference.json").read_text())
    record("floor-reference-links", floors["legalReviewId"] in reviews and set(floors["sourceIds"]) <= source_ids
           and all(set(s["sourceIds"]) <= source_ids for s in floors["systems"]), len(floors["systems"]))
    record("floor-alternatives-remain-scoped", floors["selection"] == "recognized_system OR applicable_standard_form"
           and not floors["isNationalDefault"] and not floors["isVerifiedProductLibrary"]
           and all(not s["projectApplicabilityVerified"] and not s["materialAndProductVerified"] for s in floors["systems"]), "reference systems; not universal defaults")
    for name in ("detached", "villa", "apartment"):
        m = json.loads((ROOT / "examples" / (name + ".json")).read_text())
        errors = engine.validate_model(m)
        record(name + "-json-and-semantics", not errors, errors)
        conforms, _, message = engine.shacl_validate(m)
        record(name + "-shacl", conforms, message.strip())
        graph = engine.to_graph(m)
        restored = engine.from_graph(graph)
        record(name + "-rdf-roundtrip", engine.canonical(m) == engine.canonical(restored), len(graph))
        jsonld = engine.to_jsonld(m)
        parsed = Graph().parse(data=json.dumps(jsonld), format="json-ld")
        record(name + "-jsonld-roundtrip", engine.canonical(m) == engine.canonical(engine.from_graph(parsed)), len(parsed))
        for suffix, fmt in (("ttl", "turtle"), ("jsonld", "json-ld")):
            path = ROOT / "examples" / (name + "." + suffix)
            if path.is_file():
                exported = Graph().parse(path, format=fmt)
                # JSON literal lexical order can differ; compare the semantic model.
                record(name + "-export-" + suffix, engine.canonical(m) == engine.canonical(engine.from_graph(exported)), path.name)
            else:
                record(name + "-export-" + suffix, False, "Required published example is missing: " + path.name)
    graph = engine.to_graph(json.loads((ROOT / "examples/apartment.json").read_text()))
    expected = {"unknown-quantities.rq": {"Q-SILL", "Q-WINDOW-HEIGHT"},
                "opening-hosts.rq": {"OPEN-DOOR", "OPEN-WINDOW", "OPEN-STAIR"},
                "unresolved-issues.rq": {"ISSUE-HEIGHT"},
                "derived-outputs.rq": {"PLAN-OUTPUT", "SOLID-WALL", "SCHEDULE"},
                "common-shafts.rq": {"SHAFT"}}
    for name, required in expected.items():
        rows = list(graph.query((ROOT / "queries" / name).read_text()))
        found = {str(row[0]).removeprefix(str(engine.I)) for row in rows}
        record("sparql-" + name, required <= found, {"rows": len(rows), "requiredIDs": sorted(required)})
    # Markdown local links including relative file links; AKM wiki-links checked on publication.
    broken = []
    for p in ROOT.glob("*.md"):
        for target in re.findall(r"\[[^\]]*\]\(([^)\n]+)\)", p.read_text()):
            if target.startswith(("https:", "http:", "#", "/")):
                continue
            target = target.split("#")[0]
            if target and not (p.parent / target).exists():
                broken.append(p.name + " → " + target)
    record("local-markdown-links", not broken, broken)
    return {"schemaVersion": vocab["version"], "checkedAt": datetime.now(timezone.utc).isoformat(),
            "passed": all(r["passed"] for r in results), "checks": results,
            "counts": {"classes": len(vocab["classes"]), "objectProperties": sum(p["kind"]=="object" for p in vocab["properties"].values()),
                       "dataProperties": sum(p["kind"]=="data" for p in vocab["properties"].values()), "rules": len(raw),
                       "sources": len(sources), "ontologyTriples": len(ontology), "shapeTriples": len(shapes)},
            "boundaries": {"realHouseCases": 0, "syntheticFragments": 3, "ifcRoundtripRun": False,
                           "legalApproval": False, "completeDrawingOr3DGenerator": False}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    report = check()
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "checks": len(report["checks"]),
                      "failures": [x for x in report["checks"] if not x["passed"]],
                      "report": str(args.report), "counts": report["counts"]}, ensure_ascii=False))
    raise SystemExit(0 if report["passed"] else 1)
