"""Consumer-side counterexamples, independent of implementation branches."""
import copy
import json
import math
import unittest
from pathlib import Path
from rdflib import Literal, RDF, XSD, Graph, BNode, URIRef
from build_contracts import projection_tree_signature
import validate_model as engine

ROOT = Path(__file__).resolve().parents[1]


class AdversarialModelTests(unittest.TestCase):
    def setUp(self):
        self.model = json.loads((ROOT / "examples/apartment.json").read_text())

    def entity(self, id):
        return next(e for e in self.model["entities"] if e["id"] == id)

    def codes(self):
        return {e["code"] for e in engine.validate_model(self.model)}

    def add(self, id, cls, **values):
        entity = {"id": id, "type": cls, **values}
        self.model["entities"].append(entity)
        return entity

    def type_setup(self):
        self.add("TYPE-A", "TypeDefinition", typeCode="TEST", hasParameter=["PARAM-A"],
                 hostConditions={}, verificationStatus="unverified")
        self.add("PARAM-A", "ParameterDefinition", propertyTerm="assemblyThickness", unit="mm", basis="assembly_total")
        self.entity("WALL-01")["hasType"] = "TYPE-A"
        self.entity("WALL-01")["parameterValues"] = {"assemblyThickness": "Q-WALL-THICKNESS"}

    def test_entities_null_returns_schema_error_instead_of_crashing(self):
        self.model["entities"] = None
        self.assertIn("SCHEMA", self.codes())

    def test_required_relation_set_cannot_be_empty(self):
        self.entity("ASSUMPTION")["usesInput"] = []
        self.assertIn("SCHEMA", self.codes())

    def test_model_scope_must_agree_with_profile(self):
        self.entity("PROFILE")["modelScope"] = "site"
        self.assertIn("CONTEXT_SCOPE", self.codes())

    def test_invalid_calendar_date_rejected(self):
        self.entity("CONTEXT")["applicationDate"] = "2026-02-30"
        self.assertIn("DATE_FORMAT", self.codes())

    def test_known_quantity_cannot_have_unknown_unit(self):
        self.entity("Q-WALL-THICKNESS")["unit"] = "unknown"
        self.assertIn("QUANTITY_UNIT", self.codes())

    def test_negative_wall_thickness_rejected(self):
        self.entity("Q-WALL-THICKNESS")["value"] = -200
        self.assertIn("QUANTITY_DOMAIN", self.codes())

    def test_negative_slab_thickness_rejected(self):
        q = self.entity("Q-SLAB")
        q.update(value=-100, evidenceStatus="assumed", hasInference="ASSUMPTION")
        self.assertIn("QUANTITY_DOMAIN", self.codes())

    def test_wrong_quantity_owner_in_hasquantity_rejected(self):
        self.entity("WALL-01")["hasQuantity"] = ["Q-DOOR-WIDTH"]
        self.assertIn("QUANTITY_OWNER", self.codes())

    def test_opening_width_cannot_use_leaf_basis(self):
        self.entity("Q-DOOR-WIDTH")["basis"] = "leaf_nominal"
        self.assertIn("OPENING_BASIS", self.codes())

    def test_two_doors_cannot_fill_the_same_opening(self):
        door = copy.deepcopy(self.entity("DOOR"))
        door["id"] = "DUPLICATE-DOOR"
        self.model["entities"].append(door)
        self.assertIn("OPENING_FILL", self.codes())

    def test_wall_cannot_be_load_bearing_and_non_load_bearing(self):
        self.entity("WALL-01")["wallRoles"] += ["load_bearing", "non_load_bearing"]
        self.assertIn("WALL_ROLE_CONFLICT", self.codes())

    def test_wall_geometry_must_be_a_path(self):
        self.entity("WALL-01")["hasGeometry"] = "GEOM-FLOOR"
        self.assertIn("WALL_PATH", self.codes())

    def test_polygon_hole_outside_outer_ring_rejected(self):
        self.entity("GEOM-FLOOR")["holes"] = [[[8000,0,0],[9000,0,0],[9000,1000,0],[8000,1000,0],[8000,0,0]]]
        self.assertIn("HOLE_OUTSIDE", self.codes())

    def test_touching_hole_is_not_an_interior_hole(self):
        self.entity("GEOM-FLOOR")["holes"] = [[[0,1000,0],[1000,1000,0],[1000,2000,0],[0,2000,0],[0,1000,0]]]
        self.assertIn("HOLE_BOUNDARY", self.codes())

    def test_overlapping_holes_rejected(self):
        self.entity("GEOM-FLOOR")["holes"].append([[4500,2500,0],[5700,2500,0],[5700,3700,0],[4500,3700,0],[4500,2500,0]])
        self.assertIn("HOLE_OVERLAP", self.codes())

    def test_nonplanar_polygon_rejected(self):
        self.entity("GEOM-FLOOR")["points"][2][2] = 100
        self.assertIn("NONPLANAR_PROFILE", self.codes())

    def test_valid_vertical_polygon_is_not_self_intersecting(self):
        self.add("VERTICAL", "GeometryProfile", geometryKind="polygon",
                 points=[[0,0,0],[0,1000,0],[0,1000,2000],[0,0,2000],[0,0,0]],
                 unit="mm", evidenceStatus="assumed")
        self.assertEqual([], engine.validate_model(self.model))

    def test_stair_hole_in_different_frame_does_not_match(self):
        self.add("SHIFT", "Placement", origin=[1000,0,0], rotationDeg=0, handedness="right", unit="mm")
        self.entity("GEOM-STAIR-HOLE")["hasPlacement"] = "SHIFT"
        self.assertIn("STAIR_HOLE", self.codes())

    def test_type_parameter_missing_quantity_rejected(self):
        self.type_setup()
        self.entity("WALL-01")["parameterValues"]["assemblyThickness"] = "NO-SUCH-QUANTITY"
        self.assertIn("PARAMETER_REFERENCE", self.codes())

    def test_type_parameter_undeclared_name_rejected(self):
        self.type_setup()
        self.entity("WALL-01")["parameterValues"]["inventedWidth"] = "Q-WALL-THICKNESS"
        self.assertIn("PARAMETER_UNDECLARED", self.codes())

    def test_type_parameter_wrong_owner_rejected(self):
        self.type_setup()
        self.entity("WALL-01")["parameterValues"]["assemblyThickness"] = "Q-DOOR-WIDTH"
        self.assertIn("PARAMETER_BINDING", self.codes())

    def test_revision_cycle_rejected(self):
        self.entity("REV-1")["supersedes"] = ["REV-2"]
        self.assertIn("REVISION_CYCLE", self.codes())

    def test_derived_quantity_cycle_rejected(self):
        q = self.entity("Q-WALL-THICKNESS")
        q.update(evidenceStatus="derived", formula="self", inputQuantity=["Q-WALL-THICKNESS"])
        self.assertIn("QUANTITY_CYCLE", self.codes())

    def test_current_output_cannot_depend_on_stale_output(self):
        self.entity("SOLID-WALL")["artifactStatus"] = "stale"
        self.entity("PLAN-OUTPUT")["dependsOn"].append("SOLID-WALL")
        self.assertIn("STALE_DEPENDENCY", self.codes())

    def test_source_change_invalidates_derived_output(self):
        self.entity("WALL-01")["hasSource"] = ["SOURCE"]
        changed = engine.invalidate(self.model, ["SOURCE"])
        output = next(e for e in changed["entities"] if e["id"] == "PLAN-OUTPUT")
        self.assertEqual("stale", output["artifactStatus"])

    def test_current_artifact_cannot_be_stale_quantity_consumer(self):
        self.entity("Q-WALL-THICKNESS").update(evidenceStatus="derived", formula="x", inputQuantity=["Q-LAYER-THICKNESS"], validityStatus="stale")
        self.entity("PLAN-OUTPUT")["dependsOn"].append("Q-WALL-THICKNESS")
        self.assertIn("STALE_DEPENDENCY", self.codes())

    def test_drawing_sheet_membership_must_be_reciprocal(self):
        self.entity("SHEET")["hasView"] = []
        self.assertIn("DRAWING_MEMBERSHIP", self.codes())

    def test_malformed_expression_cannot_vacuously_pass(self):
        with self.assertRaises(ValueError):
            engine.evaluate_expression({"kind": "all_of", "items": []}, {}, {})

    def test_compare_with_missing_evidence_state_stays_unknown(self):
        expr={"kind":"compare","propertyTerm":"width","operator":"gte","value":900,"unit":"mm","basis":"clear"}
        q={"value":1000,"unit":"mm","basis":"clear","validityStatus":"current"}
        self.assertIsNone(engine.evaluate_expression(expr, {}, {"width":q}))

    def test_rdf_import_rejects_silent_unknown_predicate_loss(self):
        graph = engine.to_graph(self.model)
        graph.add((engine.I["WALL-01"], engine.K["undeclaredThickness"], Literal(250)))
        with self.assertRaises(ValueError):
            engine.from_graph(graph)

    def test_rdf_root_cardinality_not_arbitrary_first_value(self):
        graph = engine.to_graph(self.model)
        graph.add((engine.I[self.model["modelId"]], engine.K.modelRevision, engine.I["REV-1"]))
        with self.assertRaises(ValueError):
            engine.from_graph(graph)

    def test_rdf_float_projection_must_not_lose_large_integer(self):
        self.entity("Q-WALL-THICKNESS")["value"] = 9007199254740993
        restored = engine.from_graph(engine.to_graph(self.model))
        actual = next(e for e in restored["entities"] if e["id"] == "Q-WALL-THICKNESS")["value"]
        self.assertEqual(9007199254740993, actual)

    def approval_setup(self):
        self.add("APPROVAL", "ApprovalRecord", approvalScope={
            "projectId":"PROJECT","revisionId":"REV-2","entityIds":["Q-WALL-THICKNESS"]},
            reviewerRole="architect", approvalDecision="approved", createdAt="2026-09-05T08:00:00+00:00",
            hasSource=["SOURCE"])
        self.entity("Q-WALL-THICKNESS").update(approvalStatus="approved", hasApproval="APPROVAL")
        if hasattr(engine, "revision_digest"):
            self.entity("APPROVAL")["approvalScope"]["modelDigest"] = engine.revision_digest(self.model)

    def test_valid_scoped_approval_record(self):
        self.approval_setup()
        self.assertEqual([], engine.validate_model(self.model))

    def test_approval_wrong_project_rejected(self):
        self.approval_setup()
        self.entity("APPROVAL")["approvalScope"]["projectId"]="OTHER-PROJECT"
        self.assertIn("APPROVAL_SCOPE", self.codes())

    def test_approval_wrong_revision_rejected(self):
        self.approval_setup()
        self.entity("APPROVAL")["approvalScope"]["revisionId"]="REV-1"
        self.assertIn("APPROVAL_SCOPE", self.codes())

    def test_approval_wrong_entity_rejected(self):
        self.approval_setup()
        self.entity("APPROVAL")["approvalScope"]["entityIds"]=["DOOR"]
        self.assertIn("APPROVAL_SCOPE", self.codes())

    def test_rejected_approval_cannot_support_approved_quantity(self):
        self.approval_setup()
        self.entity("APPROVAL")["approvalDecision"]="rejected"
        self.assertIn("APPROVAL_DECISION", self.codes())

    def test_approval_without_provenance_rejected(self):
        self.approval_setup()
        del self.entity("APPROVAL")["hasSource"]
        self.assertIn("APPROVAL_PROVENANCE", self.codes())

    def test_document_parent_cannot_claim_another_sheet_view(self):
        other=copy.deepcopy(self.entity("SHEET"))
        other["id"]="OTHER-SHEET"
        self.model["entities"].append(other)
        self.entity("DRAWING")["hasSheet"].append("OTHER-SHEET")
        self.assertIn("DRAWING_MEMBERSHIP", self.codes())

    def test_parameter_only_dependency_is_invalidated(self):
        self.type_setup()
        self.entity("WALL-01").pop("hasQuantity",None)
        changed=engine.invalidate(self.model,["Q-WALL-THICKNESS"])
        self.assertEqual("stale",next(e for e in changed["entities"] if e["id"]=="PLAN-OUTPUT")["artifactStatus"])

    def test_quantity_nan_comparison_stays_unknown(self):
        expr={"kind":"compare","propertyTerm":"width","operator":"gte","value":900,"unit":"mm","basis":"clear"}
        q={"value":float("nan"),"unit":"mm","basis":"clear","evidenceStatus":"field_measured","validityStatus":"current"}
        self.assertIsNone(engine.evaluate_expression(expr,{},{"width":q}))

    def test_rdf_unknown_root_field_must_not_be_lost(self):
        graph=engine.to_graph(self.model)
        graph.add((engine.I[self.model["modelId"]], engine.K.unknownRootField, Literal("valuable")))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_rdf_literal_cannot_masquerade_as_object_reference(self):
        graph=engine.to_graph(self.model)
        graph.remove((engine.I["OPEN-DOOR"],engine.K.voidsElement,None))
        graph.add((engine.I["OPEN-DOOR"],engine.K.voidsElement,Literal(str(engine.I["WALL-01"]))))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_rdf_unlisted_entity_must_not_disappear(self):
        graph=engine.to_graph(self.model)
        graph.add((engine.I["UNLISTED"],RDF.type,engine.K.Wall))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_rdf_unknown_entity_type_must_not_disappear(self):
        graph=engine.to_graph(self.model)
        graph.add((engine.I["WALL-01"],RDF.type,engine.K.UnmodelledStructuralRole))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_view_transform_cannot_collapse_every_point(self):
        self.entity("TRANSFORM")["transformMatrix"]=[[0,0,0,0] for _ in range(4)]
        self.assertIn("TRANSFORM_SINGULAR", self.codes())

    def test_different_length_units_preserve_valid_geometry(self):
        for e in self.model["entities"]:
            if e["type"]=="GeometryProfile":
                e["unit"]="m"
                e["points"]=[[x/1000 for x in p] for p in e["points"]]
                e["holes"]=[[[x/1000 for x in p] for p in h] for h in e.get("holes",[])]
        self.assertEqual([], engine.validate_model(self.model))

    def test_rdf_plain_string_is_valid_rdf11(self):
        graph=engine.to_graph(self.model)
        graph.set((engine.I[self.model["modelId"]],engine.K.schemaVersion,Literal(self.model["schemaVersion"])))
        self.assertEqual(engine.canonical(self.model),engine.canonical(engine.from_graph(graph)))

    def test_rdf_high_precision_decimal_must_not_silently_round(self):
        graph=engine.to_graph(self.model)
        graph.set((engine.I["Q-WALL-THICKNESS"],engine.K.value,Literal("0.1000000000000000001",datatype=XSD.decimal)))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_empty_application_date_is_not_unknown(self):
        self.entity("CONTEXT")["applicationDate"]=""
        self.assertIn("DATE_FORMAT",self.codes())

    def test_revision_timestamp_requires_time_and_timezone(self):
        self.entity("REV-2")["createdAt"]="2026-09-05"
        self.assertIn("DATE_FORMAT",self.codes())

    def test_zero_observed_clearance_can_describe_blocked_passage(self):
        q=copy.deepcopy(self.entity("Q-WALL-THICKNESS"))
        q.update(id="Q-BLOCKED",propertyTerm="clearWidth",value=0,basis="minimum_finished_in_use")
        self.model["entities"].append(q)
        self.assertEqual([],engine.validate_model(self.model))

    def test_space_cannot_contain_itself(self):
        self.entity("SPACE-LIVING")["containsSpace"]=["SPACE-LIVING"]
        self.assertIn("SPATIAL_CYCLE",self.codes())

    def test_revision_change_does_not_reuse_approval(self):
        self.approval_setup()
        changed=engine.invalidate(self.model,["Q-WALL-THICKNESS"])
        q=next(e for e in changed["entities"] if e["id"]=="Q-WALL-THICKNESS")
        self.assertNotEqual("approved",q["approvalStatus"])

    def test_invalidated_model_retains_historical_approval_record(self):
        self.approval_setup()
        changed=engine.invalidate(self.model,["Q-WALL-THICKNESS"])
        self.assertIn("APPROVAL",[e["id"] for e in changed["entities"]])
        self.assertEqual("approved",self.entity("Q-WALL-THICKNESS")["approvalStatus"])

    def test_rdf_invalid_decimal_lexeme_is_rejected(self):
        graph=engine.to_graph(self.model)
        graph.set((engine.I["Q-WALL-THICKNESS"],engine.K.value,Literal("garbage",datatype=XSD.decimal)))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_rdf_wrong_scalar_type_is_rejected(self):
        graph=engine.to_graph(self.model)
        graph.set((engine.I["Q-WALL-THICKNESS"],engine.K.value,Literal("200",datatype=XSD.string)))
        with self.assertRaises(ValueError): engine.from_graph(graph)

    def test_direct_quantity_edit_cannot_keep_old_approval(self):
        self.approval_setup()
        self.entity("Q-WALL-THICKNESS")["value"] += 10
        self.assertIn("APPROVAL_SNAPSHOT",self.codes())

    def test_geometry_edit_cannot_keep_old_approval(self):
        self.approval_setup()
        self.entity("GEOM-WALL")["points"][-1][0] += 100
        self.assertIn("APPROVAL_SNAPSHOT",self.codes())

    def test_approval_fingerprint_survives_rdf_roundtrip(self):
        self.approval_setup()
        self.assertEqual([],engine.validate_model(engine.from_graph(engine.to_graph(self.model))))

    def test_approval_fingerprint_ignores_unordered_edge_order(self):
        self.approval_setup()
        self.model["entities"].reverse()
        self.entity("PROJECT")["hasContext"] = "CONTEXT"
        for e in self.model["entities"]:
            for key,p in engine.VOCAB["properties"].items():
                if p["kind"]=="object" and p["multiple"] and key in e:
                    e[key].reverse()
        self.assertEqual([],engine.validate_model(self.model))

    def test_rule_threshold_must_be_finite(self):
        expr={"kind":"compare","propertyTerm":"width","operator":"gte","value":float("inf"),"unit":"mm","basis":"clear"}
        with self.assertRaises(ValueError):engine.evaluate_expression(expr,{}, {})

    def test_invalid_rdf_boolean_must_not_turn_into_false(self):
        graph=engine.to_graph(self.model)
        # A documented Boolean data property on the existing artifact.
        graph.set((engine.I["ASSESSMENT"],engine.K.isWholeBuildingApproval,Literal("not-a-boolean",datatype=XSD.boolean)))
        with self.assertRaises(ValueError):engine.from_graph(graph)

    def test_projection_comparison_ignores_blank_ids_but_preserves_values(self):
        p=URIRef("urn:test:p");root=URIRef("urn:test:root")
        a,b=Graph(),Graph();x,y=BNode(),BNode()
        a.add((root,p,x));a.add((x,p,Literal(1)))
        b.add((root,p,y));b.add((y,p,Literal(1)))
        self.assertEqual(projection_tree_signature(a),projection_tree_signature(b))
        b.set((y,p,Literal(2)))
        self.assertNotEqual(projection_tree_signature(a),projection_tree_signature(b))

    def test_projection_comparison_rejects_shared_or_cyclic_blank_nodes(self):
        p=URIRef("urn:test:p");a=Graph();x=BNode()
        a.add((URIRef("urn:test:one"),p,x));a.add((URIRef("urn:test:two"),p,x))
        with self.assertRaises(ValueError):projection_tree_signature(a)
        b=Graph();y,z=BNode(),BNode();b.add((y,p,z));b.add((z,p,y))
        with self.assertRaises(ValueError):projection_tree_signature(b)


if __name__ == "__main__":
    unittest.main(verbosity=2)
