"""Bounded ontology reference implementation. No OCR, CAD booleans or legal approval."""
import argparse
import copy
import json
import math
from decimal import Decimal
from pathlib import Path

from jsonschema import Draft202012Validator
from rdflib import Graph, Literal, Namespace, RDF, RDFS, XSD, URIRef
from build_contracts import ancestors, fields_for, required_for
from model_checks import audit_invariants, check_profile, world_ring, equal_rings, revision_digest as _revision_digest

ROOT = Path(__file__).resolve().parents[1]
VOCAB = json.loads((ROOT / "vocabulary.json").read_text())
SCHEMA = json.loads((ROOT / "schemas/residential-model.schema.json").read_text())
K = Namespace(VOCAB["namespace"])
I = Namespace(VOCAB["namespace"] + "instance:")
LENGTH = {"mm": 1.0, "m": 1000.0}


def index(model):
    return {e["id"]: e for e in model.get("entities", []) if isinstance(e, dict) and "id" in e}


def is_a(entity, cls):
    return entity.get("type") in VOCAB["classes"] and cls in ancestors(VOCAB, entity["type"])


def canonical(model):
    """Semantic canonicalization: unordered RDF edges; ordered geometry arrays."""
    m = copy.deepcopy(model)
    for e in m["entities"]:
        required = required_for(VOCAB, e["type"])
        for key in list(e):
            p = VOCAB["properties"].get(key)
            if e[key] is None and key not in required:
                del e[key]
            elif p and p["kind"] == "object" and p["multiple"]:
                if not e[key] and key not in required:
                    del e[key]
                else:
                    e[key] = sorted(e[key])
    m["entities"].sort(key=lambda e: e["id"])
    return m


def revision_digest(model):
    return _revision_digest(canonical(model))


def to_graph(model):
    g = Graph()
    g.bind("kco", K)
    g.bind("inst", I)
    root = I[model["modelId"]]
    for p, o in [(RDF.type, K.ModelDocument), (K.schemaVersion, Literal(model["schemaVersion"], datatype=XSD.string)),
                 (K.modelProject, I[model["projectId"]]), (K.modelRevision, I[model["revisionId"]])]:
        g.add((root, p, o))
    dtypes = {"string": XSD.string, "number": XSD.decimal, "integer": XSD.integer, "boolean": XSD.boolean, "json": RDF.JSON}
    for e in model["entities"]:
        s = I[e["id"]]
        g.add((root, K.hasMember, s))
        g.add((s, RDF.type, K[e["type"]]))
        for key, val in e.items():
            if key in ("id", "type") or val is None:
                continue
            p = VOCAB["properties"][key]
            if p["kind"] == "object":
                for target in val if p["multiple"] else [val]:
                    g.add((s, K[key], I[target]))
            else:
                if p["type"] == "json":
                    val = json.dumps(val, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                elif p["type"] == "number":
                    numeric = Decimal(str(val))
                    if not numeric.is_finite():
                        raise ValueError("Cannot export non-finite number")
                    val = format(numeric, "f")
                g.add((s, K[key], Literal(val, datatype=dtypes[p["type"]])))
    return g


def from_graph(g):
    roots = list(g.subjects(RDF.type, K.ModelDocument))
    if len(roots) != 1:
        raise ValueError("Expected exactly one ModelDocument")
    root = roots[0]
    def local(uri):
        if not isinstance(uri, URIRef) or not str(uri).startswith(str(I)):
            raise ValueError("Expected local instance IRI: " + str(uri))
        return str(uri).removeprefix(str(I))
    local(root)
    root_fields = {RDF.type, K.schemaVersion, K.modelProject, K.modelRevision, K.hasMember}
    if set(g.predicates(root)) - root_fields:
        raise ValueError("Unsupported root predicates would be lost")
    if set(g.objects(root, RDF.type)) - {K.ModelDocument, RDFS.Resource}:
        raise ValueError("Unsupported root type would be lost")
    for field in ("schemaVersion", "modelProject", "modelRevision"):
        if len(list(g.objects(root, K[field]))) != 1:
            raise ValueError("Root cardinality violation: " + field)
    version = g.value(root, K.schemaVersion)
    if not isinstance(version, Literal) or version.language or version.datatype not in (None, XSD.string):
        raise ValueError("schemaVersion must be an xsd:string")
    members = set(g.objects(root, K.hasMember))
    for member in members:
        local(member)
    if root in members:
        raise ValueError("Root cannot also be a member")
    unlisted = {s for s in g.subjects() if str(s).startswith(str(I))} - members - {root}
    if unlisted:
        raise ValueError("Unlisted local instances would be lost: " + str(unlisted))
    model = {"schemaVersion": str(g.value(root, K.schemaVersion)), "modelId": local(root),
             "projectId": local(g.value(root, K.modelProject)), "revisionId": local(g.value(root, K.modelRevision)), "entities": []}
    datatypes = {"string": XSD.string, "number": XSD.decimal, "integer": XSD.integer, "boolean": XSD.boolean, "json": RDF.JSON}
    for s in members:
        if set(g.objects(s, RDF.type)) - {K[t] for t in VOCAB["classes"]} - {RDFS.Resource}:
            raise ValueError("Unsupported entity type would be lost: " + str(s))
        types = [str(t).removeprefix(str(K)) for t in g.objects(s, RDF.type) if str(t).removeprefix(str(K)) in VOCAB["classes"]]
        # Supports asserted or RDFS-enriched graphs: choose one most-specific type.
        types = [t for t in types if not any(t != u and t in ancestors(VOCAB, u) for u in types)]
        if len(types) != 1:
            raise ValueError("Ambiguous entity type: " + str(s))
        name = types[0]
        allowed = {K[key] for key in fields_for(VOCAB, name)} | {RDF.type}
        unsupported = {p for p in g.predicates(s) if p not in allowed}
        if unsupported:
            raise ValueError("Unsupported predicates would be lost: " + str(unsupported))
        e = {"id": local(s), "type": name}
        for key, p in fields_for(VOCAB, name).items():
            vals = list(g.objects(s, K[key]))
            if not vals:
                if key in required_for(VOCAB, name) and p.get("nullable"):
                    e[key] = None
                continue
            if not p["multiple"] and len(vals) != 1:
                raise ValueError("Multiple values for " + key)
            if p["kind"] == "object":
                for target in vals:
                    local(target)
                    if target not in members:
                        raise ValueError("Object reference is not a model member: " + str(target))
                e[key] = sorted(local(v) for v in vals) if p["multiple"] else local(vals[0])
            else:
                expected = (None, XSD.string) if p["type"] == "string" else (datatypes[p["type"]],)
                if not isinstance(vals[0], Literal) or vals[0].language or vals[0].datatype not in expected:
                    raise ValueError("Incorrect literal datatype: " + key)
                if vals[0].ill_typed:
                    raise ValueError("Invalid RDF literal lexical form: " + key)
                value = json.loads(str(vals[0])) if p["type"] == "json" else vals[0].toPython()
                if isinstance(value, Decimal):
                    if not value.is_finite():
                        raise ValueError("Non-finite decimal")
                    converted = int(value) if value == value.to_integral_value() else float(value)
                    if Decimal(str(converted)) != value:
                        raise ValueError("Decimal is not losslessly representable in this JSON number contract")
                    value = converted
                if isinstance(value, Literal):
                    raise ValueError("Invalid RDF literal lexical value: " + key)
                e[key] = value
        model["entities"].append(e)
    return model


def to_jsonld(model):
    """Produce real JSON-LD, not a plain JSON document with a context pasted on."""
    context = json.loads((ROOT / "context.jsonld").read_text())["@context"]
    return json.loads(to_graph(model).serialize(format="json-ld", context=context, auto_compact=True))


def transform_point(point, origin, rotation_deg, handedness, source_unit, target_unit):
    if source_unit not in LENGTH or target_unit not in LENGTH:
        raise ValueError("Placement requires a length unit")
    if handedness not in ("right", "mirrored"):
        raise ValueError("Unknown handedness")
    x, y, z = point
    if handedness == "mirrored":
        x = -x
    a = math.radians(rotation_deg)
    scale = LENGTH[source_unit] / LENGTH[target_unit]
    return [(x * math.cos(a) - y * math.sin(a) + origin[0]) * scale,
            (x * math.sin(a) + y * math.cos(a) + origin[1]) * scale,
            (z + origin[2]) * scale]


def wall_offsets(thickness, reference_side, interior_side):
    if thickness <= 0 or interior_side not in ("left", "right"):
        raise ValueError("Positive thickness and known interior side required")
    offsets = {"center": [-thickness/2, thickness/2], "interior": [-thickness, 0], "exterior": [0, thickness]}[reference_side]
    return offsets if interior_side == "left" else sorted(-x for x in offsets)


def quantity_mm(q):
    if q.get("value") is None or q.get("unit") not in LENGTH:
        return None
    return q["value"] * LENGTH[q["unit"]]


def opening_interval(model, opening_id):
    by = index(model)
    op = by[opening_id]
    off = quantity_mm(by[op["offsetQuantity"]])
    width = quantity_mm(by[op["widthQuantity"]])
    return None if off is None or width is None else [off, off + width]


def invalidate(model, changed_ids):
    """Pure invalidation; observations and previous model are never rewritten."""
    m = copy.deepcopy(model)
    dirty = set(changed_ids)
    while True:
        previous = len(dirty)
        for e in m["entities"]:
            references = set()
            for key, p in VOCAB["properties"].items():
                if p["kind"] == "object" and key in e and key not in ("belongsToRevision", "derivedFromRevision"):
                    references.update(e[key] if p["multiple"] else [e[key]])
            references.update(e.get("parameterValues", {}).values())
            # Includes host, quantitySubject, geometry and assembly dependencies.
            if references & dirty:
                dirty.add(e["id"])
            if e["id"] in dirty:
                if e.get("approvalStatus") in ("approved", "reviewed"):
                    e["approvalStatus"] = "proposed"
                    e.pop("hasApproval", None)
                if is_a(e, "DerivedArtifact"):
                    e["artifactStatus"] = "stale"
                if is_a(e, "Quantity") and e.get("evidenceStatus") == "derived":
                    e["validityStatus"] = "stale"
        if len(dirty) == previous:
            return m


def evaluate_expression(expr, facts, quantities, _checked=False):
    """Kleene three-valued logic. Caller supplies evidenced facts, never text eval."""
    if not _checked:
        contract = {"$ref":"#/$defs/Expression", "$defs":SCHEMA["$defs"]}
        def finite_expression(value):
            if isinstance(value,float):
                return math.isfinite(value)
            if isinstance(value,dict):
                return all(finite_expression(v) for v in value.values())
            if isinstance(value,list):
                return all(finite_expression(v) for v in value)
            return True
        if not finite_expression(expr) or not Draft202012Validator(contract).is_valid(expr):
            raise ValueError("Invalid expression contract")
    kind = expr["kind"]
    if kind in ("all_of", "any_of"):
        values = [evaluate_expression(x, facts, quantities, True) for x in expr["items"]]
        if kind == "all_of":
            return False if False in values else (None if None in values else True)
        return True if True in values else (None if None in values else False)
    if kind == "not":
        value = evaluate_expression(expr["item"], facts, quantities, True)
        return None if value is None else not value
    if kind == "fact":
        val = facts.get(expr["factCode"])
        return None if type(val) is not bool else val == expr["expected"]
    if kind == "evidence_required":
        return facts.get(expr["requirementCode"]) if type(facts.get(expr["requirementCode"])) is bool else None
    if kind == "compare":
        q = quantities.get(expr["propertyTerm"])
        if not q or type(q.get("value")) not in (int, float) or q.get("evidenceStatus") not in ("source_observed","field_measured","derived") or q.get("validityStatus") != "current":
            return None
        if isinstance(q["value"],float) and not math.isfinite(q["value"]):
            return None
        if q.get("propertyTerm",expr["propertyTerm"]) != expr["propertyTerm"]:
            return None
        if q.get("unit") != expr["unit"] or q.get("basis") != expr["basis"]:
            return None
        value, threshold = q["value"], expr["value"]
        return {"gte": value >= threshold, "lte": value <= threshold, "eq": value == threshold}[expr["operator"]]
    raise ValueError("Unsupported expression kind: " + kind)


def evaluate_rule(contract, facts, quantities):
    """Rule-local result; missing edition, exceptions or project scope blocks PASS."""
    if contract["automationStatus"] != "project_verified" or contract.get("formalizationReviewStatus") != "reviewed":
        return "UNKNOWN"
    if contract["authority"] in ("LAW", "NOTICE") and contract.get("legalApplicabilityVerified") is not True:
        return "UNKNOWN"
    applicable = evaluate_expression(contract["applicabilityExpression"], facts, quantities)
    if applicable is False:
        return "NOT_APPLICABLE"
    if applicable is None:
        return "UNKNOWN"
    exceptions = evaluate_expression(contract["exceptionExpression"], facts, quantities)
    if exceptions is None:
        return "UNKNOWN"
    if exceptions:
        return "NOT_APPLICABLE"
    result = evaluate_expression(contract["requirementExpression"], facts, quantities)
    return "UNKNOWN" if result is None else ("PASS" if result else "FAIL")


def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def segments_intersect(a, b, c, d):
    eps = 1e-8  # Floating-point guard, not a construction tolerance.
    def on(p, q, r):
        return abs(cross(p, q, r)) < eps and min(p[0], q[0])-eps <= r[0] <= max(p[0], q[0])+eps and min(p[1], q[1])-eps <= r[1] <= max(p[1], q[1])+eps
    return (cross(a,b,c)*cross(a,b,d) < 0 and cross(c,d,a)*cross(c,d,b) < 0) or on(a,b,c) or on(a,b,d) or on(c,d,a) or on(c,d,b)


def ring_self_intersects(ring):
    n = len(ring)-1
    return any(segments_intersect(ring[i], ring[i+1], ring[j], ring[j+1])
               for i in range(n) for j in range(i+2, n) if not (i == 0 and j == n-1))


def validate_model(model):
    errors = []
    def fail(code, entity, message):
        errors.append({"code": code, "entity": entity, "message": message})
    def finite(value, path=""):
        if isinstance(value, float) and not math.isfinite(value):
            fail("NON_FINITE", path, "JSON numbers must be finite")
        elif isinstance(value, dict):
            for key, item in value.items():
                finite(item, path + "/" + key)
        elif isinstance(value, list):
            for n, item in enumerate(value):
                finite(item, path + "/" + str(n))
    finite(model)
    for err in Draft202012Validator(SCHEMA).iter_errors(model):
        fail("SCHEMA", "/".join(str(x) for x in err.absolute_path), err.message[:250])
    if errors:
        # Schema-invalid input must produce diagnostics, never crash semantic code.
        candidates = model.get("entities", []) if isinstance(model, dict) else []
        for e in candidates if isinstance(candidates,list) else []:
            if isinstance(e, dict) and e.get("type") in ("Quantity", "AreaMeasurement") and (e.get("evidenceStatus") == "unknown") != (e.get("value") is None):
                fail("UNKNOWN_VALUE", e.get("id"), "unknown iff numeric value is null")
        return errors
    by = index(model)
    entities = list(by.values())
    if len(by) != len(model.get("entities", [])) or model.get("modelId") in by:
        fail("DUPLICATE_ID", model.get("modelId"), "Entity and model IDs must be unique")
    for key, cls in (("projectId", "Project"), ("revisionId", "ModelRevision")):
        if not is_a(by.get(model.get(key), {}), cls):
            fail("ROOT_REFERENCE", key, "Missing or incorrectly typed root reference")
    for e in entities:
        eid = e["id"]
        if e.get("type") not in VOCAB["classes"]:
            continue
        for key, p in fields_for(VOCAB, e["type"]).items():
            if p["kind"] != "object" or key not in e:
                continue
            vals = e[key] if p["multiple"] and isinstance(e[key], list) else [e[key]]
            for target in vals:
                if not isinstance(target, str) or target not in by:
                    fail("REFERENCE_MISSING", eid, key + " missing target")
                elif not any(is_a(by[target], r) for r in p["ranges"]):
                    fail("REFERENCE_TYPE", eid, key + " invalid target type: " + target)
        if is_a(e, "Quantity"):
            unknown = e.get("evidenceStatus") == "unknown"
            if unknown != (e.get("value") is None):
                fail("UNKNOWN_VALUE", eid, "unknown iff numeric value is null")
            if e.get("evidenceStatus") == "assumed" and not e.get("hasInference"):
                fail("ASSUMPTION_EVIDENCE", eid, "Assumed value requires Inference")
            if e.get("evidenceStatus") == "derived" and not (e.get("formula") and e.get("inputQuantity")):
                fail("DERIVATION_EVIDENCE", eid, "Derived value requires formula and input quantities")
            if e.get("evidenceStatus") in ("source_observed", "field_measured") and not (e.get("hasEvidence") or e.get("hasSource")):
                fail("OBSERVATION_EVIDENCE", eid, "Observed value requires a source/evidence reference")
            if e.get("uncertainty") is not None and e["uncertainty"] < 0:
                fail("UNCERTAINTY", eid, "Uncertainty cannot be negative")
        if e.get("approvalStatus") == "approved" and not e.get("hasApproval"):
            fail("APPROVAL_EVIDENCE", eid, "Approval requires a scoped ApprovalRecord")
        if is_a(e, "Placement"):
            if e.get("unit") not in LENGTH:
                fail("GEOMETRY_UNIT", eid, "Placement unit must be mm or m")
            seen, cur = set(), eid
            while cur in by:
                if cur in seen:
                    fail("PLACEMENT_CYCLE", eid, "Parent placements form a cycle")
                    break
                seen.add(cur)
                cur = by[cur].get("relativeTo")
        if is_a(e, "GeometryProfile"):
            if e.get("unit") not in LENGTH:
                fail("GEOMETRY_UNIT", eid, "Profile unit must be mm or m")
            check_profile(e, fail)
        if is_a(e, "Opening"):
            host = by.get(e.get("voidsElement"), {})
            if host and not any(is_a(host, cls) for cls in ("Wall", "Slab", "Roof")):
                fail("REFERENCE_TYPE", eid, "Opening host must be Wall, Slab or Roof")
            for key, term in [("offsetQuantity", "hostOffset"), ("widthQuantity", "roughOpeningWidth"), ("heightQuantity", "roughOpeningHeight"), ("baseHeightQuantity", "openingBaseHeight")]:
                q = by.get(e.get(key), {})
                if q and (q.get("quantitySubject") != eid or q.get("propertyTerm") != term or q.get("unit") not in LENGTH):
                    fail("QUANTITY_BINDING", eid, key + " subject, role or unit mismatch")
                if key in ("widthQuantity", "heightQuantity") and q.get("value") is not None and q["value"] <= 0:
                    fail("OPENING_DIMENSION", eid, "Known opening width and height must be positive")
            if host.get("belongsToStorey") and e.get("belongsToStorey") != host["belongsToStorey"]:
                fail("OPENING_STOREY", eid, "Opening and host storey must agree")
            face = by.get(e.get("hasHostFace"), {})
            if face and face.get("faceOf") != host.get("id"):
                fail("HOST_FACE", eid, "HostFace belongs to another wall")
            if is_a(host, "Wall"):
                geom = by.get(host.get("hasGeometry"), {})
                points = geom.get("points", [])
                if len(points) >= 2 and all(isinstance(p, list) and len(p) == 3 for p in points):
                    length = sum(math.dist(a,b) for a,b in zip(points, points[1:])) * LENGTH.get(geom.get("unit"), 1)
                    try:
                        span = opening_interval(model, eid)
                    except (KeyError, TypeError):
                        span = None
                    if span and (span[0] < 0 or span[1] > length or span[1] <= span[0]):
                        fail("OPENING_OUTSIDE_HOST", eid, "Opening interval exceeds host path")
        if is_a(e, "Stair") and "usesOpening" in e:
            op = by.get(e["usesOpening"], {})
            if not is_a(by.get(op.get("voidsElement"), {}), "Slab"):
                fail("STAIR_SLAB_OPENING", eid, "Stair must link to a slab opening")
            if e.get("endStorey") != op.get("belongsToStorey"):
                fail("STAIR_STOREY", eid, "Stair end and opening storey must agree")
            slab = by.get(op.get("voidsElement"), {})
            slab_profile = by.get(slab.get("hasGeometry"), {})
            hole_profile = by.get(op.get("hasGeometry"), {})
            if is_a(slab, "Slab"):
                try:
                    wanted = world_ring(by,hole_profile,op,hole_profile.get("points",[]))
                    holes = [world_ring(by,slab_profile,slab,r) for r in slab_profile.get("holes",[])]
                    match = any(equal_rings(wanted,hole) for hole in holes)
                except ValueError:
                    match = False
                if not match:
                    fail("STAIR_HOLE", eid, "Stair opening profile must occur among the slab holes in the same local frame")
        if is_a(e, "DimensionAnnotation"):
            q = by.get(e.get("dimensionQuantity"), {})
            if q.get("quantitySubject") != e.get("annotates"):
                fail("DIMENSION_BINDING", eid, "Dimension and quantity subjects differ")
        if is_a(e, "Assembly"):
            orders = [by.get(layer, {}).get("layerOrder") for layer in e.get("hasLayer", [])]
            if not orders or len(orders) != len(set(orders)) or any(x is None or x < 0 for x in orders):
                fail("LAYER_ORDER", eid, "Assembly layers need distinct nonnegative order values")
        if is_a(e, "ReconstructionIssue") and e.get("issueStatus") == "resolved":
            if not (e.get("hasApproval") and e.get("hasEvidence")):
                fail("CONFLICT_RESOLUTION_EVIDENCE", eid, "Resolved issue requires evidence and scoped review")
        if is_a(e, "ScaleCalibration") and e.get("calibrationStatus") == "verified":
            checks = e.get("calibrationChecks", [])
            if len({x.get("dimensionId") for x in checks}) < 2:
                fail("CALIBRATION_INSUFFICIENT", eid, "At least two distinct check dimensions are required by this project contract")
            for check in checks:
                if not is_a(by.get(check.get("dimensionId"), {}), "DimensionAnnotation"):
                    fail("CALIBRATION_REFERENCE", eid, "Calibration dimension must exist")
                else:
                    dimension = by[check["dimensionId"]]
                    q = by.get(dimension.get("dimensionQuantity"), {})
                    observed_mm = quantity_mm(q)
                    if observed_mm is None or not math.isclose(observed_mm, check["modelLengthMm"], rel_tol=0, abs_tol=1e-7):
                        fail("CALIBRATION_MEASUREMENT", eid, "Check length must match its referenced dimension Quantity")
        if is_a(e, "DerivedArtifact") and e.get("artifactStatus") == "current" and e.get("derivedFromRevision") != model.get("revisionId"):
            fail("STALE_REVISION", eid, "Current derived output must use current model revision")
        if is_a(e, "DesignBrief") and e.get("outputPurpose") == "design_documents":
            # This reference release has no project approval/discipline signoff engine.
            fail("OUTPUT_UNVERIFIED", eid, "This contract validator cannot release design/construction documents; unresolved inputs and discipline approval need downstream validation")
    audit_invariants({**model, "_reviewDigest": revision_digest(model)}, by, is_a, fail)
    return errors


def shacl_validate(model):
    from pyshacl import validate
    conforms, report, message = validate(to_graph(model), shacl_graph=str(ROOT / "shapes.ttl"),
                                        ont_graph=str(ROOT / "ontology.ttl"), inference="rdfs")
    return bool(conforms), report, message


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("--shacl", action="store_true")
    parser.add_argument("--rdf-out", type=Path)
    args = parser.parse_args()
    model = json.loads(args.model.read_text())
    errors = validate_model(model)
    if args.shacl and not errors:
        conforms, _, message = shacl_validate(model)
        if not conforms:
            errors.append({"code": "SHACL", "message": message})
    if args.rdf_out and not errors:
        to_graph(model).serialize(args.rdf_out, format="turtle")
    print(json.dumps({"model": str(args.model), "contractValid": not errors, "errors": errors,
                      "isLegalApproval": False, "isReconstructionAccuracyTest": False}, ensure_ascii=False, indent=2))
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
