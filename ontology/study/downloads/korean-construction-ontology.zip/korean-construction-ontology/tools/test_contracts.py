"""Acceptance tests for the ontology contract, not house-design accuracy."""
import copy
import json
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


class MaterializationTests(unittest.TestCase):
    def test_legacy_preserved(self):
        legacy = json.loads((ROOT / "rules.json").read_text())["rules"]
        bridge = json.loads((ROOT / "rule-contracts.json").read_text())["rules"]
        self.assertEqual(69, len(legacy))
        self.assertEqual(legacy, [r["legacyRecord"] for r in bridge])
        v = json.loads((ROOT / "vocabulary.json").read_text())
        self.assertTrue(all(r["subject"] in v["classes"] for r in legacy))
        sources = {s["id"] for s in json.loads((ROOT / "sources.json").read_text())}
        self.assertTrue(all(set(r["sourceIds"]) <= sources for r in bridge))

    def test_library_parameters_and_classes(self):
        import validate_model as engine
        data = json.loads((ROOT / "library/component-types.json").read_text())
        v = engine.VOCAB
        params = {p["id"]: p for p in data["parameters"]}
        self.assertEqual(13, len(data["types"]))
        for p in params.values():
            Draft202012Validator({"$ref": "#/$defs/ParameterDefinition", "$defs": engine.SCHEMA["$defs"]}).validate(p)
        for card in data["types"]:
            self.assertIn(card["componentClass"], v["classes"])
            self.assertTrue(set(card["parameters"]) <= set(params))
            self.assertEqual({}, card["defaultParameterValues"])
            Draft202012Validator({"$ref": "#/$defs/TypeDefinition", "$defs": engine.SCHEMA["$defs"]}).validate(card["definition"])

    def test_rule_contracts_schema_and_unknown(self):
        import validate_model as engine
        data = json.loads((ROOT / "rule-contracts.json").read_text())
        facts = {f["factCode"] for f in data["facts"]}
        def refs(expression):
            if expression["kind"] == "fact": return {expression["factCode"]}
            if expression["kind"] == "evidence_required": return {expression["requirementCode"]}
            if expression["kind"] == "not": return refs(expression["item"])
            return set().union(*(refs(e) for e in expression.get("items", [])))
        for rule in data["rules"]:
            for field in ("applicabilityExpression", "exceptionExpression", "requirementExpression"):
                Draft202012Validator({"$ref": "#/$defs/Expression", "$defs": engine.SCHEMA["$defs"]}).validate(rule[field])
                self.assertTrue(refs(rule[field]) <= facts)
            self.assertEqual("UNKNOWN", engine.evaluate_rule(rule, {}, {}))

    def test_materialized_artifacts_exist(self):
        required = [
            "vocabulary.json", "ontology.ttl", "context.jsonld",
            "schemas/residential-model.schema.json", "shapes.ttl",
            "library/residential-profiles.json", "library/component-types.json",
            "rule-contracts.json", "requirement-coverage.json",
            "examples/detached.json", "examples/villa.json", "examples/apartment.json",
        ]
        self.assertEqual([], [f for f in required if not (ROOT / f).is_file()])

    def test_all_named_extension_classes_exist(self):
        names = "ResidentialUnit CommonArea DesignBrief ParcelBoundary RegulatoryEnvelope DrawingDocument DrawingSheet DrawingView ViewTransform GridAxis Placement GeometryProfile SolidRepresentation HostFace TypeDefinition SpatialBoundary AreaMeasurement DimensionAnnotation Tag Schedule Inference ReconstructionIssue ModelRevision".split()
        vocab = json.loads((ROOT / "vocabulary.json").read_text())
        self.assertTrue(set(names) <= set(vocab["classes"]))


class SemanticContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import validate_model as engine
        cls.engine = engine
        cls.original = json.loads((ROOT / "examples/apartment.json").read_text())

    def setUp(self):
        self.model = copy.deepcopy(self.original)

    def entity(self, id):
        return next(e for e in self.model["entities"] if e["id"] == id)

    def codes(self):
        return {e["code"] for e in self.engine.validate_model(self.model)}

    def test_three_residential_examples(self):
        for name in ("detached", "villa", "apartment"):
            m = json.loads((ROOT / f"examples/{name}.json").read_text())
            self.assertEqual([], self.engine.validate_model(m), name)

    def test_unknown_sill_is_not_zero(self):
        self.assertIsNone(self.entity("Q-SILL")["value"])
        self.entity("Q-SILL")["value"] = 0
        self.assertIn("UNKNOWN_VALUE", self.codes())

    def test_missing_quantity_unit_rejected(self):
        del self.entity("Q-WALL-THICKNESS")["unit"]
        self.assertIn("SCHEMA", self.codes())

    def test_approved_is_not_a_measurement_method(self):
        self.entity("Q-WALL-THICKNESS")["evidenceStatus"] = "approved"
        self.assertIn("SCHEMA", self.codes())

    def test_unsupported_approval_rejected(self):
        self.entity("Q-WALL-THICKNESS")["approvalStatus"] = "approved"
        self.assertIn("APPROVAL_EVIDENCE", self.codes())

    def test_wrong_opening_host_rejected(self):
        self.entity("OPEN-DOOR")["voidsElement"] = "SPACE-LIVING"
        self.assertIn("REFERENCE_TYPE", self.codes())

    def test_host_width_overflow_rejected(self):
        self.entity("Q-DOOR-OFFSET")["value"] = 5900
        self.assertIn("OPENING_OUTSIDE_HOST", self.codes())

    def test_opening_quantity_subject_is_bound(self):
        self.entity("Q-DOOR-WIDTH")["quantitySubject"] = "OPEN-WINDOW"
        self.assertIn("QUANTITY_BINDING", self.codes())

    def test_polygon_cannot_be_unclosed(self):
        self.entity("GEOM-FLOOR")["points"].pop()
        self.assertIn("OPEN_RING", self.codes())

    def test_polygon_self_intersection_rejected(self):
        self.entity("GEOM-FLOOR")["points"] = [[0,0,0],[6000,4000,0],[6000,0,0],[0,4000,0],[0,0,0]]
        self.assertIn("SELF_INTERSECTION", self.codes())

    def test_parent_placement_cycle_rejected(self):
        self.entity("PLACE-BUILDING")["relativeTo"] = "PLACE-WALL"
        self.assertIn("PLACEMENT_CYCLE", self.codes())

    def test_villa_name_does_not_infer_legal_use(self):
        self.entity("PROFILE")["colloquialUse"] = "빌라"
        self.entity("PROFILE")["legalUse"] = "unknown"
        self.entity("PROFILE")["useEvidenceStatus"] = "unknown"
        self.assertEqual([], self.engine.validate_model(self.model))
        self.assertEqual("unknown", self.entity("PROFILE")["legalUse"])

    def test_balcony_state_revision_is_preserved(self):
        self.assertEqual("expanded", self.entity("BALCONY")["balconyState"])
        self.assertEqual("unexpanded", self.entity("BALCONY-OLD")["balconyState"])
        self.assertNotEqual(self.entity("BALCONY")["belongsToRevision"], self.entity("BALCONY-OLD")["belongsToRevision"])

    def test_conflicting_dimensions_cannot_be_silently_resolved(self):
        self.entity("ISSUE-HEIGHT")["issueStatus"] = "resolved"
        self.assertIn("CONFLICT_RESOLUTION_EVIDENCE", self.codes())

    def test_two_independent_scale_checks_required(self):
        self.entity("CALIBRATION")["calibrationChecks"] = self.entity("CALIBRATION")["calibrationChecks"][:1]
        self.assertIn("CALIBRATION_INSUFFICIENT", self.codes())

    def test_mm_to_m_rotation_and_mirror(self):
        self.assertEqual([1.0, 2.0, 0.0], self.engine.transform_point([1000,2000,0], [0,0,0], 0, "right", "mm", "m"))
        p = self.engine.transform_point([1000,0,0], [0,0,0], 90, "mirrored", "mm", "m")
        self.assertAlmostEqual(0.0, p[0], places=8)
        self.assertAlmostEqual(-1.0, p[1], places=8)

    def test_door_move_recomputes_only_live_opening_interval(self):
        old = self.engine.opening_interval(self.model, "OPEN-DOOR")
        self.entity("Q-DOOR-OFFSET")["value"] = 1500
        new = self.engine.opening_interval(self.model, "OPEN-DOOR")
        self.assertEqual([1000,2000], old)
        self.assertEqual([1500,2500], new)
        self.assertEqual("WALL-01", self.entity("OPEN-DOOR")["voidsElement"])

    def test_wall_reference_side_changes_offset_semantics(self):
        self.assertEqual([-100,100], self.engine.wall_offsets(200, "center", "left"))
        self.assertEqual([-200,0], self.engine.wall_offsets(200, "interior", "left"))
        self.assertEqual([0,200], self.engine.wall_offsets(200, "exterior", "left"))

    def test_change_invalidates_dependent_drawings_and_solids(self):
        changed = self.engine.invalidate(self.model, ["WALL-01"])
        by_id = {e["id"]:e for e in changed["entities"]}
        for id in ("PLAN-OUTPUT","SOLID-WALL","SCHEDULE"):
            self.assertEqual("stale", by_id[id]["artifactStatus"])
        self.assertEqual("current", self.entity("PLAN-OUTPUT")["artifactStatus"])

    def test_stair_cannot_use_a_wall_opening(self):
        self.entity("STAIR")["usesOpening"] = "OPEN-DOOR"
        self.assertIn("STAIR_SLAB_OPENING", self.codes())

    def test_shafts_and_unit_boundary_roles_survive_roundtrip(self):
        restored = self.engine.from_graph(self.engine.to_graph(self.model))
        self.assertEqual(self.engine.canonical(self.model), self.engine.canonical(restored))
        by_id = {e["id"]:e for e in restored["entities"]}
        self.assertIn("unit_boundary", by_id["WALL-01"]["wallRoles"])
        self.assertEqual("Shaft", by_id["SHAFT"]["type"])

    def test_whole_building_approval_cannot_be_synthesized(self):
        self.entity("ASSESSMENT")["isWholeBuildingApproval"] = True
        self.assertIn("SCHEMA", self.codes())

    def test_design_documents_reject_unresolved_inputs(self):
        self.entity("BRIEF")["outputPurpose"] = "design_documents"
        self.assertIn("OUTPUT_UNVERIFIED", self.codes())

    def test_unknown_rule_applicability_stays_unknown(self):
        r = self.engine.evaluate_expression({"kind":"all_of","items":[{"kind":"fact","factCode":"IS-RESIDENTIAL","expected":True},{"kind":"fact","factCode":"EDITION-CONFIRMED","expected":True}]}, {"IS-RESIDENTIAL": True}, {})
        self.assertIsNone(r)

    def test_quantity_change_invalidates_dependents(self):
        changed = self.engine.invalidate(self.model, ["Q-WALL-THICKNESS"])
        self.assertEqual("stale", next(e for e in changed["entities"] if e["id"] == "PLAN-OUTPUT")["artifactStatus"])

    def test_duplicate_ids_rejected(self):
        self.model["entities"].append(copy.deepcopy(self.entity("WALL-01")))
        self.assertIn("DUPLICATE_ID", self.codes())

    def test_missing_target_rejected(self):
        self.entity("DOOR")["fillsOpening"] = "NO-SUCH-OPENING"
        self.assertIn("REFERENCE_MISSING", self.codes())

    def test_derived_quantity_requires_inputs(self):
        self.entity("Q-WALL-THICKNESS")["evidenceStatus"] = "derived"
        self.assertIn("DERIVATION_EVIDENCE", self.codes())

    def test_wrong_dimension_subject_rejected(self):
        self.entity("DIM-WALL")["annotates"] = "SPACE-LIVING"
        self.assertIn("DIMENSION_BINDING", self.codes())

    def test_stair_hole_must_match_slab_hole(self):
        self.entity("GEOM-FLOOR")["holes"] = []
        self.assertIn("STAIR_HOLE", self.codes())

    def test_layer_order_collision_rejected(self):
        layer = copy.deepcopy(self.entity("LAYER-CONCRETE"))
        layer["id"] = "LAYER-DUPLICATE"
        self.model["entities"].append(layer)
        self.entity("ASSEMBLY")["hasLayer"].append(layer["id"])
        self.assertIn("LAYER_ORDER", self.codes())

    def test_polyline_points_cannot_be_degenerate(self):
        self.entity("GEOM-WALL")["points"] = [[0,0,0], [0,0,0]]
        self.assertIn("DEGENERATE_GEOMETRY", self.codes())

    def test_jsonld_semantic_roundtrip(self):
        from rdflib import Graph
        graph = Graph().parse(data=json.dumps(self.engine.to_jsonld(self.model)), format="json-ld")
        self.assertEqual(self.engine.canonical(self.model), self.engine.canonical(self.engine.from_graph(graph)))

    def test_shacl_valid_and_unknown_negative(self):
        self.assertTrue(self.engine.shacl_validate(self.model)[0])
        self.entity("Q-SILL")["value"] = 0
        self.assertFalse(self.engine.shacl_validate(self.model)[0])

    def test_three_valued_logic(self):
        e = self.engine.evaluate_expression
        a = {"kind": "fact", "factCode": "A", "expected": True}
        b = {"kind": "fact", "factCode": "B", "expected": True}
        self.assertFalse(e({"kind": "all_of", "items": [a,b]}, {"A": False}, {}))
        self.assertTrue(e({"kind": "any_of", "items": [a,b]}, {"A": True}, {}))
        self.assertIsNone(e({"kind": "not", "item": b}, {}, {}))

    def test_mismatched_measurement_basis_is_unknown(self):
        q = {"value": 900, "unit": "mm", "basis": "leaf_nominal", "evidenceStatus": "field_measured", "validityStatus": "current"}
        e = {"kind": "compare", "propertyTerm": "width", "operator": "gte", "value": 900, "unit": "mm", "basis": "clear_in_use"}
        self.assertIsNone(self.engine.evaluate_expression(e, {}, {"width": q}))

    def test_editing_automation_flag_cannot_activate_rule(self):
        r = json.loads((ROOT / "rule-contracts.json").read_text())["rules"][0]
        r["automationStatus"] = "project_verified"
        r["applicabilityExpression"] = {"kind": "fact", "factCode": "A", "expected": True}
        r["exceptionExpression"] = {"kind": "fact", "factCode": "B", "expected": True}
        r["requirementExpression"] = {"kind": "fact", "factCode": "A", "expected": True}
        self.assertEqual("UNKNOWN", self.engine.evaluate_rule(r, {"A": True, "B": False}, {}))

    def test_non_finite_numbers_rejected(self):
        self.entity("Q-WALL-THICKNESS")["value"] = float("nan")
        self.assertIn("NON_FINITE", self.codes())

    def test_opening_negative_height_rejected(self):
        self.entity("Q-DOOR-HEIGHT")["value"] = -10
        self.assertIn("OPENING_DIMENSION", self.codes())

    def test_wall_opening_storey_must_match_host(self):
        self.entity("OPEN-DOOR")["belongsToStorey"] = "STOREY-2"
        self.assertIn("OPENING_STOREY", self.codes())

    def test_optional_empty_relation_set_roundtrip(self):
        self.entity("WALL-01")["hasSource"] = []
        restored = self.engine.from_graph(self.engine.to_graph(self.model))
        self.assertEqual(self.engine.canonical(self.model), self.engine.canonical(restored))

    def test_calibration_matches_referenced_dimension_value(self):
        self.entity("CALIBRATION")["calibrationChecks"][0]["modelLengthMm"] = 6100
        self.assertIn("CALIBRATION_MEASUREMENT", self.codes())


if __name__ == "__main__":
    unittest.main(verbosity=2)
