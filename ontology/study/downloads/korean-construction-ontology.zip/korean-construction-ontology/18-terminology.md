---
description: "Korean construction ontology foundation: 18-terminology."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: concept
trustLevel: unverified
sourceType: synthesis
CMDS: Develop
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 한국 건설 용어·현장어 매핑

현장어는 발화 맥락에 따라 뜻이 달라진다. 별칭만 같다는 이유로 물리 객체를 병합하지 않는다. SKOS label은 검색에 쓰고, 실제 동치는 정의·기준면·역할을 대조한다.

| 표현 | 정규화 후보 | 주의 |
|---|---|---|
| 골조 | StructuralFrame | 마감 포함 건물 전체와 구별 |
| 벽식 | WallBearingSystem | 하중 전달체계 확인 |
| 라멘 | BeamColumnFrame | 법정 예외의 정의와 맞춰야 함 |
| 무량판 | FlatSlabSystem | 라멘 자동 매핑 금지 |
| 조적 | Masonry | 벽돌·블록·석조 구체화 |
| 경량벽·드라이월 | DrywallAssembly | 일반 보드와 인정 시스템 분리 |
| 스터드·샛기둥 | Stud | 폭·강재두께·간격·방향 |
| 런너·트랙 | Track | 상하단·고정·처짐상세 |
| 석고 2P | GypsumBoardLayerCount | 양면 각각 2겹인지 총 2겹인지 질문 |
| 내단열·외단열·중단열 | InsulationPlacement | 구조체 기준 위치 |
| 단열선 | ThermalBoundary | 기밀선·방수선과 다름 |
| 열교 | ThermalBridge | 누기와 다름 |
| 결로 | Condensation | 누수와 다름 |
| 방수·방습·투습 | Water/VapourFunctions | 서로 반대 또는 별도 성능 |
| 후레싱 | Flashing | 빗물 배출 금속·시트 상세 |
| 창대 | Sill | 상단·유리 하단 기준 구분 |
| 인방 | Lintel | 창 위 구조 지지 부재 |
| 안목 | ClearInsideDimension | 어떤 마감 경계인지 지정 |
| 먹·먹매김 | SettingOut/Datum | 작업과 기준선 객체 구분 |
| 레벨 | Elevation/Level | 기준점·단위·상태 필요 |
| 층고·층높이 | StoreyHeight | 구조/마감 기준면 선언 |
| 천고·천장고·반자높이 | CeilingHeight | 국소 보 하부 유효높이 별도 |
| 방통 | FloorHeatingWetWork 후보 | 범위·레이어를 현장에 확인 |
| 몰탈·모르타르 | Mortar | 용도·배합·제품 별도 |
| 공구리 | Concrete | 비공식 별칭, 정본 용어는 콘크리트 |
| 슬라브·슬래브 | Slab | 구조 판/바닥 총구성 구분 |
| 구배·물매 | Slope | 수평 투영길이 기준 |
| 턱·문지방 | Threshold/Step | 형상·방수·접근성 역할 |
| 두겁 | Coping | 벽·파라펫 상단 덮개 |
| 걸레받이 | Skirting | 바닥 구조층과 구별 |
| 피복 | ConcreteCover 등 | 콘크리트 피복/전선 피복 맥락 |
| 내화·불연·준불연·난연 | 별도 성능개념 | 구조의 시간성능과 재료 연소성 구분 |
| 차음·흡음 | SoundInsulation/Absorption | 소리 전달 차단과 실내 반사 저감 구분 |
| 중량충격음·경량충격음 | ImpactSoundMetrics | 시험법·지표·판본 필수 |
| 유효폭·외경·문짝폭 | 별도 Quantity | 동의어로 병합 금지 |
| 준공도·시공도·허가도 | DrawingStage | 최신 날짜만으로 승인 상태 추정 금지 |

이 표는 검색·데이터 정규화를 위한 작성자 편집 사전이며 KS 표준 용어집 전체가 아니다.
