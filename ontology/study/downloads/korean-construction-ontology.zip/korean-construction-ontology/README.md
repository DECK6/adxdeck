# 한국 주거 건축·건설 온톨로지 · 실습 패키지

v0.3 · 원자료 조사 기준 2026-09-05 · 배포 정리 2026-09-30

단독·다가구·다세대·연립·아파트의 공간, 벽, 문, 창, 레이어, 치수, 근거를 연결한 온톨로지입니다. 116개 클래스, 106개 객체 관계, 108개 데이터 속성, 참고 규칙 69개를 담았습니다. 실습페이지의 FAMILY-02 작은 예제와 별개의 확장 패키지입니다.

## 읽고 실습하는 순서

1. [전체 안내](00-index.md)와 [개념·관계](13-ontology-schema.md)를 읽습니다.
2. [문·개구부](05-doors-and-openings.md)에서 문짝 폭과 통과유효폭을 구분하고 [예제](15-worked-examples.md)의 근거와 연결합니다.
3. [어휘 정본](vocabulary.json), [OWL](ontology.ttl), [SHACL](shapes.ttl), [JSON Schema](schemas/residential-model.schema.json)를 비교합니다.
4. [아파트](examples/apartment.json), [단독주택](examples/detached.json), [빌라](examples/villa.json) 중 하나의 사본으로 실습합니다.
5. [검증·이행 안내](23-validation-and-migration.md)를 따라 입력을 검사합니다.

## 실행

Python 3.11 이상에서 패키지 폴더를 작업 디렉터리로 사용합니다. 아래 명령은 모델·제약을 검사하며 외부 AI API를 호출하지 않습니다.

```sh
python3 -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell에서는 .venv/Scripts/Activate.ps1
python -m pip install -r requirements.txt
python tools/validate_model.py examples/apartment.json --shacl
python tools/check_package.py --report verification-report.json
```

에이전트에게 이렇게 요청할 수 있습니다.

> 00-index.md와 13-ontology-schema.md를 읽고, apartment.json의 벽·개구부·문과 치수의 연결을 설명해줘. 값이 없는 치수는 추정하지 말고 근거와 UNKNOWN을 보존해줘. 원본을 유지하고 실습 사본에서 관계 하나를 바꾼 뒤 검증기의 결과와 이유를 비교해줘.

## 자료의 범위

2026-09-05의 조사·구현 스냅샷이며 이번 배포에서 법령의 현행성을 새로 조사하지 않았습니다. 규칙은 reference_only 상태입니다. 합성 예제의 구조 검증과 실제 건물의 안전·인허가·복원 정확도는 별개입니다. [출처대장](16-source-register.md), [적용 조건](25-residential-legal-conditions.md)에 판본과 확인 범위를 기록했습니다. 외부 법령·표준·제조사 문헌의 권리는 각 제공자에게 있습니다.
