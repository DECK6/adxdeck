---
description: "Korean construction knowledge and ontology: 11-construction-safety-and-quality."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 가설 안전과 품질 기록

## 완성 시설과 공사 중 시설을 구분한다

영구 난간·임시 안전난간·작업발판·비계는 다른 대상이다. 이 장은 안전 지식의 시작점이며 현장 안전계획 전체가 아니다.

| ID | 항목 | 조건과 내용 | 근거 |
|---|---|---|---|
| SITE-001 | 작업발판 폭 | 해당 비계 높이 2m 이상 작업장소: 400mm 이상, 제외·예외 확인 | S21 제56조 |
| SITE-002 | 발판 틈 | 같은 조건: 30mm 이하 원칙, 예외 확인 | S21 제56조 |
| SITE-003 | 최대 적재하중 | 구조·재료에 맞춰 정하고 초과 금지 | S21 제55조 |
| SITE-004 | 말비계 | 높이 2m 초과: 폭 400mm 이상 | S22 제67조 |

S22 확인판 시행 2026-03-02. S21은 현행 연결 페이지에서 조문을 확인했으며 전체 표제부·최신 개정 재대조가 필요하다. [작업발판](https://law.go.kr/lsInfoP.do?ancYnChk=0&lsId=007363), [말비계](https://www.law.go.kr/LSW/lsLinkCommonInfo.do?lsJoLnkSeq=1020912307).

치수만 맞아도 비계 전체 안전이 입증되는 것은 아니다. 지지·고정·난간·적재·조립·환경 등 다른 요구가 남는다. 2m라는 값이 같아도 이상과 초과 연산자를 구별한다.

## 품질 기록

ProductBatch → DeliveryInspection → InstallationActivity → ConcealedInspection → Test → Handover로 연결한다.

| 기록 | 필수 맥락 |
|---|---|
| 자재 승인 | 제품·성능·부위·승인판 |
| 반입 검사 | 로트·손상·보관·시험 |
| 시공 사진 | 층·실·부재·방향·날짜 |
| 은폐 검사 | 무엇을 누가 어떤 기준으로 확인했는가 |
| 시험 | 방법·장비·단위·조건·결과·불확도 |
| 변경 | 변경 전후·연관 요구·승인 |
| 인수인계 | 유지관리·교체·보증·하자 이력 |

‘먹을 먼저 맞춘다’는 Datum establishedBefore Installation, ‘덮기 전에 본다’는 Inspection precedes Concealment로 바꾼다. 현장 조정은 승인 상세와 동일하지 않으며 변경 리비전·작업지시·검사 근거가 필요하다. 공차·설계여유·법정 최솟값·불량 허용을 별개 속성으로 저장한다.
