---
description: "Korean construction knowledge and ontology: 09-waterproofing-and-roofs."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 방수·지붕·욕실·배수 상세

## 방수는 공법과 위치가 먼저다

액상 도막·시트·복합·시멘트계는 바탕·프라이머·보강·두께·양생·보호층 조건이 다르다. KCS 41 40 계열은 방수 기준의 탐색 경로다(S11·S12). 세부 코드 최신 전문을 모두 확보한 것은 아니므로 최소 도막두께·겹침폭을 보편값으로 제시하지 않는다.

| 부위 | 핵심 변수 | 관계 |
|---|---|---|
| 욕실 바닥 | 바탕 구배·드레인·무단차 | WetArea drainsTo Drain |
| 벽-바닥 모서리 | 변위·균열·보강·치켜올림 | Junction treatedBy Detail |
| 평지붕 | 구배·주배수·넘침 배수·파라펫 | Roof hasDrainagePath |
| 지하 외벽 | 지하수·수압·이음·보호 | Wall exposedTo WaterPressure |
| 테라스 문 | 내외부 레벨·단열·방수 연결 | Threshold interfacesWith Layer |
| 관통부 | 배관 재질·변위·슬리브 | Penetration sealedBy System |
| 드레인 | 방수층 접속·최저점·청소 | Drain accessibleFor Maintenance |

## 시공 판단 패턴: 작성자 합성·현장 검증 전

- 물의 입구와 출구를 함께 찾는다. 겉면 실란트 보수만으로 원인이 제거됐다고 판단하지 않는다.
- 타일과 줄눈은 방수층과 구별한다. 마감이 멀쩡해도 하부 접합이 새는 경우를 검토한다.
- 배수구 주변의 국소 역구배를 확인한다. 바닥 전체 경사만으로 배수 성능을 판단하지 않는다.
- 모서리·관통·이음·드레인 접속을 평탄부와 별도 검사한다.
- 다음 공정이 덮기 전에 검사한다. 사진은 위치·방향·날짜·측정 기준과 연결한다.
- 무단차와 방수는 구조 레벨·배수·방수층 연속을 함께 풀어야 한다. 높은 턱을 모든 문제의 해법으로 삼지 않는다.
- 강우 때의 누수, 난방 때의 결로, 상층 물 사용 때의 누수를 같은 원인으로 확정하지 않는다.

위 항목은 현장 인터뷰를 통해 확인한 관행이 아니다. 시방·제품 자료로 구체화할 검토 지식이다.

## 구배 계산 예

수평 2,000mm에 가정 구배 1%면 높이차 20mm, 2%면 40mm다. 욕실·옥상 의무 구배 또는 권장치가 아니라 산술 예제다. 실제 경사는 제품·시방·마감·접근성 조건에서 정한다.

## 은폐 검사 데이터

검사에는 바탕 승인, 모서리·관통부, 드레인 연결, 건조 도막두께, 시험 방법·수위·시간·결과, 시방 리비전, 다음 공정 승인 여부를 둔다. 미확인 시간·수위는 null로 보존하며 임의의 24시간으로 채우지 않는다. 사진만으로 숨은 전체 두께·접착 상태를 입증할 수 없다.

온톨로지에서 Material, WaterproofingSystem, InstallationActivity, Inspection, DefectHypothesis를 분리한다. 동일 자재라도 바탕·층 구성·시공 조건이 달라지면 별도 시스템 인스턴스다.
