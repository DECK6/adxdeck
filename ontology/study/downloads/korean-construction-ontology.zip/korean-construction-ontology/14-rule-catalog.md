---
description: "Catalogues conditional Korean construction requirements with scope, exceptions and provenance."
akmLayer: knowledge
akmRole: reusable-knowledge
akmType: guide
trustLevel: unverified
sourceType: synthesis
CMDS: Merge
nextAction: verify
date created: 2026-09-05
date modified: 2026-09-05
tags: [construction, architecture, korea, ontology]
---

# 조건부 규칙 카탈로그

## 사용 계약

이 목록은 조건과 근거를 보존한 지식 데이터다. 실행 가능한 판정 프로그램이나 현행 법규 완전집이 아니다. 숫자만 복사하지 말고 [rules.json](rules.json)의 applicability, exceptions, measurementBasis, sourceEditions를 함께 사용한다. 아래 요약 표의 수치는 모든 건축물에 적용되는 기본값이 아니다.

- 법령(LAW)·고시(NOTICE): 사업의 용도·규모·신청일·경과조치·적용판 확인 후 사용.
- 제품(PRODUCT): 해당 제조사·제품·인정 구성에만 연결. 카탈로그 숫자는 법정 최소치가 아니다.
- 지침(GUIDANCE): 문서의 대상 범위 내 권고. 법령 편입 여부는 별도 확인.
- 작성자 합성(SYNTHESIS): 검증 후보. 자동 적합 판정 입력으로 승격하지 않는다.

규칙의 authority와 출처 문서의 authority는 다를 수 있다. THERMAL은 고시 요구를 공식 해설서 표로 확인했다. 적용판본이 불명확하면 UNKNOWN이다. exceptions가 빈 배열이어도 ‘법령 전체에 예외가 없다’를 뜻하지 않는다.

## 대표 규칙 카드

아래는 데이터 구조 예시다. 전체 카드는 JSON에 보존했다.


```json
{
  "id": "WALL-001",
  "title": "철근콘크리트 또는 철골철근콘크리트 경계벽 두께",
  "authority": "LAW",
  "subject": "Wall",
  "property": "thickness",
  "operator": "gte",
  "value": 150,
  "unit": "mm",
  "measurementBasis": "조항이 허용한 바름 마감 포함(001·002); 일반 단열·공기층 합산 금지",
  "applicability": {
    "allOf": [
      "주택건설기준 등에 관한 규정 적용 대상",
      "공동주택 세대간 또는 주택 외 시설과의 경계벽",
      "내화구조",
      "철근콘크리트 또는 철골철근콘크리트"
    ],
    "projectProcedureAndEditionConfirmed": null
  },
  "exceptions": [
    "다른 인정 경로와 OR 관계; 모든 경로 동시 적용 아님"
  ],
  "sourceIds": [
    "S03"
  ],
  "sourceLocator": "제14조제1항 각 호",
  "sourceEditions": [
    "2026-06-30 시행"
  ],
  "sourceVerification": [
    "직접 조문 확인"
  ],
  "projectApplicability": "unverified",
  "legalApplicabilityVerified": false,
  "automationStatus": "reference_only",
  "checkedAt": "2026-09-05",
  "missingInputResult": "UNKNOWN"
}
```

## 발췌 목록

법령 경로의 OR/AND 구분: WALL-001~004는 벽체 종류에 따른 대안 경로이며 두께를 모두 동시에 요구하지 않는다. FLOOR-001/002는 구조형식 조건이 다르다. THERMAL-008/009의 문 경로도 구분한다. 접근성·피난·주택 규정은 각각의 적용 여부를 먼저 확인한 후 중첩한다.

| ID | 요구·주장 | 근거 종류 | 값 또는 결과 | 출처 ID |
|---|---|---|---|---|
| WALL-001 | 철근콘크리트 또는 철골철근콘크리트 경계벽 두께 | LAW | 150 mm | S03 |
| WALL-002 | 무근콘크리트·블록·벽돌·석조 경계벽 두께 | LAW | 200 mm | S03 |
| WALL-003 | 조립식 주택부재 콘크리트판 경계벽 두께 | LAW | 120 mm | S03 |
| WALL-004 | 대체 경계벽 차음 인정 경로 | LAW | 정성 요건  | S03 |
| WALL-005 | 경계벽 상단과 틈 연속성 | LAW | 정성 요건  | S03 |
| HEIGHT-001 | 일반 거실 반자높이 | LAW | 2100 mm | S05 |
| HEIGHT-002 | 주택 거실·침실 반자높이 | LAW | 2200 mm | S06 |
| HEIGHT-003 | 주택 층높이 | LAW | 2400 mm | S06 |
| FLOOR-001 | 일반 공동주택 슬래브 | LAW | 210 mm | S02 |
| FLOOR-002 | 라멘구조 공동주택 슬래브 | LAW | 150 mm | S02 |
| FLOOR-003 | 층간바닥 충격음 | LAW | {"lightweight": 49, "heavyweight": 49} dB | S02 |
| DOOR-001 | 출입문 통과유효폭 | LAW | 900 mm | S07 |
| DOOR-002 | 문 전면 유효거리 | LAW | 1200 mm | S07 |
| DOOR-003 | 비자동문 옆 활동공간 | LAW | 600 mm | S07 |
| DOOR-004 | 경기용 휠체어 해당 출입구 | LAW | 1200 mm | S07 |
| DOOR-005 | 출입구 단차 제거 | LAW | 0 mm | S07 |
| WINDOW-001 | 거실 채광 개구부 비율 | LAW | 0.1 ratio | S05 |
| WINDOW-002 | 거실 환기 개구부 비율 | LAW | 0.05 ratio | S05 |
| WINDOW-003 | 저창대의 별도 난간 대상 판단 | LAW | 정성 요건  | S04b |
| STAIR-001 | 계단 유효높이 | LAW | 2100 mm | S05 |
| STAIR-002 | 높은 계단의 참 | LAW | {"triggerHeightGt": 3000, "maxVerticalInterval": 3000, "minLandingClearWidth": 1200} mm | S05 |
| STAIR-003 | 초등학교 계단 | LAW | {"minClearWidth": 1500, "maxRiserHeight": 160, "minTreadDepth": 260} mm | S05 |
| STAIR-004 | 중학교·고등학교 계단 | LAW | {"minClearWidth": 1500, "maxRiserHeight": 180, "minTreadDepth": 260} mm | S05 |
| STAIR-005 | 접근성 계단 치수 | LAW | {"minTreadDepth": 280, "maxRiserHeight": 180} mm | S07 |
| RAIL-001 | 주택 난간 높이 | LAW | 1200 mm | S04 |
| RAIL-002 | 난간 간살 안목간격 | LAW | 100 mm | S04 |
| RAMP-001 | 접근성 경사로 일반 경사 | LAW | 0.08333333333333333 ratio | S07 |
| RAMP-002 | 접근성 경사로 일반 폭 | LAW | 1200 mm | S07 |
| PARK-001 | 평행 외 경형 주차구획 | LAW | {"width": 2000, "length": 3600} mm | S10 |
| PARK-002 | 평행 외 일반형 주차구획 | LAW | {"width": 2500, "length": 5000} mm | S10 |
| PARK-003 | 평행 외 확장형 주차구획 | LAW | {"width": 2600, "length": 5200} mm | S10 |
| PARK-004 | 평행 외 장애인전용 주차구획 | LAW | {"width": 3300, "length": 5000} mm | S10 |
| THERMAL-001 | 공동주택 외벽 직접 열관류율 | NOTICE | {"central1": 0.15, "central2": 0.17, "south": 0.22, "jeju": 0.29} W/(m2*K) | S08·S09 |
| THERMAL-002 | 공동주택 외 외벽 직접 열관류율 | NOTICE | {"central1": 0.17, "central2": 0.24, "south": 0.32, "jeju": 0.41} W/(m2*K) | S08·S09 |
| THERMAL-003 | 공동주택 외벽 간접 열관류율 | NOTICE | {"central1": 0.21, "central2": 0.24, "south": 0.31, "jeju": 0.41} W/(m2*K) | S08·S09 |
| THERMAL-004 | 공동주택 외 외벽 간접 열관류율 | NOTICE | {"central1": 0.24, "central2": 0.34, "south": 0.45, "jeju": 0.56} W/(m2*K) | S08·S09 |
| THERMAL-005 | 최상층 지붕 직접 열관류율 | NOTICE | {"central1": 0.15, "central2": 0.15, "south": 0.18, "jeju": 0.25} W/(m2*K) | S08·S09 |
| THERMAL-006 | 최하층 난방바닥 직접 열관류율 | NOTICE | {"central1": 0.15, "central2": 0.17, "south": 0.22, "jeju": 0.29} W/(m2*K) | S08·S09 |
| THERMAL-007 | 공동주택 창·문 직접 열관류율 | NOTICE | {"central1": 0.9, "central2": 1.0, "south": 1.2, "jeju": 1.6} W/(m2*K) | S08·S09 |
| THERMAL-008 | 공동주택 외 창·문 직접 열관류율 | NOTICE | {"central1": 1.3, "central2": 1.5, "south": 1.8, "jeju": 2.2} W/(m2*K) | S08·S09 |
| THERMAL-009 | 공동주택 외 문 직접 별도 열관류율 | NOTICE | {"central1": 1.5, "central2": 1.5, "south": 1.8, "jeju": 2.2} W/(m2*K) | S08·S09 |
| VENT-001 | 해당 공동주택 환기 | LAW | 0.5 1/h | S20 |
| SITE-001 | 비계 작업발판 폭 | LAW | 400 mm | S21 |
| SITE-002 | 비계 발판 틈 | LAW | 30 mm | S21 |
| SITE-003 | 비계 적재하중 | LAW | 정성 요건  | S21 |
| SITE-004 | 말비계 발판 폭 | LAW | 400 mm | S22 |
| PROD-001 | KND-12DB 인정 조립체 | PRODUCT | {"minThickness": 100, "fireResistanceHours": 1, "recognitionId": "FR-WS23-0109-2"} mm;h | S27 |
| PROD-002 | KND-19DB 인정 조립체 | PRODUCT | {"minThickness": 126, "fireResistanceHours": 2, "recognitionId": "FR-WS23-0109-6"} mm;h | S28 |
| PROD-003 | 영림 FROST ABS 문 제작 범위 | PRODUCT | {"doorThickness": 35, "maxWidth": 1000, "maxHeight": 2300} mm | S29 |
| TK-001 | 마감 후 치수를 본다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-002 | 벽 역할을 먼저 묻는다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-003 | 물 입구·출구를 같이 찾는다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-004 | 단열·기밀·방수선을 따로 그린다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-005 | 이론 최선과 시공성을 함께 본다 | GUIDANCE | 정성 요건  | S18 |
| TK-006 | 열교와 누기를 구분한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-007 | 경계벽 상단 연속을 본다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-008 | 보드와 시스템 성능을 구분한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-009 | 하중 보강은 마감 전에 정한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-010 | 문 열림과 가구를 중첩한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-011 | 배관 구배·보온도 공간에 넣는다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-012 | 점검구와 반출경로를 나눈다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-013 | 타일과 방수층을 구분한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-014 | 드레인 주변 역구배를 본다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-015 | 양생과 건조를 구분한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-016 | 소음은 가장자리·관통도 본다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-017 | 보수로 원인을 단정하지 않는다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-018 | 변경을 연관 설계에 전파한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-019 | 가려지는 공정 증거를 남긴다 | SYNTHESIS | 정성 요건  | 작성자 합성 |
| TK-020 | 규칙의 판본을 보관한다 | SYNTHESIS | 정성 요건  | 작성자 합성 |

## 그래프 변환 전 최소 검증

1. ID 중복이 없어야 하고 sourceIds는 [출처대장](16-source-register.md)에 존재해야 한다.
2. 단위와 기준면이 다른 수치를 직접 비교하지 않는다.
3. 날짜·용도·지역·구조형식 중 적용에 필요한 누락값은 UNKNOWN으로 보존한다.
4. value가 객체인 규칙은 명시된 각 성분과 연산의 의미를 보존한다.
5. sourceVerification은 원문 확인 수준이며 projectApplicability를 대신하지 않는다.
6. 법령 개정 시 기존 Rule을 삭제하거나 덮어쓰는 대신 새 판·supersedes 관계를 만든다.

[온톨로지 명세](13-ontology-schema.md) · [예제](15-worked-examples.md) · [검증 질문](17-competency-questions.md)

## v0.2 조건식과 원 규칙

[rules.json](rules.json)은 v0.1 출처 기록을 그대로 보존한다. [rule-contracts.json](rule-contracts.json)은 같은 69개 ID 각각에 원 기록 전체 legacyRecord, applicabilityExpression, exceptionExpression, requirementExpression을 붙인다.

표현은 all_of/any_of/not/fact/compare/evidence_required로 제한한다. 수치 비교는 같은 속성·단위·측정기준의 현재 값만 받는다. 지역별 열관류율은 지역 사실과 상한 비교의 조건 분기로 표현한다. 인정 시스템·시공 조건·암묵지처럼 숫자 하나로 표현할 수 없는 요구는 근거 확인 술어로 남긴다.

조건 사실 378개는 원문 조건을 추적하는 식별자이며, 참으로 확인된 현장 사실 378개가 아니다. 판·사업·객체 범위와 근거 없이 기본 참으로 채우지 않는다. 대체 인정 경로가 있다는 문구를 전체 요구 면제로 해석하지 않는다.

평가는 미확정에 None을 쓰는 삼값 논리다. 최종 결과는 UNKNOWN/PASS/FAIL/NOT_APPLICABLE이며 충돌은 ReconstructionIssue 및 Assessment의 CONFLICT로 보존한다. 배포 규칙은 모두 reference_only, 법적 적용 확인 false다. 자동화 플래그만 바꿔도 실행되지 않도록 형식화 검토 및 법적 적용 확인을 함께 검사한다.

formalizationReviewStatus=reviewed와 법령·고시의 legalApplicabilityVerified=true는 프로젝트 검토 이후에만 설정한다. 참조 함수에 부울 값을 넘기는 행위가 근거 확보를 대신하지 않는다. 개별 PASS를 건물 전체 승인으로 만드는 필드는 허용하지 않는다.
