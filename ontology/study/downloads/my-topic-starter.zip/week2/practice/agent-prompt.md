주제: [내 주제]
범위: [다루는 범위]
제외: [다루지 않는 범위]
모델 리비전: v1

이 실습 AKM의 INDEX·ROUTER·LOOP와 practice/README.md를 읽으세요. 원자료 10-sources, 직접 검토한 정리 노트 20-knowledge, practice/model.json의 종류·관계·속성·근거를 함께 확인하세요. 정리 노트의 빈칸을 실제 지식으로 취급하지 마세요.
practice/test-design.md, personal-project.json, 기존 평가 기록과 예상 답은 읽지 마세요. 원자료·검토한 지식·관계만으로 답하세요.
같은 모델·설정의 새 대화에서 아래 고정 질문에 답하세요. 답변/실제 근거 문장/따라간 관계/판단 불가 사항을 구분하고 근거가 없으면 보류하세요. 일반 지식으로 빈칸을 채우지 마세요. practice/response-template.json 형식의 새 after 파일에 실제 모델명과 실행일을 기록하세요. before를 덮어쓰지 마세요.
Q1. [내 질문을 입력하세요]
Q2. [내 질문을 입력하세요]
Q3. [내 질문을 입력하세요]
