# 내 주제 실습 · 아직 입력하지 않음

3주차 작업 파일입니다. 공식 AKM https://github.com/DECK6/akm 을 새 실습 폴더에 준비하고 그 폴더에서 에이전트를 여세요. 루트 CLAUDE.md·AGENTS.md가 지침입니다. practice/akm-public-guide.md를 읽고 자료를 추가하세요. 이 ZIP은 AKM 본체가 아닙니다. 1주차 before 기록과 직접 검토한 Wiki를 다음 주에도 이어 사용하세요. 기존 파일은 먼저 보관하고 비교한 뒤 적용합니다. 포함된 INDEX.local.md는 기존 파일에 항목만 병합하세요.

웹에서 personal-project.json을 불러오면 주제·자료·관계·평가를 이어 편집할 수 있습니다. 이 파일은 비공개 개인 작업이며 공개 사이트에 자동 업로드되지 않습니다.
