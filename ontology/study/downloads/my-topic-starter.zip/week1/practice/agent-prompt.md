주제: [내 주제]
범위: [다루는 범위]
제외: [다루지 않는 범위]

practice/test-design.md, personal-project.json, 기존 평가 기록과 예상 답은 읽지 마세요. 원자료·검토한 지식·관계만으로 답하세요.
같은 모델·설정의 새 대화에서 정리 전 기준선을 측정합니다. 00-inbox의 내 원자료와 practice/questions.json만 읽고 아래 질문에 답하세요. 모델·완성 Wiki·예시 답안은 읽지 마세요. 답변/실제 근거 문장/판단 불가 사항을 구분해 response-template.json 형식의 새 before 파일로 저장하세요.
Q1. [내 질문을 입력하세요]
Q2. [내 질문을 입력하세요]
Q3. [내 질문을 입력하세요]

기준선 기록이 끝난 뒤 별도 작업으로 공식 AKM https://github.com/DECK6/akm 의 99-system/INDEX.md와 현재 40-memory 메모, ROUTER·SCHEMA·LOOP·VERIFICATION을 읽고 원본을 보존하면서 정리 노트와 링크를 만드세요.
